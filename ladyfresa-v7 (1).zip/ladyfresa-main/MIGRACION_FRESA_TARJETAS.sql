-- 🍓 Lady Fresa — Migración: compra de fresa por cajas + tarjetas con crédito
-- Ejecuta esto en Supabase → SQL Editor → New Query. Una sola vez.
-- La app funciona aunque no corras esto (guarda el detalle en la nota),
-- pero SIN estos campos no vas a tener la hoja "Fresa" del Excel ni el $/kilo.

-- ─────────────────────────────────────────────────────────────
-- 1) Columnas nuevas en gastos (para las compras de fresa)
-- ─────────────────────────────────────────────────────────────
ALTER TABLE gastos
  ADD COLUMN IF NOT EXISTS cajas        NUMERIC,   -- cuántas cajas van a esa sucursal
  ADD COLUMN IF NOT EXISTS kg           NUMERIC,   -- kilos totales de esa sucursal
  ADD COLUMN IF NOT EXISTS precio_caja  NUMERIC,   -- precio pagado por caja
  ADD COLUMN IF NOT EXISTS tipo_caja    TEXT,      -- '6' o '4' (kilos por caja)
  ADD COLUMN IF NOT EXISTS grupo        TEXT;      -- id que une la misma compra repartida en varias tiendas

CREATE INDEX IF NOT EXISTS gastos_grupo_idx ON gastos(grupo);

-- ─────────────────────────────────────────────────────────────
-- 2) Configuración de la app (día de corte de cada tarjeta)
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS app_config (
  clave       TEXT PRIMARY KEY,
  valor       JSONB NOT NULL,
  updated_at  TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE app_config ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS app_config_all ON app_config;
CREATE POLICY app_config_all ON app_config FOR ALL USING (TRUE) WITH CHECK (TRUE);

-- Valores iniciales — AJUSTA dia_corte al de tu estado de cuenta real.
-- dias_pago: 20 = Tarjeta de Negocios Amex · 9 = Tarjeta Corporativa Amex
INSERT INTO app_config (clave, valor) VALUES (
  'tarjetas',
  '[
    {"key":"amex","forma":"Tarjeta Amex","label":"Amex Empresa","emoji":"💳","color":"#006FCF","dia_corte":15,"dias_pago":20,"perfil":"negocios"},
    {"key":"santander","forma":"Tarjeta Santander","label":"Santander","emoji":"💳","color":"#EC0000","dia_corte":1,"dias_pago":20,"perfil":"credito"}
  ]'::jsonb
)
ON CONFLICT (clave) DO NOTHING;

-- Listo ✅
-- Verifica con:
--   SELECT * FROM app_config;
--   SELECT fecha, concepto, cajas, kg, precio_caja, tipo_caja FROM gastos WHERE kg IS NOT NULL;
