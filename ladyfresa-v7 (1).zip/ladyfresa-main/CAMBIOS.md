# 🍓 Lady Fresa — v7.0: Compra de fresa por cajas + Tarjeta Amex con crédito automático

## 1) Nueva pantalla "🍓 Compra de fresa" (botón en el inicio)
Pensada para el registro diario, en tres toques:
- Eliges **caja de 6 kg o de 4 kg** y pones el **precio por caja** (te sugiere el último precio que pagaste, de un toque).
- Repartes las cajas por sucursal con botones **− / +**. No escribes montos: el total se calcula solo.
- Muestra en vivo **$ por kilo**, kilos totales y el desglose por tienda.
- Puedes agregar una **segunda línea** si el mismo día compras cajas de los dos tamaños.
- Botón **cortesía / reposición**: registra los kilos con costo $0 (para las cajas que manda el proveedor por merma y que antes no quedaban en ningún lado).
- Al guardar crea **un gasto por sucursal** con su monto proporcional, así el costo queda bien repartido en el P&L.
- Si pones menos de $400 en una caja de 6 kg, te avisa que normalmente esa es la de 4 kg.

## 2) Tarjeta Amex como forma de pago, con vencimiento automático
- Nueva forma de pago **💳 Amex** (además de Santander, que ahora también calcula solo).
- Al elegir una tarjeta, el gasto se marca como **crédito** y la app calcula la fecha límite **desde la fecha de corte**, no desde la compra — que es como funciona en México.
- Muestra: fecha de corte, fecha límite de pago y días reales de crédito de esa compra.
- Nueva pantalla **💳 Tarjetas** (desde Créditos → botón arriba a la derecha): día de corte y días para pagar, con perfiles listos:
  - **Amex Negocios** (Business / Gold / Platinum Business): corte + 20 días → hasta 50 días de financiamiento.
  - **Amex Corporativa** (Corporate Card, persona moral): corte + 9 días → hasta 39 días.
  - **Crédito bancaria** estándar MX: corte + 20 días.
- En Créditos aparece el **saldo por tarjeta agrupado por fecha límite**: cuánto hay que pagar y cuándo.

## 3) Excel
- La hoja **Gastos** ahora trae Cajas, Kg y $ por Caja.
- Nueva hoja **Fresa**: fecha, sucursal, proveedor, tipo de caja, cajas, kilos, $/caja, **$/kilo** y total, con renglón de totales. Es la unidad económica de la fresa, lista para el reporte mensual.

## Migración
Corre `MIGRACION_FRESA_TARJETAS.sql` en Supabase → SQL Editor.
La app funciona aunque no la corras (guarda el detalle en la nota del gasto), pero sin ella no tienes la hoja Fresa ni el $/kilo en Excel.

---

# 🍓 Lady Fresa — v6.1: Categorías personalizables (HOTFIX)

## Cambio crítico (v6.1)
Arreglado bug donde la vista de "detalle de un mes" (Historial → tocar mes) tenía una variable local `cats` que ocultaba el estado global, rompiendo el render. Ahora se llama `catTot` (totales por categoría).

## v6.0: Categorías personalizables

Las **11 categorías hardcoded** ahora viven en una tabla de Supabase y se administran desde la app.

### En la barra superior (sólo admins)
- **⚙️ Sucursales** (antes era "Admin")
- **📂 Categorías** (nuevo)

### Panel de Categorías
- Lista por sucursal (Todas / 🌐 Globales / cada sucursal)
- Cada categoría muestra: emoji, nombre, color, ámbito (Global o sucursal), cuántos gastos usa
- ✏️ Editar | ⏸ Desactivar | 🗑 Eliminar (sólo si no tiene gastos)

### Crear nueva categoría
- Nombre + clave técnica autogenerada
- 50+ emojis, 24 colores
- Ámbito: 🌐 Global o sólo una sucursal

### Migración aplicada por mí en Supabase
- Tabla `categorias` con 22 entradas (11 originales + 11 nuevas: Nómina, Renta, Mobiliario, Servicios Pro, Servicios, Permisos, Transporte, Compras varias, Ferretería, Consumo empleados, Caja chica)
- 114 gastos reclasificados de "Otros" a sus categorías reales

### Implementación técnica
- `CATS` (constante) → `cats` (estado de Supabase, con `CATS_DEFAULT` como fallback)
- `exportExcel` y `GastoRow` reciben `cats` como prop
- Realtime: canal "c-*" escucha cambios en `categorias`

## ✅ Verificado
- `vite build` compila sin errores
- Renderiza el splash inicial en entorno JSDOM sin errores de runtime
