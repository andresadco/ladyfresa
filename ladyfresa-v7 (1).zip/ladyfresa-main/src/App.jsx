import { useState, useEffect, useRef } from "react";
import { createClient } from "@supabase/supabase-js";
import * as XLSX from "xlsx";

const SUPABASE_URL = "https://tnspshptvqvhhwwckzcc.supabase.co";
const SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRuc3BzaHB0dnF2aGh3d2NremNjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzIyOTE4MzYsImV4cCI6MjA4Nzg2NzgzNn0.VYO6LMiRfv9pTCO-jRrz4ph2S_uKgX-kqYRCyVKCwdU";
const sb = createClient(SUPABASE_URL, SUPABASE_KEY);

const ROSA="#E8175D",ROSA_DARK="#C0134E",ROSA_BG="#FFF5F8",BLANCO="#FFFFFF";
const GRIS_DARK="#1A1A1A",GRIS_MED="#4A4A4A",GRIS_LIGHT="#F5F5F5",GRIS_TEXT="#888";
const VERDE="#2E7D32",VERDE_BG="#E8F5E9",AMBAR="#F57F17",AMBAR_BG="#FFF8E1";
const AZUL="#1565C0",AZUL_BG="#E3F2FD";

// Categorías por defecto (fallback). El estado real se lee de Supabase tabla `categorias`.
// Si Supabase falla o tarda, la app usa estas mientras tanto.
const CATS_DEFAULT=[
  {id:"fruta",label:"Fruta Fresca",emoji:"🍓",color:"#E8175D"},
  {id:"lacteos",label:"Lácteos y Cremas",emoji:"🥛",color:"#1565C0"},
  {id:"chocolate",label:"Chocolate",emoji:"🍫",color:"#4E342E"},
  {id:"toppings",label:"Toppings / Compl.",emoji:"🍯",color:"#E65100"},
  {id:"torani",label:"Jarabes Torani",emoji:"🧃",color:"#00796B"},
  {id:"azucar",label:"Azúcar / Endulz.",emoji:"🍬",color:"#F57F17"},
  {id:"bebidas",label:"Bebidas y Varios",emoji:"☕",color:"#5D4037"},
  {id:"desechables",label:"Desechables",emoji:"🥤",color:"#6A1B9A"},
  {id:"publicidad",label:"Publicidad",emoji:"📢",color:"#C62828"},
  {id:"limpieza",label:"Limpieza",emoji:"🧹",color:"#2E7D32"},
  {id:"otros",label:"Otros",emoji:"📦",color:"#546E7A"},
];
// Convertir filas de tabla `categorias` (Supabase) al shape interno {id,label,emoji,color}
const catRowToObj=(r)=>({id:r.cat_key,label:r.nombre,emoji:r.emoji||"📦",color:r.color||"#546E7A",sucursal_id:r.sucursal_id,_dbId:r.id,activa:r.activa!==false,orden:r.orden||0});
const EQUIPO=["Hugo","Sofía","Nueva","José Luis","Jefeson","Andres","Apolo"];
const PUEDE_VER_NUMEROS=["José Luis","Andres"]; // Solo ellos ven resúmenes y cifras
const PUEDE_ADMIN_SUC=["Andres","José Luis"]; // Pueden crear/editar/desactivar sucursales
const PUEDE_ADMIN_CAT=["Andres","José Luis"]; // Pueden crear/editar/desactivar categorías
const PINES={"José Luis":"5555","Andres":"1221"}; // PINs de acceso
// Apolo: puede registrar gastos y recolecciones, pero las recolecciones requieren aprobación de José Luis
const APOLO_REQUIERE_APROBACION=true;
const FORMA_OPTS=["Efectivo","Mercado Pago","Transfer BBVA","Tarjeta Santander","Tarjeta Amex","Otro"];

// ── TARJETAS CON CRÉDITO AUTOMÁTICO ──────────────────────────────────────────
// En México el crédito de una tarjeta NO son "X días desde la compra":
// se cuenta desde la FECHA DE CORTE. Compras todo el mes, cortan, y a partir
// de ahí tienes N días naturales para pagar.
//   • Tarjetas de Negocios Amex (Business / Business Gold / Business Platinum):
//     corte + 20 días naturales (hasta 50 días de financiamiento).
//   • Tarjetas Corporativas Amex (Corporate / Gold / Platinum Corporate):
//     corte + 9 días naturales (hasta 39 días de financiamiento).
//   • Tarjeta de crédito bancaria estándar en México: corte + 20 días.
// dia_corte = día del mes en que corta (1-31). Se ajusta solo en meses cortos.
const TARJETAS_DEFAULT=[
  {key:"amex",      forma:"Tarjeta Amex",      label:"Amex Empresa", emoji:"💳", color:"#006FCF", dia_corte:15, dias_pago:20, perfil:"negocios"},
  {key:"santander", forma:"Tarjeta Santander", label:"Santander",    emoji:"💳", color:"#EC0000", dia_corte:1,  dias_pago:20, perfil:"credito"},
];
const PERFILES_TARJETA=[
  {id:"negocios",   label:"Amex Negocios",     dias:20, desc:"Business / Gold / Platinum Business — corte + 20 días"},
  {id:"corporativa",label:"Amex Corporativa",  dias:9,  desc:"Corporate Card (persona moral) — corte + 9 días"},
  {id:"credito",    label:"Crédito bancaria",  dias:20, desc:"Tarjeta de crédito estándar MX — corte + 20 días"},
];
// Paletas para sucursales nuevas (cuando se agreguen desde el panel)
const SUC_COLORS=["#E8175D","#1565C0","#2E7D32","#F57F17","#6A1B9A","#00838F","#5D4037","#C62828"];
const SUC_EMOJIS=["🍓","🍦","🧁","🍰","🥐","🍪","🍨","🍫"];

const todayISO=()=>new Date().toISOString().slice(0,10);
const fmtMXN=(n)=>n!=null?`$${Number(n).toLocaleString("es-MX")}`:"—";
const monthKey=(d)=>d?.slice(0,7)??"";
const monthLabel=(k)=>{
  if(!k)return"";
  const[y,m]=k.split("-");
  const ns=["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"];
  return`${ns[+m-1]} ${y}`;
};
const addDays=(iso,n)=>{const d=new Date(iso);d.setDate(d.getDate()+n);return d.toISOString().slice(0,10);};
const diasEntre=(a,b)=>Math.round((new Date(b)-new Date(a))/86400000);
const fmtFechaCorta=(iso)=>{
  if(!iso)return"—";
  const[y,m,d]=iso.split("-").map(Number);
  const ms=["ene","feb","mar","abr","may","jun","jul","ago","sep","oct","nov","dic"];
  return`${d} ${ms[m-1]}`;
};
// Próxima fecha de corte a partir de una fecha de compra (respeta meses cortos)
const proximoCorte=(iso,diaCorte)=>{
  if(!iso||!diaCorte)return null;
  const[y,m,d]=iso.split("-").map(Number);
  const ultimoDia=(yy,mm)=>new Date(yy,mm,0).getDate();
  const corteEn=(yy,mm)=>Math.min(diaCorte,ultimoDia(yy,mm));
  let yy=y,mm=m;
  if(d>corteEn(y,m)){mm++;if(mm>12){mm=1;yy++;}}
  return`${yy}-${String(mm).padStart(2,"0")}-${String(corteEn(yy,mm)).padStart(2,"0")}`;
};
// Fecha límite de pago = corte + días de pago de esa tarjeta
const vencimientoTarjeta=(isoCompra,t)=>{
  const c=proximoCorte(isoCompra,t?.dia_corte);
  return c?addDays(c,parseInt(t.dias_pago)||0):null;
};
// Días reales de crédito que te dio la compra (varían según dónde caiga en el ciclo)
const creditoRealDias=(isoCompra,t)=>{
  const v=vencimientoTarjeta(isoCompra,t);
  return v?diasEntre(isoCompra,v):0;
};
const lsLoad=(k)=>{try{return JSON.parse(localStorage.getItem(k)||"[]");}catch{return[];}};
const num=(v)=>{const n=parseFloat(v);return isNaN(n)?0:n;};
// Normaliza texto: sin acentos, minúsculas, sin espacios extras
const norm=(s)=>(s||"").toString().normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase().trim();
const lsSave=(k,d)=>{try{localStorage.setItem(k,JSON.stringify(d));}catch{}};

const exportExcel=(gastos,ventas,recolecciones,mk,sucursales=[],sucursalId=null,cats=CATS_DEFAULT)=>{
  const cl=(id)=>cats.find(c=>c.id===id)?.label??id;
  const sucName=(id)=>sucursales.find(s=>s.id===id)?.nombre||"—";
  // Si viene sucursalId, filtra todo a esa sucursal
  const fSuc=(arr)=>sucursalId?arr.filter(x=>x.sucursal_id===sucursalId):arr;
  const lista=fSuc(gastos).filter(g=>!mk||monthKey(g.fecha)===mk).sort((a,b)=>a.fecha.localeCompare(b.fecha));
  const wsD=XLSX.utils.json_to_sheet(lista.map(g=>({
    "Fecha":g.fecha,"Sucursal":sucName(g.sucursal_id),"Concepto":g.concepto,"Categoría":cl(g.cat),
    "Monto ($)":g.monto,"Forma de Pago":g.forma,"Tipo de Pago":g.tipo_pago||"",
    "Días Crédito":g.dias_credito||"","Vence":g.fecha_vencimiento||"","Pagado":g.pagado?"Sí":"No",
    "Fecha Pago":g.fecha_pago||"","Cajas":g.cajas||"","Kg":g.kg||"","$ por Caja":g.precio_caja||"",
    "Quién":g.quien||"","Nota":g.nota||"",
  })));
  wsD["!cols"]=[{wch:12},{wch:14},{wch:28},{wch:20},{wch:11},{wch:18},{wch:14},{wch:12},{wch:12},{wch:8},{wch:12},{wch:8},{wch:8},{wch:11},{wch:14},{wch:22}];
  const totC={},totG=lista.reduce((s,g)=>s+num(g.monto),0);
  lista.forEach(g=>{totC[g.cat]=(totC[g.cat]||0)+g.monto;});
  const rRows=cats.filter(c=>totC[c.id]).sort((a,b)=>totC[b.id]-totC[a.id])
    .map(c=>({Categoría:c.label,"Monto ($)":totC[c.id],"% del Total":totG?+((totC[c.id]/totG)*100).toFixed(1):0}));
  rRows.push({Categoría:"TOTAL","Monto ($)":totG,"% del Total":100});
  const wsR=XLSX.utils.json_to_sheet(rRows);
  // Por sucursal (sólo si NO se está filtrando por una específica)
  let wsS=null;
  if(!sucursalId && sucursales.length>0){
    const porSuc={};
    lista.forEach(g=>{const k=sucName(g.sucursal_id);porSuc[k]=(porSuc[k]||0)+num(g.monto);});
    const sRows=Object.entries(porSuc).sort((a,b)=>b[1]-a[1])
      .map(([n,v])=>({Sucursal:n,"Gastos ($)":v,"% del Total":totG?+((v/totG)*100).toFixed(1):0}));
    sRows.push({Sucursal:"TOTAL","Gastos ($)":totG,"% del Total":100});
    wsS=XLSX.utils.json_to_sheet(sRows);
  }
  const vLista=fSuc(ventas).filter(v=>!mk||monthKey(v.fecha)===mk).sort((a,b)=>a.fecha.localeCompare(b.fecha));
  const wsV=XLSX.utils.json_to_sheet(vLista.map(v=>({"Fecha":v.fecha,"Sucursal":sucName(v.sucursal_id),"Efectivo ($)":v.efectivo,"Registró":v.quien||"","Nota":v.nota||""})));
  const rLista=fSuc(recolecciones);
  const wsC=XLSX.utils.json_to_sheet(rLista.map(r=>({"Fecha":r.fecha_recoleccion,"Sucursal":sucName(r.sucursal_id),"Monto ($)":r.monto_total,"Monto Físico ($)":r.monto_fisico??"","Faltante ($)":r.faltante??"","Quién":r.quien||"","Nota":r.nota||""})));
  // Hoja Fresa: unidad económica (kilos y $/kg) de las compras registradas con cajas
  const fresa=lista.filter(g=>num(g.kg)>0);
  let wsF=null;
  if(fresa.length>0){
    const fRows=fresa.map(g=>({
      "Fecha":g.fecha,"Sucursal":sucName(g.sucursal_id),"Proveedor":g.concepto,
      "Tipo Caja (kg)":g.tipo_caja||"","Cajas":num(g.cajas),"Kilos":num(g.kg),
      "$ por Caja":num(g.precio_caja),"$ por Kilo":num(g.kg)?+(num(g.monto)/num(g.kg)).toFixed(2):0,
      "Total ($)":num(g.monto),
    }));
    const tKg=fresa.reduce((s,g)=>s+num(g.kg),0),tMonto=fresa.reduce((s,g)=>s+num(g.monto),0);
    fRows.push({"Fecha":"TOTAL","Cajas":fresa.reduce((s,g)=>s+num(g.cajas),0),"Kilos":tKg,
      "$ por Kilo":tKg?+(tMonto/tKg).toFixed(2):0,"Total ($)":tMonto});
    wsF=XLSX.utils.json_to_sheet(fRows);
    wsF["!cols"]=[{wch:12},{wch:14},{wch:22},{wch:13},{wch:8},{wch:9},{wch:11},{wch:11},{wch:12}];
  }
  const wb=XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb,wsD,"Gastos");
  XLSX.utils.book_append_sheet(wb,wsR,"Por Categoría");
  if(wsF)XLSX.utils.book_append_sheet(wb,wsF,"Fresa");
  if(wsS)XLSX.utils.book_append_sheet(wb,wsS,"Por Sucursal");
  XLSX.utils.book_append_sheet(wb,wsV,"Ventas");
  XLSX.utils.book_append_sheet(wb,wsC,"Recolecciones");
  const sufijo=sucursalId?`_${sucName(sucursalId).replace(/\s+/g,"_")}`:"";
  XLSX.writeFile(wb,`LadyFresa_${mk?monthLabel(mk).replace(" ","_"):"Todos"}${sufijo}.xlsx`);
};

const FORM0={fecha:todayISO(),cat:"",monto:"",concepto:"",forma:"Efectivo",tipo_pago:"contado",dias_credito:"",quien:"",nota:"",foto:null,sucursal_id:null};
const VFORM0={fecha:todayISO(),efectivo:"",quien:"",nota:"",sucursal_id:null};
const RFORM0={fecha_recoleccion:todayISO(),quien:"",nota:"",selDias:[],monto_fisico:"",quien_faltante:"",sucursal_id:null};
// Compra de fresa: una o más "líneas" (tipo de caja + precio) y el reparto por sucursal
const nuevaLinea=(tipo="6")=>({tipo,precio:"",cajas:{},cortesia:false});
const FRESA0={fecha:todayISO(),proveedor:"",lineas:[nuevaLinea("6")],forma:"Efectivo",tipo_pago:"contado",dias_credito:"",quien:"",nota:"",foto:null};

export default function App(){
  const[view,setView]=useState("inicio");
  const[gastos,setGastos]=useState([]);
  const[ventas,setVentas]=useState([]);
  const[recolecciones,setRecolecciones]=useState([]);
  const[sucursales,setSucursales]=useState([]);
  const[cats,setCats]=useState(CATS_DEFAULT);
  // sucursalActiva: null = todas. Persistida en localStorage.
  const[sucursalActiva,setSucursalActivaState]=useState(()=>{
    const v=localStorage.getItem("lf_sucursal_activa");
    return v?parseInt(v):null;
  });
  const setSucursalActiva=(id)=>{
    setSucursalActivaState(id);
    if(id==null)localStorage.removeItem("lf_sucursal_activa");
    else localStorage.setItem("lf_sucursal_activa",String(id));
  };
  const[loading,setLoading]=useState(true);
  const[usuarioActual,setUsuarioActual]=useState(()=>localStorage.getItem("lf_usuario")||null);
  const[selMonth,setSelMonth]=useState(null);
  const[selRec,setSelRec]=useState(null);
  const[selVentaDia,setSelVentaDia]=useState(null);
  const[filtroQ,setFiltroQ]=useState("todos");
  const[resMK,setResMK]=useState(null); // null = mes actual
  const[resCat,setResCat]=useState("todos");
  const[resBuscar,setResBuscar]=useState("");
  const[resDesde,setResDesde]=useState("");
  const[resHasta,setResHasta]=useState("");
  const[resFiltrosOpen,setResFiltrosOpen]=useState(false);
  const[resTab,setResTab]=useState("resumen"); // resumen | gastos | recolecciones
  const[showMonthPicker,setShowMonthPicker]=useState(false);
  const[error,setError]=useState(null);
  const[pinUsuario,setPinUsuario]=useState(null); // usuario pendiente de PIN
  const[pinInput,setPinInput]=useState("");
  const[pinError,setPinError]=useState(false);
  const[form,setForm]=useState(FORM0);
  const[editandoId,setEditandoId]=useState(null);
  const[vForm,setVForm]=useState(VFORM0);
  const[rForm,setRForm]=useState(RFORM0);
  const[editRecForm,setEditRecForm]=useState(null);
  const[comentario,setComentario]=useState("");
  const[saved,setSaved]=useState(false);
  const[vSaved,setVSaved]=useState(false);
  const[rSaved,setRSaved]=useState(false);
  const[catErr,setCatErr]=useState(false);
  const[uploadingFoto,setUploadingFoto]=useState(false);
  const[pagoForm,setPagoForm]=useState(null); // {id, forma, fecha, nota}
  const[tarjetas,setTarjetas]=useState(()=>{
    try{const v=JSON.parse(localStorage.getItem("lf_tarjetas")||"null");return Array.isArray(v)&&v.length?v:TARJETAS_DEFAULT;}
    catch{return TARJETAS_DEFAULT;}
  });
  const[fForm,setFForm]=useState(FRESA0);
  const[fSaved,setFSaved]=useState(false);
  const fileRef=useRef();
  const camaraRef=useRef();

  // ── TARJETAS (config de corte / días de pago) ─────────────────────────────
  const tarjetaDe=(forma)=>tarjetas.find(t=>t.forma===forma)||null;
  const fetchT=async()=>{
    const{data,error}=await sb.from("app_config").select("valor").eq("clave","tarjetas").maybeSingle();
    if(!error&&data?.valor&&Array.isArray(data.valor)&&data.valor.length){
      setTarjetas(data.valor);lsSave("lf_tarjetas",data.valor);
    }
  };
  const saveTarjetas=async(nuevas)=>{
    setTarjetas(nuevas);lsSave("lf_tarjetas",nuevas);
    // Si la tabla app_config no existe todavía, queda guardado en el dispositivo
    await sb.from("app_config").upsert({clave:"tarjetas",valor:nuevas},{onConflict:"clave"});
  };

  // ── SUPABASE ─────────────────────────────────────────────────────────────
  const fetchG=async()=>{const{data}=await sb.from("gastos").select("*").order("fecha",{ascending:false});if(data)setGastos(data);};
  const fetchV=async()=>{const{data}=await sb.from("ventas").select("*").order("fecha",{ascending:false});if(data)setVentas(data);};
  const fetchR=async()=>{const{data}=await sb.from("recolecciones").select("*").order("created_at",{ascending:false});if(data)setRecolecciones(data);};
  const fetchS=async()=>{const{data}=await sb.from("sucursales").select("*").order("orden",{ascending:true});if(data)setSucursales(data);};
  const fetchC=async()=>{
    const{data}=await sb.from("categorias").select("*").order("orden",{ascending:true});
    if(data&&data.length>0)setCats(data.map(catRowToObj));
  };

  // Auto-seleccionar quien=usuarioActual cuando alguien abre el form de recolección
  useEffect(()=>{
    if(view==="recoleccion"&&usuarioActual){
      setRForm(f=>f.quien===usuarioActual?f:{...f,quien:usuarioActual});
    }
  },[view,usuarioActual]);

  // Aplicar sucursalActiva como default en los formularios cuando se abren
  useEffect(()=>{
    if(view==="nuevo"&&sucursalActiva!=null){
      setForm(f=>f.sucursal_id?f:{...f,sucursal_id:sucursalActiva});
    }
    if(view==="ventas"&&sucursalActiva!=null){
      setVForm(f=>f.sucursal_id?f:{...f,sucursal_id:sucursalActiva});
    }
    if(view==="recoleccion"&&sucursalActiva!=null){
      setRForm(f=>f.sucursal_id?f:{...f,sucursal_id:sucursalActiva});
    }
  },[view,sucursalActiva]);

  // Si la forma de pago es una tarjeta configurada, el crédito se calcula solo
  // (desde la fecha de corte, no desde la fecha de compra)
  useEffect(()=>{
    const t=tarjetaDe(form.forma);
    if(!t||!form.fecha)return;
    const dias=String(creditoRealDias(form.fecha,t));
    setForm(f=>(f.tipo_pago==="credito"&&f.dias_credito===dias)?f:{...f,tipo_pago:"credito",dias_credito:dias});
  },[form.forma,form.fecha,tarjetas]);

  useEffect(()=>{
    const t=tarjetaDe(fForm.forma);
    if(!t||!fForm.fecha)return;
    const dias=String(creditoRealDias(fForm.fecha,t));
    setFForm(f=>(f.tipo_pago==="credito"&&f.dias_credito===dias)?f:{...f,tipo_pago:"credito",dias_credito:dias});
  },[fForm.forma,fForm.fecha,tarjetas]);

  useEffect(()=>{
    (async()=>{setLoading(true);await Promise.all([fetchG(),fetchV(),fetchR(),fetchS(),fetchC(),fetchT()]);setLoading(false);})();
    const uid=Math.random().toString(36).slice(2);
    const chG=sb.channel("g-"+uid).on("postgres_changes",{event:"*",schema:"public",table:"gastos"},fetchG).subscribe();
    const chV=sb.channel("v-"+uid).on("postgres_changes",{event:"*",schema:"public",table:"ventas"},fetchV).subscribe();
    const chR=sb.channel("r-"+uid).on("postgres_changes",{event:"*",schema:"public",table:"recolecciones"},fetchR).subscribe();
    const chS=sb.channel("s-"+uid).on("postgres_changes",{event:"*",schema:"public",table:"sucursales"},fetchS).subscribe();
    const chC=sb.channel("c-"+uid).on("postgres_changes",{event:"*",schema:"public",table:"categorias"},fetchC).subscribe();
    return()=>{sb.removeChannel(chG);sb.removeChannel(chV);sb.removeChannel(chR);sb.removeChannel(chS);sb.removeChannel(chC);};
  },[]);

  // ── FOTO UPLOAD ───────────────────────────────────────────────────────────
  const handleFoto=async(e)=>{
    const file=e.target.files[0];if(!file)return;
    setUploadingFoto(true);
    const ext=file.name.split(".").pop().toLowerCase();
    const path=`tickets/${Date.now()}.${ext}`;
    const{error:ue}=await sb.storage.from("tickets").upload(path,file,{contentType:file.type});
    if(ue){setError("Error foto: "+ue.message);setUploadingFoto(false);return;}
    const{data}=sb.storage.from("tickets").getPublicUrl(path);
    // Para PDFs guardamos la URL igual, la vista distingue por extensión
    setForm(f=>({...f,foto:data.publicUrl,fotoEsPdf:file.type==="application/pdf"}));
    setUploadingFoto(false);
    // Limpiar el input para permitir subir el mismo archivo otra vez
    e.target.value="";
  };

  // ── GASTOS ────────────────────────────────────────────────────────────────
  const promedios={};
  cats.forEach(c=>{const ms=gastos.filter(g=>g.cat===c.id).map(g=>g.monto);if(ms.length>1)promedios[c.id]=ms.reduce((s,m)=>s+m,0)/ms.length;});
  const esInusual=(cat,monto)=>promedios[cat]&&monto>promedios[cat]*2.5;

  const saveGasto=async()=>{
    if(!form.cat){setCatErr(true);setTimeout(()=>setCatErr(false),2000);return;}
    if(!form.monto||!form.concepto)return;
    if(!form.sucursal_id){setError("Selecciona una sucursal");setTimeout(()=>setError(null),3000);return;}
    // Si Apolo, forzar quien=Apolo
    const quienFinal=usuarioActual==="Apolo"?"Apolo":(form.quien||usuarioActual||"");
    const dias=parseInt(form.dias_credito)||0;
    const tj=tarjetaDe(form.forma);
    // Con tarjeta el vencimiento sale de la fecha de corte; si no, son días desde la compra
    const vence=form.tipo_pago!=="credito"?null
      :tj?vencimientoTarjeta(form.fecha,tj)
      :dias?addDays(form.fecha,dias):null;
    const payload={
      fecha:form.fecha,concepto:form.concepto,cat:form.cat,
      monto:parseFloat(form.monto),forma:form.forma,tipo_pago:form.tipo_pago,
      dias_credito:dias||null,
      fecha_vencimiento:vence,
      pagado:form.tipo_pago==="contado",
      quien:quienFinal,nota:form.nota,foto:form.foto,
      sucursal_id:form.sucursal_id,
    };
    let e;
    if(editandoId){({error:e}=await sb.from("gastos").update(payload).eq("id",editandoId));}
    else{({error:e}=await sb.from("gastos").insert([payload]));}
    if(e){setError("Error: "+e.message);return;}
    await fetchG();
    setSaved(true);
    setTimeout(()=>{setSaved(false);setEditandoId(null);setForm(FORM0);setView("inicio");},1200);
  };

  // ── COMPRA DE FRESA ───────────────────────────────────────────────────────
  const KG_CAJA={"6":6,"4":4};
  const cajasLinea=(l)=>Object.values(l.cajas||{}).reduce((s,n)=>s+(parseInt(n)||0),0);
  const totalLinea=(l)=>l.cortesia?0:cajasLinea(l)*num(l.precio);
  const kgLinea=(l)=>cajasLinea(l)*(KG_CAJA[l.tipo]||0);
  const cajasSucLinea=(l,sid)=>parseInt(l.cajas?.[sid])||0;
  const totalFresa=fForm.lineas.reduce((s,l)=>s+totalLinea(l),0);
  const kgFresa=fForm.lineas.reduce((s,l)=>s+kgLinea(l),0);
  const cajasFresa=fForm.lineas.reduce((s,l)=>s+cajasLinea(l),0);
  const totalFresaSuc=(sid)=>fForm.lineas.reduce((s,l)=>s+(l.cortesia?0:cajasSucLinea(l,sid)*num(l.precio)),0);
  const kgFresaSuc=(sid)=>fForm.lineas.reduce((s,l)=>s+cajasSucLinea(l,sid)*(KG_CAJA[l.tipo]||0),0);
  const cajasFresaSuc=(sid)=>fForm.lineas.reduce((s,l)=>s+cajasSucLinea(l,sid),0);
  const setLinea=(i,patch)=>setFForm(f=>({...f,lineas:f.lineas.map((l,ix)=>ix===i?{...l,...patch}:l)}));
  const setCajas=(i,sid,n)=>setFForm(f=>({...f,lineas:f.lineas.map((l,ix)=>
    ix===i?{...l,cajas:{...l.cajas,[sid]:Math.max(0,n)}}:l)}));
  // Último precio pagado por tipo de caja (para sugerirlo de un toque)
  const ultimoPrecioCaja=(tipo)=>{
    const g=gastos.find(x=>x.tipo_caja===tipo&&num(x.precio_caja)>0);
    if(g)return num(g.precio_caja);
    const ls=num(localStorage.getItem("lf_precio_caja_"+tipo));
    return ls>0?ls:null;
  };
  const proveedoresFresa=[...new Set(gastos.filter(g=>g.cat==="fruta").map(g=>g.concepto))].filter(Boolean).slice(0,4);

  const saveFresa=async()=>{
    if(cajasFresa===0){setError("Agrega al menos una caja");setTimeout(()=>setError(null),3000);return;}
    const sinPrecio=fForm.lineas.some(l=>cajasLinea(l)>0&&!l.cortesia&&num(l.precio)<=0);
    if(sinPrecio){setError("Falta el precio por caja");setTimeout(()=>setError(null),3000);return;}
    const quienFinal=usuarioActual==="Apolo"?"Apolo":(fForm.quien||usuarioActual||"");
    const tj=tarjetaDe(fForm.forma);
    const dias=parseInt(fForm.dias_credito)||0;
    const vence=fForm.tipo_pago!=="credito"?null
      :tj?vencimientoTarjeta(fForm.fecha,tj)
      :dias?addDays(fForm.fecha,dias):null;
    const grupo="fresa-"+Date.now();
    const concepto=fForm.proveedor?.trim()||"Compra de fresa";
    // Un gasto por sucursal: así el costo queda repartido correcto en el P&L
    const rows=sucActivas.filter(s=>cajasFresaSuc(s.id)>0).map(s=>{
      const detalle=fForm.lineas.filter(l=>cajasSucLinea(l,s.id)>0).map(l=>
        `${cajasSucLinea(l,s.id)} caja${cajasSucLinea(l,s.id)!==1?"s":""} de ${l.tipo}kg`+
        (l.cortesia?" (cortesía)":` @ ${fmtMXN(num(l.precio))}`)).join(" + ");
      const kg=kgFresaSuc(s.id),monto=totalFresaSuc(s.id);
      return{
        fecha:fForm.fecha,concepto,cat:"fruta",monto,
        forma:fForm.forma,tipo_pago:fForm.tipo_pago,
        dias_credito:dias||null,fecha_vencimiento:vence,
        pagado:fForm.tipo_pago==="contado",
        quien:quienFinal,sucursal_id:s.id,foto:fForm.foto,
        nota:`🍓 ${detalle} · ${kg} kg`+(monto>0?` · ${fmtMXN(+(monto/kg).toFixed(2))}/kg`:"")+(fForm.nota?`\n${fForm.nota}`:""),
        // Columnas nuevas (si aún no existen en Supabase, se guarda igual sin ellas)
        cajas:cajasFresaSuc(s.id),kg,
        precio_caja:num(fForm.lineas.find(l=>cajasSucLinea(l,s.id)>0)?.precio)||null,
        tipo_caja:fForm.lineas.find(l=>cajasSucLinea(l,s.id)>0)?.tipo||null,
        grupo,
      };
    });
    let{error:e}=await sb.from("gastos").insert(rows);
    if(e){ // Fallback: la migración de columnas nuevas todavía no se corre
      const base=rows.map(({cajas,kg,precio_caja,tipo_caja,grupo,...r})=>r);
      ({error:e}=await sb.from("gastos").insert(base));
    }
    if(e){setError("Error: "+e.message);return;}
    fForm.lineas.forEach(l=>{if(!l.cortesia&&num(l.precio)>0)lsSave("lf_precio_caja_"+l.tipo,num(l.precio));});
    await fetchG();
    setFSaved(true);
    setTimeout(()=>{setFSaved(false);setFForm({...FRESA0,fecha:todayISO(),lineas:[nuevaLinea("6")]});setView("inicio");},1200);
  };

  const startEdit=(g)=>{
    if(usuarioActual!=="Andres"&&g.quien!==usuarioActual)return;
    setForm({fecha:g.fecha,cat:g.cat,monto:String(g.monto),concepto:g.concepto,
      forma:g.forma||"Efectivo",tipo_pago:g.tipo_pago||"contado",
      dias_credito:g.dias_credito?String(g.dias_credito):"",
      quien:g.quien||"",nota:g.nota||"",foto:g.foto||null,
      sucursal_id:g.sucursal_id||null});
    setEditandoId(g.id);
    setView("nuevo");
  };

  const deleteGasto=async(id)=>{
    const g=gastos.find(x=>x.id===id);
    if(usuarioActual==="Apolo")return;
    const esAdmin=usuarioActual==="Andres"||usuarioActual==="José Luis";
    if(!esAdmin&&g?.quien!==usuarioActual)return;
    await sb.from("gastos").delete().eq("id",id);
    const{data}=await sb.from("gastos").select("*").order("fecha",{ascending:false});
    if(data)setGastos(data);
  };

  const marcarPagado=async()=>{
    if(!pagoForm)return;
    await sb.from("gastos").update({
      pagado:true,tipo_pago:"contado",
      fecha_pago:pagoForm.fecha,
      forma:pagoForm.forma,
      nota:(gastos.find(g=>g.id===pagoForm.id)?.nota||"")+(pagoForm.nota?"\nPago: "+pagoForm.nota:""),
    }).eq("id",pagoForm.id);
    await fetchG();
    setPagoForm(null);
  };

  // ── VENTAS ────────────────────────────────────────────────────────────────
  const saveVenta=async()=>{
    if(!vForm.efectivo)return;
    if(!vForm.sucursal_id){setError("Selecciona una sucursal");setTimeout(()=>setError(null),3000);return;}
    const payload={efectivo:parseFloat(vForm.efectivo),quien:vForm.quien,nota:vForm.nota,sucursal_id:vForm.sucursal_id};
    // Buscar si ya existe por fecha + sucursal
    const{data:existing}=await sb.from("ventas").select("id").eq("fecha",vForm.fecha).eq("sucursal_id",vForm.sucursal_id).limit(1);
    let err;
    if(existing&&existing.length>0){
      // Actualizar el existente
      const{error:e}=await sb.from("ventas").update(payload).eq("id",existing[0].id);
      err=e;
    } else {
      // Insertar nuevo
      const{error:e}=await sb.from("ventas").insert([{...payload,fecha:vForm.fecha}]);
      err=e;
    }
    if(err){setError("Error: "+err.message);return;}
    const{data}=await sb.from("ventas").select("*").order("fecha",{ascending:false});
    if(data)setVentas(data);
    setVSaved(true);
    setTimeout(()=>{setVSaved(false);setVForm(VFORM0);setView("inicio");},1200);
  };

  // ── RECOLECCIONES ─────────────────────────────────────────────────────────
  const saveRecoleccion=async()=>{
    // Forzar quien=usuarioActual si es Apolo (no toca chips)
    const quienFinal=usuarioActual==="Apolo"?"Apolo":rForm.quien;
    if(!rForm.sucursal_id){setError("Selecciona una sucursal");setTimeout(()=>setError(null),3000);return;}
    if(!rForm.selDias.length){setError("Selecciona al menos un día para recolectar");setTimeout(()=>setError(null),3000);return;}
    if(!quienFinal){setError("Indica quién recolecta");setTimeout(()=>setError(null),3000);return;}
    // Los montos vienen de las ventas de ESA sucursal en esas fechas
    const montoTotal=rForm.selDias.reduce((s,f)=>{const v=ventas.find(v=>v.fecha===f&&v.sucursal_id===rForm.sucursal_id);return s+num(v?.efectivo);},0);
    const montoFisico=rForm.monto_fisico?parseFloat(rForm.monto_fisico):null;
    const faltante=montoFisico!=null?Math.max(0,montoTotal-montoFisico):0;
    const requiereAprobacion=quienFinal==="Apolo";
    const payload={
      fecha_recoleccion:rForm.fecha_recoleccion,
      fechas_cubiertas:rForm.selDias,
      monto_total:montoTotal,
      monto_fisico:montoFisico,
      faltante:faltante||null,
      quien:quienFinal,
      quien_faltante:faltante>0?(rForm.quien_faltante||quienFinal):null,
      nota:rForm.nota,
      aprobada:requiereAprobacion?false:true,
      aprobada_por:requiereAprobacion?null:"auto",
      sucursal_id:rForm.sucursal_id,
    };
    const{error:e}=await sb.from("recolecciones").insert([payload]);
    if(e){setError("Error: "+e.message);return;}
    const{data}=await sb.from("recolecciones").select("*").order("created_at",{ascending:false});
    if(data)setRecolecciones(data);
    setRSaved(true);
    setTimeout(()=>{setRSaved(false);setRForm(RFORM0);},1200);
  };

  const updateRecoleccion=async(id,updates)=>{
    const{error:e}=await sb.from("recolecciones").update(updates).eq("id",id);
    if(e){setError("Error: "+e.message);return;}
    const{data}=await sb.from("recolecciones").select("*").order("created_at",{ascending:false});
    if(data){
      setRecolecciones(data);
      const updated=data.find(r=>r.id===id);
      if(updated)setSelRec(updated);
    }
    setEditRecForm(null);
  };
  const deleteRecoleccion=async(id)=>{
    const{error:e}=await sb.from("recolecciones").delete().eq("id",id);
    if(e){setError("Error: "+e.message);return;}
    const{data}=await sb.from("recolecciones").select("*").order("created_at",{ascending:false});
    if(data)setRecolecciones(data);
    setSelRec(null);
    setView("recoleccion");
  };
  const agregarComentario=async(id,notaActual)=>{
    const nueva=(notaActual?notaActual+"\n":"")+comentario;
    await sb.from("recolecciones").update({nota:nueva}).eq("id",id);
    await new Promise(r=>setTimeout(r,300));
    const{data}=await sb.from("recolecciones").select("*").order("created_at",{ascending:false});
    if(data){setRecolecciones(data);const updated=data.find(r=>r.id===id);if(updated)setSelRec(updated);}
    setComentario("");
  };

  // ── DATOS DERIVADOS ───────────────────────────────────────────────────────
  // Filtro por sucursal activa (null = todas)
  const filtroSuc=(arr)=>sucursalActiva==null?arr:arr.filter(x=>x.sucursal_id===sucursalActiva);
  const gastosF=filtroSuc(gastos);
  const ventasF=filtroSuc(ventas);
  const recoleccionesF=filtroSuc(recolecciones);
  // Helpers visuales
  const sucActivaObj=sucursales.find(s=>s.id===sucursalActiva)||null;
  const sucName=(id)=>sucursales.find(s=>s.id===id)?.nombre||"—";
  const sucEmoji=(id)=>sucursales.find(s=>s.id===id)?.emoji||"📍";
  const sucColor=(id)=>sucursales.find(s=>s.id===id)?.color||GRIS_MED;
  const sucActivasObj=sucursales.filter(s=>s.activa!==false);
  const sucActivas=sucActivasObj;
  // Helper: cuando viendo "Todas", devolver label para mostrar; si filtrando, devolver null
  const mkSucLabel=(sucId)=>{
    if(sucursalActiva!=null)return null; // viendo solo una, no hace falta etiquetar
    const s=sucursales.find(x=>x.id===sucId);
    if(!s)return null;
    return{nombre:s.nombre,emoji:s.emoji||"📍",color:s.color||GRIS_MED,bg:(s.color||GRIS_MED)+"18"};
  };

  const currentMK=monthKey(todayISO());
  const months=[...new Set(gastosF.map(g=>monthKey(g.fecha)))].filter(Boolean).sort().reverse();
  const gMes=(mk)=>gastosF.filter(g=>monthKey(g.fecha)===mk);
  const totG=(mk)=>gMes(mk).reduce((s,g)=>s+num(g.monto),0);
  const porCat=(mk)=>{const m={};gMes(mk).forEach(g=>{m[g.cat]=(m[g.cat]||0)+g.monto;});return m;};
  const porQuien=(mk)=>{
    const m={};
    gMes(mk).filter(g=>filtroQ==="todos"||g.quien===filtroQ).forEach(g=>{const k=g.quien||"Sin asignar";m[k]=(m[k]||0)+g.monto;});
    return m;
  };
  const diasConVenta=ventasF.map(v=>v.fecha);
  const diasRecolectados=recoleccionesF.flatMap(r=>r.fechas_cubiertas||[]);
  // Pendiente por (fecha, sucursal): un día puede estar pendiente en una sucursal y recolectado en otra
  const ventasFiltradasParaPend=ventasF;
  // Para cada venta filtrada, ver si su (fecha, sucursal_id) está cubierta por alguna recolección de la misma sucursal
  const pendVentaIds=ventasFiltradasParaPend.filter(v=>{
    const recosMismaSuc=recolecciones.filter(r=>r.sucursal_id===v.sucursal_id);
    return !recosMismaSuc.some(r=>(r.fechas_cubiertas||[]).includes(v.fecha));
  });
  // Lista de fechas (únicas) pendientes — usadas en pantallas de recolección cuando hay sucursal activa
  const diasPendientes=[...new Set(pendVentaIds.map(v=>v.fecha))].sort();
  const montoPendiente=pendVentaIds.reduce((s,v)=>s+num(v.efectivo),0);
  const todayG=gastosF.filter(g=>g.fecha===todayISO());
  const todayTG=todayG.reduce((s,g)=>s+num(g.monto),0);
  const todayV=ventasF.find(v=>v.fecha===todayISO());
  const creditosPendientes=gastosF.filter(g=>g.tipo_pago==="credito"&&!g.pagado);
  const recoleccionesPendientesAprobacion=recoleccionesF.filter(r=>r.quien==="Apolo"&&!r.aprobada);
  const vencidos=creditosPendientes.filter(g=>g.fecha_vencimiento&&g.fecha_vencimiento<todayISO());

  if(loading)return(
    <div style={{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",minHeight:"100vh",background:ROSA}}>
      <div style={{fontSize:56,marginBottom:16}}>🍓</div>
      <div style={{fontSize:22,fontWeight:900,color:BLANCO}}>Lady Fresa</div>
      <div style={{fontSize:13,color:"rgba(255,255,255,0.7)",marginTop:8}}>Conectando…</div>
    </div>
  );

  // ══════════════════════════════════════════════════════════════════════════
  // PANTALLA: SELECCIONAR USUARIO
  // ══════════════════════════════════════════════════════════════════════════
  if(!usuarioActual)return(
    <div style={{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",minHeight:"100vh",background:`linear-gradient(160deg,${ROSA},${ROSA_DARK})`,padding:24}}>
      <div style={{fontSize:56,marginBottom:8}}>🍓</div>
      <div style={{fontSize:26,fontWeight:900,color:BLANCO,marginBottom:4}}>Lady Fresa</div>
      <div style={{fontSize:14,color:"rgba(255,255,255,0.7)",marginBottom:36}}>¿Quién eres?</div>
      <div style={{width:"100%",maxWidth:320,display:"flex",flexDirection:"column",gap:12}}>
        {EQUIPO.map(nombre=>(
          <button key={nombre} onClick={()=>{
              if(PINES[nombre]){setPinUsuario(nombre);setPinInput("");setPinError(false);}
              else{localStorage.setItem("lf_usuario",nombre);setUsuarioActual(nombre);}
            }}
            style={{width:"100%",padding:"16px 0",borderRadius:16,
              border:nombre==="Apolo"?"2px solid #FFD700":PINES[nombre]?"2px solid rgba(255,255,255,0.6)":"2px solid rgba(255,255,255,0.3)",
              background:nombre==="Apolo"?"rgba(255,215,0,0.2)":PINES[nombre]?"rgba(255,255,255,0.25)":"rgba(255,255,255,0.15)",
              color:BLANCO,fontSize:17,fontWeight:800,
              cursor:"pointer",fontFamily:"inherit",backdropFilter:"blur(8px)",
              letterSpacing:0.3}}>
            {nombre==="Apolo"?"🧑 ":PINES[nombre]?"🔒 ":""}{nombre}{nombre==="Apolo"?" (Recolector)":""}
          </button>
        ))}
      </div>

      {/* PANTALLA PIN */}
      {pinUsuario&&(
        <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.6)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:200,padding:24}}>
          <div style={{background:BLANCO,borderRadius:24,padding:"32px 24px",width:"100%",maxWidth:320,textAlign:"center",boxShadow:"0 20px 60px rgba(0,0,0,0.3)"}}>
            <div style={{fontSize:40,marginBottom:8}}>🔒</div>
            <div style={{fontSize:18,fontWeight:900,color:GRIS_DARK,marginBottom:4}}>Código de acceso</div>
            <div style={{fontSize:13,color:GRIS_TEXT,marginBottom:24}}>Ingresa el PIN de <strong>{pinUsuario}</strong></div>
            {/* Mostrar puntos */}
            <div style={{display:"flex",justifyContent:"center",gap:14,marginBottom:24}}>
              {[0,1,2,3].map(i=>(
                <div key={i} style={{width:16,height:16,borderRadius:"50%",
                  background:pinInput.length>i?ROSA:"#E0E0E0",
                  transition:"background 0.15s"}}/>
              ))}
            </div>
            {pinError&&<div style={{fontSize:12,color:"#E53935",fontWeight:700,marginBottom:12}}>❌ PIN incorrecto, intenta de nuevo</div>}
            {/* Teclado numérico */}
            <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:10,marginBottom:12}}>
              {["1","2","3","4","5","6","7","8","9","","0","⌫"].map((k,i)=>(
                <button key={i} disabled={k===""} onClick={()=>{
                  if(k==="⌫"){setPinInput(p=>p.slice(0,-1));setPinError(false);}
                  else{
                    const nuevo=pinInput+k;
                    setPinInput(nuevo);
                    if(nuevo.length===4){
                      if(nuevo===PINES[pinUsuario]){
                        localStorage.setItem("lf_usuario",pinUsuario);
                        setUsuarioActual(pinUsuario);
                        setPinUsuario(null);setPinInput("");
                      } else {
                        setPinError(true);
                        setTimeout(()=>setPinInput(""),600);
                      }
                    }
                  }
                }}
                  style={{padding:"18px 0",borderRadius:14,border:"1.5px solid #E8E8E8",
                    background:k===""?"transparent":GRIS_LIGHT,fontSize:20,fontWeight:700,
                    color:GRIS_DARK,cursor:k===""?"default":"pointer",fontFamily:"inherit",
                    opacity:k===""?0:1}}>
                  {k}
                </button>
              ))}
            </div>
            <button onClick={()=>{setPinUsuario(null);setPinInput("");setPinError(false);}}
              style={{width:"100%",padding:"12px 0",borderRadius:12,border:"1.5px solid #E0E0E0",
                background:GRIS_LIGHT,color:GRIS_MED,fontSize:14,fontWeight:700,cursor:"pointer",fontFamily:"inherit"}}>
              Cancelar
            </button>
          </div>
        </div>
      )}
    </div>
  );

  // ══════════════════════════════════════════════════════════════════════════
  // VISTA: NUEVO / EDITAR GASTO
  // ══════════════════════════════════════════════════════════════════════════
  if(view==="nuevo")return(
    <Screen title={editandoId?"Editar Gasto":"Nuevo Gasto"}
      onBack={()=>{setEditandoId(null);setForm(FORM0);setView("inicio");}}>

      <FL>📍 Sucursal *</FL>
      <SucursalChips sucursales={sucActivas} value={form.sucursal_id}
        onChange={(id)=>setForm(f=>({...f,sucursal_id:id}))}/>

      <FL>Fecha</FL>
      <input type="date" style={S.input} value={form.fecha} onChange={e=>setForm(f=>({...f,fecha:e.target.value}))}/>

      <FL>{catErr?<span style={{color:"#E53935"}}>Categoría * ← elige una</span>:"Categoría *"}</FL>
      <div style={{...S.catGrid,border:catErr?"2px solid #E53935":"none",borderRadius:14,padding:catErr?6:0}}>
        {cats.filter(c=>c.id===form.cat||(c.activa!==false&&(c.sucursal_id==null||c.sucursal_id===form.sucursal_id))).map(c=>(
          <button key={c.id} onClick={()=>{setForm(f=>({...f,cat:c.id}));setCatErr(false);}}
            style={{...S.catBtn,background:form.cat===c.id?c.color:GRIS_LIGHT,
              color:form.cat===c.id?BLANCO:GRIS_MED,
              border:`2px solid ${form.cat===c.id?c.color:"#E0E0E0"}`,
              transform:form.cat===c.id?"scale(1.06)":"scale(1)"}}>
            <span style={{fontSize:22}}>{c.emoji}</span>
            <span style={{fontSize:9,marginTop:3,textAlign:"center",lineHeight:1.2,fontWeight:600}}>{c.label}</span>
          </button>
        ))}
      </div>

      <FL>Proveedor / Concepto *</FL>
      {(()=>{
        const sugs=[...new Set(gastos.map(g=>g.concepto))].filter(c=>c&&form.concepto&&c.toLowerCase().includes(form.concepto.toLowerCase())&&c!==form.concepto).slice(0,4);
        return(
          <div style={{position:"relative"}}>
            <input style={S.input} placeholder="Ej: Fresa mx, Central Abastos…" value={form.concepto}
              onChange={e=>setForm(f=>({...f,concepto:e.target.value}))}/>
            {sugs.length>0&&(
              <div style={{position:"absolute",top:"100%",left:0,right:0,background:BLANCO,borderRadius:10,
                boxShadow:"0 4px 16px rgba(0,0,0,0.12)",zIndex:50,overflow:"hidden"}}>
                {sugs.map(s=>(
                  <button key={s} onClick={()=>setForm(f=>({...f,concepto:s}))}
                    style={{display:"block",width:"100%",textAlign:"left",padding:"11px 14px",
                      border:"none",borderBottom:"1px solid #F5F5F5",background:BLANCO,
                      cursor:"pointer",fontSize:14,color:GRIS_DARK,fontFamily:"inherit"}}>
                    🔍 {s}
                  </button>
                ))}
              </div>
            )}
          </div>
        );
      })()}

      <FL>Monto ($) *</FL>
      <div style={{position:"relative"}}>
        <span style={{position:"absolute",left:14,top:"50%",transform:"translateY(-50%)",fontSize:20,fontWeight:800,color:form.monto?ROSA:"#CCC"}}>$</span>
        <input type="number" inputMode="decimal"
          style={{...S.input,paddingLeft:32,fontSize:26,fontWeight:800,color:ROSA}}
          placeholder="0" value={form.monto} onChange={e=>setForm(f=>({...f,monto:e.target.value}))}/>
      </div>
      {form.cat&&form.monto&&esInusual(form.cat,parseFloat(form.monto))&&(
        <div style={S.alertaBanner}>⚠️ Monto inusualmente alto para esta categoría</div>
      )}

      <FL>Tipo de pago *</FL>
      <div style={{display:"flex",gap:8,marginBottom:4}}>
        {[
          {id:"contado",label:"Contado",emoji:"✅",color:VERDE,desc:"Pago inmediato"},
          {id:"credito",label:"Crédito",emoji:"⏳",color:AMBAR,desc:"Se paga después"},
          {id:"cuenta",label:"A cuenta",emoji:"🔄",color:AZUL,desc:"Reembolso pendiente"},
        ].map(t=>(
          <button key={t.id} onClick={()=>setForm(f=>({...f,tipo_pago:t.id}))}
            style={{flex:1,padding:"10px 4px",borderRadius:12,cursor:"pointer",fontFamily:"inherit",
              border:`2px solid ${form.tipo_pago===t.id?t.color:"#E0E0E0"}`,
              background:form.tipo_pago===t.id?t.color+"18":GRIS_LIGHT,textAlign:"center"}}>
            <div style={{fontSize:20}}>{t.emoji}</div>
            <div style={{fontSize:10,fontWeight:800,color:form.tipo_pago===t.id?t.color:GRIS_MED,marginTop:2}}>{t.label}</div>
            <div style={{fontSize:9,color:GRIS_TEXT}}>{t.desc}</div>
          </button>
        ))}
      </div>

      {form.tipo_pago==="credito"&&tarjetaDe(form.forma)&&(
        <TarjetaCreditoBox t={tarjetaDe(form.forma)} fecha={form.fecha}
          onConfig={PUEDE_VER_NUMEROS.includes(usuarioActual)?()=>setView("admin-tarjetas"):null}/>
      )}

      {form.tipo_pago==="credito"&&!tarjetaDe(form.forma)&&(
        <>
          <FL>Días de crédito</FL>
          <div style={{display:"flex",gap:8,flexWrap:"wrap",marginBottom:4}}>
            {["7","14","30","60"].map(d=>(
              <Chip key={d} active={form.dias_credito===d} color={AMBAR}
                onClick={()=>setForm(f=>({...f,dias_credito:d}))}>{d} días</Chip>
            ))}
          </div>
          <input type="number" inputMode="numeric" style={S.input}
            placeholder="O escribe los días…" value={form.dias_credito}
            onChange={e=>setForm(f=>({...f,dias_credito:e.target.value}))}/>
          {form.dias_credito&&form.fecha&&(
            <div style={{...S.infoBox,marginTop:6}}>
              📅 Vence el: <strong>{addDays(form.fecha,parseInt(form.dias_credito)||0)}</strong>
            </div>
          )}
        </>
      )}

      <FL>Forma de pago</FL>
      <div style={S.chipRow}>{FORMA_OPTS.map(o=>(
        <Chip key={o} active={form.forma===o} color={tarjetaDe(o)?AZUL:ROSA}
          onClick={()=>setForm(f=>({...f,forma:o,...(tarjetaDe(o)?{}:{tipo_pago:f.tipo_pago==="credito"&&tarjetaDe(f.forma)?"contado":f.tipo_pago})}))}>
          {tarjetaDe(o)?`💳 ${o.replace("Tarjeta ","")}`:o}
        </Chip>
      ))}</div>

      <FL>¿Quién pagó?</FL>
      {usuarioActual==="Apolo"
        ?<div style={{background:"#FFF8E1",borderRadius:12,padding:"10px 14px",border:"1.5px solid #FFE082",fontSize:13,fontWeight:700,color:"#E65100"}}>🧑 Apolo (registrado automáticamente)</div>
        :<div style={S.chipRow}>{EQUIPO.map(o=><Chip key={o} active={form.quien===o} color={GRIS_MED} onClick={()=>setForm(f=>({...f,quien:o}))}>{o}</Chip>)}</div>
      }

      <FL>Nota (opcional)</FL>
      <textarea style={{...S.input,height:60,resize:"none"}} placeholder="Observación…"
        value={form.nota} onChange={e=>setForm(f=>({...f,nota:e.target.value}))}/>

      <FL>📷 Foto o archivo del ticket</FL>
      {form.foto
        ?<div style={{position:"relative",marginBottom:8}}>
           {form.foto.match(/\.pdf(\?|$)/i)
             ?<div style={{display:"flex",alignItems:"center",justifyContent:"space-between",
                 padding:"14px",borderRadius:12,background:"#FFF8E1",border:"1px solid #FFE082"}}>
                <a href={form.foto} target="_blank" rel="noreferrer"
                   style={{fontSize:13,fontWeight:700,color:AMBAR,textDecoration:"none"}}>
                  📄 PDF adjunto — toca para ver
                </a>
                <button onClick={()=>setForm(f=>({...f,foto:null,fotoEsPdf:false}))}
                  style={{background:"none",border:"none",cursor:"pointer",fontSize:16,color:GRIS_TEXT}}>✕</button>
              </div>
             :<><img src={form.foto} alt="ticket" style={{width:"100%",borderRadius:12,objectFit:"cover",maxHeight:160}}/>
               <button onClick={()=>setForm(f=>({...f,foto:null,fotoEsPdf:false}))}
                 style={{position:"absolute",top:8,right:8,background:"rgba(0,0,0,0.5)",border:"none",
                   borderRadius:20,color:BLANCO,padding:"4px 10px",cursor:"pointer",fontSize:12}}>✕</button>
             </>
           }
         </div>
        :<div style={{display:"flex",gap:8,marginBottom:8}}>
           <input ref={camaraRef} type="file" accept="image/*" capture="environment" style={{display:"none"}} onChange={handleFoto}/>
           <input ref={fileRef} type="file" accept="image/*,application/pdf" style={{display:"none"}} onChange={handleFoto}/>
           <button onClick={()=>camaraRef.current.click()} disabled={uploadingFoto}
             style={{flex:1,padding:"13px 0",borderRadius:13,border:`1.5px solid ${ROSA}`,background:ROSA_BG,
               color:ROSA,fontWeight:700,fontSize:13,cursor:"pointer",fontFamily:"inherit",
               opacity:uploadingFoto?0.6:1}}>
             📷 Cámara
           </button>
           <button onClick={()=>fileRef.current.click()} disabled={uploadingFoto}
             style={{flex:1,padding:"13px 0",borderRadius:13,border:"1.5px solid #E0E0E0",background:GRIS_LIGHT,
               color:GRIS_MED,fontWeight:700,fontSize:13,cursor:"pointer",fontFamily:"inherit",
               opacity:uploadingFoto?0.6:1}}>
             {uploadingFoto?"⏳ Subiendo…":"🖼 Galería / PDF"}
           </button>
         </div>
      }
      {error&&<div style={S.errorBanner}>{error}</div>}
      <button onClick={saveGasto} disabled={!form.monto||!form.concepto||!form.sucursal_id}
        style={{...S.btnPri,opacity:(!form.monto||!form.concepto||!form.sucursal_id)?0.4:1,background:saved?VERDE:ROSA}}>
        {saved?"✅ ¡Guardado!":!form.sucursal_id?"Selecciona una sucursal":editandoId?"💾 Guardar cambios":"Guardar Gasto"}
      </button>
    </Screen>
  );

  // ══════════════════════════════════════════════════════════════════════════
  // VISTA: COMPRA DE FRESA
  // ══════════════════════════════════════════════════════════════════════════
  if(view==="fresa")return(
    <Screen title="🍓 Compra de Fresa"
      onBack={()=>{setFForm({...FRESA0,fecha:todayISO(),lineas:[nuevaLinea("6")]});setView("inicio");}}>

      <div style={{...S.infoBox,marginBottom:4}}>
        Pon el precio por caja y cuántas van a cada tienda. El total se calcula solo y se registra un gasto por sucursal.
      </div>

      <FL>Fecha</FL>
      <input type="date" style={S.input} value={fForm.fecha} onChange={e=>setFForm(f=>({...f,fecha:e.target.value}))}/>

      <FL>Proveedor</FL>
      <input style={S.input} placeholder="Ej: Fresa MX, Central de Abastos…" value={fForm.proveedor}
        onChange={e=>setFForm(f=>({...f,proveedor:e.target.value}))}/>
      {proveedoresFresa.length>0&&!fForm.proveedor&&(
        <div style={{...S.chipRow,marginTop:8}}>
          {proveedoresFresa.map(p=><Chip key={p} active={false} color={ROSA} onClick={()=>setFForm(f=>({...f,proveedor:p}))}>{p}</Chip>)}
        </div>
      )}

      {fForm.lineas.map((l,i)=>{
        const ultimo=ultimoPrecioCaja(l.tipo);
        const precioKg=num(l.precio)>0?num(l.precio)/(KG_CAJA[l.tipo]||1):0;
        return(
          <div key={i} style={{background:BLANCO,borderRadius:16,padding:14,marginTop:16,
            boxShadow:"0 2px 10px rgba(0,0,0,0.06)",border:`1.5px solid ${l.cortesia?"#FFE082":"#F0F0F0"}`}}>

            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}>
              <div style={{fontSize:11,fontWeight:800,color:GRIS_TEXT,textTransform:"uppercase",letterSpacing:0.6}}>
                Tipo de caja
              </div>
              {fForm.lineas.length>1&&(
                <button onClick={()=>setFForm(f=>({...f,lineas:f.lineas.filter((_,ix)=>ix!==i)}))}
                  style={{background:"none",border:"none",cursor:"pointer",fontSize:13,color:"#E53935",fontWeight:700,fontFamily:"inherit"}}>
                  ✕ Quitar
                </button>
              )}
            </div>

            <div style={{display:"flex",gap:8}}>
              {["6","4"].map(t=>(
                <button key={t} onClick={()=>setLinea(i,{tipo:t})}
                  style={{flex:1,padding:"12px 4px",borderRadius:13,cursor:"pointer",fontFamily:"inherit",
                    border:`2px solid ${l.tipo===t?ROSA:"#E0E0E0"}`,
                    background:l.tipo===t?ROSA_BG:GRIS_LIGHT,textAlign:"center"}}>
                  <div style={{fontSize:20}}>📦</div>
                  <div style={{fontSize:14,fontWeight:900,color:l.tipo===t?ROSA:GRIS_MED,marginTop:2}}>{t} kg</div>
                </button>
              ))}
            </div>

            <FL>{l.cortesia?"Cortesía / merma — sin costo":"Precio por caja ($)"}</FL>
            {!l.cortesia&&(
              <>
                <div style={{position:"relative"}}>
                  <span style={{position:"absolute",left:14,top:"50%",transform:"translateY(-50%)",fontSize:18,fontWeight:800,color:l.precio?ROSA:"#CCC"}}>$</span>
                  <input type="number" inputMode="decimal"
                    style={{...S.input,paddingLeft:30,fontSize:22,fontWeight:800,color:ROSA}}
                    placeholder="0" value={l.precio} onChange={e=>setLinea(i,{precio:e.target.value})}/>
                </div>
                {ultimo&&!l.precio&&(
                  <div style={{...S.chipRow,marginTop:8}}>
                    <Chip active={false} color={ROSA} onClick={()=>setLinea(i,{precio:String(ultimo)})}>
                      🔁 Último: {fmtMXN(ultimo)}
                    </Chip>
                  </div>
                )}
                {precioKg>0&&(
                  <div style={{...S.infoBox,marginTop:8}}>
                    = <strong>${precioKg.toFixed(2)} por kilo</strong>
                    {l.tipo==="6"&&num(l.precio)<400&&<span> · ojo: a menos de $400 normalmente la caja es de 4 kg</span>}
                  </div>
                )}
              </>
            )}
            <button onClick={()=>setLinea(i,{cortesia:!l.cortesia,precio:l.cortesia?l.precio:""})}
              style={{marginTop:8,width:"100%",padding:"10px 0",borderRadius:12,cursor:"pointer",fontFamily:"inherit",
                fontSize:12,fontWeight:700,border:`1.5px solid ${l.cortesia?AMBAR:"#E0E0E0"}`,
                background:l.cortesia?AMBAR_BG:GRIS_LIGHT,color:l.cortesia?AMBAR:GRIS_MED}}>
              {l.cortesia?"✅ Cortesía del proveedor (registra kilos, $0)":"🎁 Marcar como cortesía / reposición"}
            </button>

            <FL>Cajas por sucursal</FL>
            {sucActivas.length===0
              ?<div style={{background:"#FFEBEE",borderRadius:12,padding:"10px 14px",fontSize:12,color:"#C62828",fontWeight:600}}>No hay sucursales activas</div>
              :sucActivas.map(s=>{
                const n=cajasSucLinea(l,s.id);
                return(
                  <div key={s.id} style={{display:"flex",alignItems:"center",gap:10,background:n>0?(s.color||ROSA)+"10":GRIS_LIGHT,
                    borderRadius:13,padding:"8px 10px",marginBottom:8,border:`1.5px solid ${n>0?(s.color||ROSA)+"55":"transparent"}`}}>
                    <span style={{fontSize:18}}>{s.emoji||"📍"}</span>
                    <div style={{flex:1,minWidth:0}}>
                      <div style={{fontSize:13,fontWeight:800,color:GRIS_DARK,whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}}>{s.nombre}</div>
                      {n>0&&<div style={{fontSize:11,color:GRIS_TEXT}}>
                        {n*(KG_CAJA[l.tipo]||0)} kg{!l.cortesia&&num(l.precio)>0?` · ${fmtMXN(n*num(l.precio))}`:""}
                      </div>}
                    </div>
                    <button onClick={()=>setCajas(i,s.id,n-1)} disabled={n===0}
                      style={{width:36,height:36,borderRadius:10,border:"1.5px solid #E0E0E0",background:BLANCO,
                        fontSize:20,fontWeight:800,color:n===0?"#DDD":GRIS_MED,cursor:n===0?"default":"pointer",fontFamily:"inherit"}}>−</button>
                    <div style={{minWidth:26,textAlign:"center",fontSize:19,fontWeight:900,color:n>0?(s.color||ROSA):"#CCC"}}>{n}</div>
                    <button onClick={()=>setCajas(i,s.id,n+1)}
                      style={{width:36,height:36,borderRadius:10,border:"none",background:s.color||ROSA,
                        fontSize:20,fontWeight:800,color:BLANCO,cursor:"pointer",fontFamily:"inherit"}}>+</button>
                  </div>
                );
              })}
            {cajasLinea(l)>0&&(
              <div style={{textAlign:"right",fontSize:12,fontWeight:800,color:GRIS_MED,marginTop:2}}>
                {cajasLinea(l)} caja{cajasLinea(l)!==1?"s":""} · {kgLinea(l)} kg · {fmtMXN(totalLinea(l))}
              </div>
            )}
          </div>
        );
      })}

      {fForm.lineas.length<3&&(
        <button onClick={()=>setFForm(f=>({...f,lineas:[...f.lineas,nuevaLinea(f.lineas[f.lineas.length-1]?.tipo==="6"?"4":"6")]}))}
          style={{...S.btnSec,marginTop:12}}>
          ➕ Agregar otro tipo de caja
        </button>
      )}

      {/* TOTAL */}
      <div style={{...S.heroCard,marginTop:20,marginBottom:0}}>
        <div style={{fontSize:11,color:"rgba(255,255,255,0.75)",fontWeight:700,letterSpacing:0.5}}>TOTAL DE LA COMPRA</div>
        <div style={{fontSize:40,fontWeight:900,letterSpacing:-1.5,lineHeight:1.1}}>{fmtMXN(totalFresa)}</div>
        <div style={{fontSize:13,color:"rgba(255,255,255,0.85)",marginTop:4}}>
          {cajasFresa} caja{cajasFresa!==1?"s":""} · {kgFresa} kg
          {totalFresa>0&&kgFresa>0?` · $${(totalFresa/kgFresa).toFixed(2)}/kg`:""}
        </div>
        {cajasFresa>0&&(
          <div style={{marginTop:14,display:"flex",flexDirection:"column",gap:6}}>
            {sucActivas.filter(s=>cajasFresaSuc(s.id)>0).map(s=>(
              <div key={s.id} style={{display:"flex",justifyContent:"space-between",fontSize:12,
                background:"rgba(0,0,0,0.15)",borderRadius:9,padding:"7px 10px"}}>
                <span style={{fontWeight:700}}>{s.emoji||"📍"} {s.nombre}</span>
                <span style={{fontWeight:800}}>{cajasFresaSuc(s.id)} cj · {kgFresaSuc(s.id)} kg · {fmtMXN(totalFresaSuc(s.id))}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      <FL>Tipo de pago</FL>
      <div style={{display:"flex",gap:8,marginBottom:4}}>
        {[
          {id:"contado",label:"Contado",emoji:"✅",color:VERDE},
          {id:"credito",label:"Crédito",emoji:"⏳",color:AMBAR},
        ].map(t=>(
          <button key={t.id} onClick={()=>setFForm(f=>({...f,tipo_pago:t.id}))}
            style={{flex:1,padding:"10px 4px",borderRadius:12,cursor:"pointer",fontFamily:"inherit",
              border:`2px solid ${fForm.tipo_pago===t.id?t.color:"#E0E0E0"}`,
              background:fForm.tipo_pago===t.id?t.color+"18":GRIS_LIGHT,textAlign:"center"}}>
            <div style={{fontSize:18}}>{t.emoji}</div>
            <div style={{fontSize:11,fontWeight:800,color:fForm.tipo_pago===t.id?t.color:GRIS_MED}}>{t.label}</div>
          </button>
        ))}
      </div>

      <FL>Forma de pago</FL>
      <div style={S.chipRow}>{FORMA_OPTS.map(o=>(
        <Chip key={o} active={fForm.forma===o} color={tarjetaDe(o)?AZUL:ROSA}
          onClick={()=>setFForm(f=>({...f,forma:o}))}>
          {tarjetaDe(o)?`💳 ${o.replace("Tarjeta ","")}`:o}
        </Chip>
      ))}</div>

      {fForm.tipo_pago==="credito"&&tarjetaDe(fForm.forma)&&(
        <TarjetaCreditoBox t={tarjetaDe(fForm.forma)} fecha={fForm.fecha}
          onConfig={PUEDE_VER_NUMEROS.includes(usuarioActual)?()=>setView("admin-tarjetas"):null}/>
      )}
      {fForm.tipo_pago==="credito"&&!tarjetaDe(fForm.forma)&&(
        <>
          <FL>Días de crédito</FL>
          <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
            {["7","14","30"].map(d=>(
              <Chip key={d} active={fForm.dias_credito===d} color={AMBAR}
                onClick={()=>setFForm(f=>({...f,dias_credito:d}))}>{d} días</Chip>
            ))}
          </div>
        </>
      )}

      <FL>¿Quién pagó?</FL>
      {usuarioActual==="Apolo"
        ?<div style={{background:"#FFF8E1",borderRadius:12,padding:"10px 14px",border:"1.5px solid #FFE082",fontSize:13,fontWeight:700,color:"#E65100"}}>🧑 Apolo (registrado automáticamente)</div>
        :<div style={S.chipRow}>{EQUIPO.map(o=><Chip key={o} active={fForm.quien===o} color={GRIS_MED} onClick={()=>setFForm(f=>({...f,quien:o}))}>{o}</Chip>)}</div>
      }

      <FL>Nota (opcional)</FL>
      <textarea style={{...S.input,height:56,resize:"none"}} placeholder="Ej: fresa chica, vino con merma…"
        value={fForm.nota} onChange={e=>setFForm(f=>({...f,nota:e.target.value}))}/>

      {error&&<div style={S.errorBanner}>{error}</div>}
      <button onClick={saveFresa} disabled={cajasFresa===0}
        style={{...S.btnPri,opacity:cajasFresa===0?0.4:1,background:fSaved?VERDE:ROSA}}>
        {fSaved?"✅ ¡Guardado!":cajasFresa===0?"Agrega cajas para guardar"
          :`Guardar — ${fmtMXN(totalFresa)} en ${sucActivas.filter(s=>cajasFresaSuc(s.id)>0).length} tienda${sucActivas.filter(s=>cajasFresaSuc(s.id)>0).length!==1?"s":""}`}
      </button>
    </Screen>
  );

  // ══════════════════════════════════════════════════════════════════════════
  // VISTA: VENTA DEL DÍA
  // ══════════════════════════════════════════════════════════════════════════
  if(view==="ventas")return(
    <Screen title="Venta de Efectivo" onBack={()=>{setVForm(VFORM0);setView("inicio");}}>
      <div style={{...S.infoBox,marginBottom:16}}>💵 Registra el efectivo del día para cuadrar la recolección.</div>
      <FL>📍 Sucursal *</FL>
      <SucursalChips sucursales={sucActivas} value={vForm.sucursal_id}
        onChange={(id)=>setVForm(f=>({...f,sucursal_id:id}))}/>
      <FL>Fecha</FL>
      <input type="date" style={S.input} value={vForm.fecha} onChange={e=>setVForm(f=>({...f,fecha:e.target.value}))}/>
      {vForm.sucursal_id&&ventas.find(v=>v.fecha===vForm.fecha&&v.sucursal_id===vForm.sucursal_id)&&(
        <div style={{...S.alertaBanner,background:AZUL_BG,color:AZUL,border:`1px solid ${AZUL}`,marginBottom:4}}>⚠️ Ya existe venta de {sucName(vForm.sucursal_id)} el {vForm.fecha} — se sobreescribirá</div>
      )}
      <FL>Efectivo del día ($) *</FL>
      <div style={{position:"relative"}}>
        <span style={{position:"absolute",left:14,top:"50%",transform:"translateY(-50%)",fontSize:20,fontWeight:800,color:VERDE}}>$</span>
        <input type="number" inputMode="decimal"
          style={{...S.input,paddingLeft:32,fontSize:28,fontWeight:800,color:VERDE}}
          placeholder="0" value={vForm.efectivo} onChange={e=>setVForm(f=>({...f,efectivo:e.target.value}))}/>
      </div>
      <FL>¿Quién registra?</FL>
      <div style={S.chipRow}>{EQUIPO.map(o=><Chip key={o} active={vForm.quien===o} color={VERDE} onClick={()=>setVForm(f=>({...f,quien:o}))}>{o}</Chip>)}</div>
      <FL>Nota</FL>
      <textarea style={{...S.input,height:56,resize:"none"}} value={vForm.nota} onChange={e=>setVForm(f=>({...f,nota:e.target.value}))}/>
      {error&&<div style={S.errorBanner}>{error}</div>}
      <button onClick={saveVenta} disabled={!vForm.efectivo||!vForm.sucursal_id}
        style={{...S.btnPri,opacity:(!vForm.efectivo||!vForm.sucursal_id)?0.4:1,background:vSaved?VERDE:ROSA}}>
        {vSaved?"✅ ¡Guardado!":!vForm.sucursal_id?"Selecciona una sucursal":"Guardar Venta"}
      </button>
    </Screen>
  );

  // ══════════════════════════════════════════════════════════════════════════
  // VISTA: RECOLECCIÓN
  // ══════════════════════════════════════════════════════════════════════════
  if(view==="recoleccion")return(
    <RecoleccionView
      rForm={rForm} setRForm={setRForm} ventas={ventas} recolecciones={recolecciones}
      recoleccionesF={recoleccionesF} sucursales={sucursales} sucActivas={sucActivas}
      sucursalActiva={sucursalActiva} setView={setView} setSelRec={setSelRec}
      setSelVentaDia={setSelVentaDia} fetchV={fetchV}
      usuarioActual={usuarioActual} saveRecoleccion={saveRecoleccion} rSaved={rSaved}
      error={error} sucName={sucName} sucEmoji={sucEmoji} sucColor={sucColor}/>
  );

  // ══════════════════════════════════════════════════════════════════════════
  // VISTA: DETALLE RECOLECCIÓN
  // ══════════════════════════════════════════════════════════════════════════
  if(view==="detalle-recoleccion"&&selRec){
    const r=recolecciones.find(x=>x.id===selRec.id)||selRec;
    const dias=r.fechas_cubiertas||[];
    return(
      <Screen title="Detalle Recolección" onBack={()=>{setView("recoleccion");setSelRec(null);setEditRecForm(null);}}>
        <div style={{background:r.faltante>0?`linear-gradient(135deg,#C62828,#B71C1C)`:`linear-gradient(135deg,${VERDE},#1B5E20)`,borderRadius:18,padding:"22px 20px",color:BLANCO,marginBottom:12,boxShadow:"0 8px 24px rgba(46,125,50,0.25)"}}>
          <div style={{fontSize:11,color:"rgba(255,255,255,0.7)",marginBottom:4}}>💰 {r.fecha_recoleccion}</div>
          <div style={{fontSize:13,color:"rgba(255,255,255,0.6)",marginBottom:2}}>Declarado</div>
          <div style={{fontSize:36,fontWeight:900,letterSpacing:-1.5}}>{fmtMXN(r.monto_total)}</div>
          {r.monto_fisico!=null&&(
            <div style={{marginTop:8,display:"flex",gap:20}}>
              <div><div style={{fontSize:10,color:"rgba(255,255,255,0.6)"}}>Físico entregado</div><div style={{fontSize:18,fontWeight:900}}>{fmtMXN(r.monto_fisico)}</div></div>
              {r.faltante>0&&<div><div style={{fontSize:10,color:"rgba(255,255,255,0.6)"}}>Faltante</div><div style={{fontSize:18,fontWeight:900,color:"#FFB3B3"}}>{fmtMXN(r.faltante)}</div></div>}
            </div>
          )}
          <div style={{fontSize:13,color:"rgba(255,255,255,0.7)",marginTop:8}}>Recolectó: <strong>{r.quien||"—"}</strong> · {dias.length} días</div>
          {r.faltante>0&&r.quien_faltante&&<div style={{fontSize:12,color:"#FFB3B3",marginTop:4}}>⚠️ Faltante a cargo de: <strong>{r.quien_faltante}</strong></div>}
        </div>
        {r.faltante>0&&(
          <div style={{background:"#FFEBEE",borderRadius:12,padding:"12px 16px",marginBottom:16,border:"1.5px solid #EF9A9A"}}>
            <div style={{fontSize:13,fontWeight:800,color:"#E53935",marginBottom:4}}>🔴 Deuda pendiente: {fmtMXN(r.faltante)}</div>
            <div style={{fontSize:12,color:"#C62828"}}>
              {r.quien_faltante?`${r.quien_faltante} debe entregar este monto en el siguiente corte.`:"Asigna a quién corresponde el faltante editando esta recolección."}
            </div>
          </div>
        )}

        {/* BANNER DE APROBACIÓN */}
        {r.quien==="Apolo"&&(
          !r.aprobada
            ?<div style={{background:"#FFF8E1",borderRadius:14,padding:"14px 16px",marginBottom:12,border:"2px solid #FFD700"}}>
               <div style={{fontSize:13,fontWeight:800,color:"#E65100",marginBottom:4}}>⏳ Pendiente de aprobación</div>
               <div style={{fontSize:12,color:"#795548",marginBottom:usuarioActual==="José Luis"?10:0}}>
                 Esta recolección de <strong>Apolo</strong> requiere que <strong>José Luis</strong> la apruebe.
               </div>
               {usuarioActual==="José Luis"&&(
                 <button onClick={async()=>{
                   await sb.from("recolecciones").update({aprobada:true,aprobada_por:"José Luis",nota:(r.nota||"")+(r.nota?"\n":"")+"✅ Aprobada por José Luis el "+todayISO()}).eq("id",r.id);
                   await fetchR();
                   const{data}=await sb.from("recolecciones").select("*").order("created_at",{ascending:false});
                   if(data){setRecolecciones(data);const upd=data.find(x=>x.id===r.id);if(upd)setSelRec(upd);}
                 }}
                   style={{width:"100%",padding:"12px 0",background:"#2E7D32",color:"#FFF",border:"none",borderRadius:12,fontSize:14,fontWeight:800,cursor:"pointer",fontFamily:"inherit"}}>
                   ✅ Aprobar esta recolección
                 </button>
               )}
             </div>
            :<div style={{background:"#E8F5E9",borderRadius:14,padding:"12px 16px",marginBottom:12,border:"1.5px solid #A5D6A7"}}>
               <div style={{fontSize:13,fontWeight:800,color:"#2E7D32"}}>✅ Aprobada por {r.aprobada_por||"sistema"}</div>
             </div>
        )}

        {!editRecForm&&(usuarioActual==="José Luis"||usuarioActual==="Andres")?(
          <div style={{display:"flex",gap:8,marginBottom:16}}>
            <button onClick={()=>setEditRecForm({quien:r.quien,nota:r.nota||"",fecha_recoleccion:r.fecha_recoleccion,quien_faltante:r.quien_faltante||""})}
              style={{flex:1,...S.actionBtn,color:AZUL,borderColor:AZUL,background:AZUL_BG}}>✏️ Editar</button>
            <button onClick={()=>{if(window.confirm("¿Cancelar esta recolección?"))deleteRecoleccion(r.id);}}
              style={{flex:1,...S.actionBtn,color:"#E53935",borderColor:"#EF9A9A",background:"#FFEBEE"}}>🗑 Cancelar</button>
          </div>
        ):(
          <div style={{background:AZUL_BG,borderRadius:14,padding:16,marginBottom:16,border:"1.5px solid #90CAF9"}}>
            <div style={{fontWeight:800,fontSize:13,color:AZUL,marginBottom:12}}>✏️ Editar</div>
            <FL>Fecha</FL>
            <input type="date" style={S.input} value={editRecForm.fecha_recoleccion} onChange={e=>setEditRecForm(f=>({...f,fecha_recoleccion:e.target.value}))}/>
            <FL>¿Quién recolectó?</FL>
            <div style={S.chipRow}>{["José Luis","Jefeson"].map(o=><Chip key={o} active={editRecForm.quien===o} color={VERDE} onClick={()=>setEditRecForm(f=>({...f,quien:o}))}>{o}</Chip>)}</div>
            <FL>Nota</FL>
            <textarea style={{...S.input,height:56,resize:"none"}} value={editRecForm.nota} onChange={e=>setEditRecForm(f=>({...f,nota:e.target.value}))}/>
            {r.faltante>0&&(
              <>
                <FL>¿Quién tiene el faltante? ({fmtMXN(r.faltante)})</FL>
                <div style={{display:"flex",flexWrap:"wrap",gap:6}}>
                  {EQUIPO.map(p=>(
                    <button key={p} onClick={()=>setEditRecForm(f=>({...f,quien_faltante:p}))}
                      style={{padding:"7px 13px",borderRadius:16,border:"none",
                        background:editRecForm.quien_faltante===p?"#E53935":"#FFCDD2",
                        color:editRecForm.quien_faltante===p?BLANCO:"#C62828",
                        fontSize:12,fontWeight:700,cursor:"pointer",fontFamily:"inherit"}}>
                      {p}
                    </button>
                  ))}
                </div>
              </>
            )}
            <div style={{display:"flex",gap:8,marginTop:12}}>
              <button onClick={()=>setEditRecForm(null)} style={{flex:1,...S.btnSec,marginTop:0,padding:"12px 0"}}>Cancelar</button>
              <button onClick={()=>updateRecoleccion(r.id,editRecForm)} style={{flex:1,...S.btnPri,marginTop:0,padding:"12px 0",background:AZUL}}>Guardar</button>
            </div>
          </div>
        )}

        <ST>Días cubiertos</ST>
        {dias.sort().map(fecha=>{
          const v=ventas.find(v=>v.fecha===fecha);
          return(
            <button key={fecha} onClick={()=>{setSelVentaDia(fecha);setView("detalle-venta");}}
              style={{...S.card,display:"flex",justifyContent:"space-between",alignItems:"center",width:"100%",border:"none",cursor:"pointer",fontFamily:"inherit",textAlign:"left",marginBottom:8}}>
              <div>
                <div style={{fontWeight:700,fontSize:14}}>{fecha}</div>
                <div style={{fontSize:11,color:GRIS_TEXT,marginTop:2}}>Registró: {v?.quien||"—"}</div>
              </div>
              <div style={{display:"flex",alignItems:"center",gap:8}}>
                <div style={{fontWeight:900,color:VERDE,fontSize:16}}>{fmtMXN(v?.efectivo)}</div>
                <span style={{fontSize:11,background:VERDE_BG,color:VERDE,borderRadius:6,padding:"2px 7px",fontWeight:700}}>✓</span>
                <span style={{color:"#CCC",fontSize:18}}>›</span>
              </div>
            </button>
          );
        })}

        <ST>Comentarios</ST>
        {r.nota&&<div style={{background:GRIS_LIGHT,borderRadius:12,padding:"12px 14px",marginBottom:12,fontSize:13,color:GRIS_DARK}}>{r.nota}</div>}
        <textarea style={{...S.input,height:72,resize:"none"}} placeholder="Agregar comentario…" value={comentario} onChange={e=>setComentario(e.target.value)}/>
        <button onClick={()=>agregarComentario(r.id,r.nota)} disabled={!comentario.trim()}
          style={{...S.btnPri,opacity:!comentario.trim()?0.4:1,background:AZUL,boxShadow:"0 6px 20px rgba(21,101,192,0.25)"}}>
          💬 Agregar comentario
        </button>
      </Screen>
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  // VISTA: DETALLE VENTA DÍA
  // ══════════════════════════════════════════════════════════════════════════
  if(view==="detalle-venta"&&selVentaDia){
    const v=ventas.find(v=>v.fecha===selVentaDia);
    const recol=recolecciones.find(r=>(r.fechas_cubiertas||[]).includes(selVentaDia));
    const gastosDia=gastos.filter(g=>g.fecha===selVentaDia);
    const totalGDia=gastosDia.reduce((s,g)=>s+num(g.monto),0);
    const backView=selRec?"detalle-recoleccion":"recoleccion";
    return(
      <Screen title={`Día · ${selVentaDia}`} onBack={()=>setView(backView)}>
        <div style={{background:`linear-gradient(135deg,${v?VERDE:"#546E7A"},${v?"#1B5E20":"#37474F"})`,borderRadius:18,padding:"22px 20px",color:BLANCO,marginBottom:16,boxShadow:"0 8px 24px rgba(0,0,0,0.15)"}}>
          <div style={{fontSize:11,color:"rgba(255,255,255,0.7)",marginBottom:4}}>{v?"💵 Venta del día":"📭 Sin registro"}</div>
          <div style={{fontSize:40,fontWeight:900,letterSpacing:-1.5}}>{v?fmtMXN(v.efectivo):"$0"}</div>
          {v&&<div style={{fontSize:13,color:"rgba(255,255,255,0.7)",marginTop:6}}>Registró: <strong>{v.quien||"—"}</strong></div>}
        </div>

        <div style={{borderRadius:12,padding:"12px 16px",marginBottom:16,
          background:recol?VERDE_BG:AMBAR_BG,border:`1.5px solid ${recol?"#A5D6A7":AMBAR}`}}>
          <div style={{fontWeight:800,fontSize:13,color:recol?VERDE:AMBAR}}>
            {recol?"✅ Efectivo recolectado":"⏳ Pendiente de recolectar"}
          </div>
          {recol&&<div style={{fontSize:11,color:GRIS_TEXT,marginTop:4}}>Recolectó {recol.quien} el {recol.fecha_recoleccion}</div>}
        </div>

        <div style={{display:"flex",gap:8,marginBottom:16}}>
          {v?(
            <button onClick={()=>{setVForm({fecha:v.fecha,efectivo:String(v.efectivo),quien:v.quien||"",nota:v.nota||""});setView("ventas");}}
              style={{flex:1,...S.actionBtn,color:AZUL,borderColor:AZUL,background:AZUL_BG}}>✏️ Editar venta</button>
          ):(
            <button onClick={()=>{setVForm({fecha:selVentaDia,efectivo:"",quien:"",nota:""});setView("ventas");}}
              style={{flex:1,...S.actionBtn,color:VERDE,borderColor:VERDE,background:VERDE_BG}}>+ Registrar venta</button>
          )}
        </div>

        {v?.nota&&<div style={{background:GRIS_LIGHT,borderRadius:12,padding:"12px 14px",marginBottom:16,fontSize:13,color:GRIS_DARK,fontStyle:"italic"}}>{v.nota}</div>}

        {gastosDia.length>0&&(
          <>
            <ST>Gastos del mismo día · {fmtMXN(totalGDia)}</ST>
            {gastosDia.map(g=><GastoRow key={g.id} g={g} onDelete={deleteGasto} onEdit={startEdit} inusual={esInusual(g.cat,g.monto)} canEdit={usuarioActual==="Andres"||usuarioActual==="José Luis"||(usuarioActual!=="Apolo"&&g.quien===usuarioActual)} sucursalLabel={mkSucLabel(g.sucursal_id)} cats={cats}/>)}
          </>
        )}
      </Screen>
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  // VISTA: CRÉDITOS
  // ══════════════════════════════════════════════════════════════════════════
  if(view==="creditos"){
    const pendientes=gastos.filter(g=>g.tipo_pago==="credito"&&!g.pagado).sort((a,b)=>(a.fecha_vencimiento||"9").localeCompare(b.fecha_vencimiento||"9"));
    const pagados=gastos.filter(g=>g.tipo_pago==="credito"&&g.pagado).sort((a,b)=>(b.fecha_pago||"").localeCompare(a.fecha_pago||""));
    const totalPendiente=pendientes.reduce((s,g)=>s+num(g.monto),0);
    return(
      <Screen title="Créditos" onBack={()=>setView("inicio")}
        action={<button onClick={()=>setView("admin-tarjetas")}
          style={{background:AZUL_BG,border:`1.5px solid ${AZUL}`,borderRadius:10,padding:"7px 11px",
            fontSize:12,fontWeight:800,color:AZUL,cursor:"pointer",fontFamily:"inherit"}}>💳 Tarjetas</button>}>
        <div style={{background:`linear-gradient(135deg,${AMBAR},#E65100)`,borderRadius:18,padding:"22px 20px",color:BLANCO,marginBottom:16,boxShadow:"0 8px 24px rgba(245,127,23,0.3)"}}>
          <div style={{fontSize:11,color:"rgba(255,255,255,0.7)",marginBottom:4}}>⏳ Total pendiente de pago</div>
          <div style={{fontSize:40,fontWeight:900,letterSpacing:-1.5}}>{fmtMXN(totalPendiente)}</div>
          <div style={{fontSize:13,color:"rgba(255,255,255,0.7)",marginTop:6}}>{pendientes.length} compra{pendientes.length!==1?"s":""} · {vencidos.length} vencida{vencidos.length!==1?"s":""}</div>
        </div>

        {/* Saldo por tarjeta: lo que se junta para cada fecha límite */}
        {tarjetas.map(t=>{
          const delaTarjeta=pendientes.filter(g=>g.forma===t.forma);
          if(delaTarjeta.length===0)return null;
          const porVence={};
          delaTarjeta.forEach(g=>{const k=g.fecha_vencimiento||"—";porVence[k]=(porVence[k]||0)+num(g.monto);});
          return(
            <div key={t.key} style={{background:BLANCO,borderRadius:14,padding:"12px 14px",marginBottom:10,
              boxShadow:"0 2px 8px rgba(0,0,0,0.05)",borderLeft:`4px solid ${t.color||AZUL}`}}>
              <div style={{fontSize:13,fontWeight:900,color:GRIS_DARK}}>💳 {t.label} · corte día {t.dia_corte}</div>
              {Object.entries(porVence).sort().map(([f,m])=>(
                <div key={f} style={{display:"flex",justifyContent:"space-between",marginTop:6,fontSize:12}}>
                  <span style={{color:GRIS_MED}}>Pagar antes del <strong>{fmtFechaCorta(f)}</strong></span>
                  <span style={{fontWeight:900,color:t.color||AZUL}}>{fmtMXN(m)}</span>
                </div>
              ))}
            </div>
          );
        })}

        {vencidos.length>0&&(
          <div style={{...S.alertaBanner,marginBottom:12}}>
            🔴 {vencidos.length} crédito{vencidos.length!==1?"s":""} vencido{vencidos.length!==1?"s":""} — requiere atención
          </div>
        )}

        {/* Modal pagar */}
        {pagoForm&&(
          <div style={{background:VERDE_BG,borderRadius:14,padding:16,marginBottom:16,border:"2px solid #A5D6A7"}}>
            <div style={{fontWeight:800,fontSize:14,color:VERDE,marginBottom:12}}>
              ✅ Registrar pago — {gastos.find(g=>g.id===pagoForm.id)?.concepto}
            </div>
            <FL>Fecha de pago</FL>
            <input type="date" style={S.input} value={pagoForm.fecha} onChange={e=>setPagoForm(f=>({...f,fecha:e.target.value}))}/>
            <FL>¿Cómo se pagó?</FL>
            <div style={S.chipRow}>{FORMA_OPTS.map(o=><Chip key={o} active={pagoForm.forma===o} color={VERDE} onClick={()=>setPagoForm(f=>({...f,forma:o}))}>{o}</Chip>)}</div>
            <FL>Nota (opcional)</FL>
            <input style={S.input} placeholder="Ej: pagado en tienda, transferencia confirmada…" value={pagoForm.nota} onChange={e=>setPagoForm(f=>({...f,nota:e.target.value}))}/>
            <div style={{display:"flex",gap:8,marginTop:12}}>
              <button onClick={()=>setPagoForm(null)} style={{flex:1,...S.btnSec,marginTop:0,padding:"12px 0"}}>Cancelar</button>
              <button onClick={marcarPagado} style={{flex:1,...S.btnPri,marginTop:0,padding:"12px 0",background:VERDE}}>✅ Confirmar pago</button>
            </div>
          </div>
        )}

        <ST>Pendientes de pago ({pendientes.length})</ST>
        {pendientes.length===0?<Empty>Sin créditos pendientes 🎉</Empty>:pendientes.map(g=>{
          const venc=g.fecha_vencimiento;
          const isVencido=venc&&venc<todayISO();
          const diasFalta=venc?Math.round((new Date(venc)-new Date(todayISO()))/(1000*60*60*24)):null;
          return(
            <div key={g.id} style={{...S.card,borderLeft:`4px solid ${isVencido?"#E53935":AMBAR}`,marginBottom:10}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:8}}>
                <div>
                  <div style={{fontWeight:800,fontSize:15}}>{g.concepto}</div>
                  <div style={{fontSize:11,color:GRIS_TEXT,marginTop:2}}>
                    {g.fecha} · {g.quien||"—"} · {cats.find(c=>c.id===g.cat)?.emoji} {cats.find(c=>c.id===g.cat)?.label}
                  </div>
                </div>
                <div style={{fontWeight:900,color:isVencido?"#E53935":AMBAR,fontSize:18}}>{fmtMXN(g.monto)}</div>
              </div>
              {venc&&(
                <div style={{fontSize:12,fontWeight:700,marginBottom:8,
                  color:isVencido?"#E53935":diasFalta<=7?AMBAR:VERDE,
                  background:isVencido?"#FFEBEE":diasFalta<=7?AMBAR_BG:VERDE_BG,
                  borderRadius:8,padding:"4px 10px",display:"inline-block"}}>
                  {isVencido?`🔴 Vencido (${Math.abs(diasFalta)} días)`:diasFalta===0?"🟡 Vence hoy":`📅 Vence ${venc} (${diasFalta} días)`}
                </div>
              )}
              {g.nota&&<div style={{fontSize:11,color:GRIS_TEXT,fontStyle:"italic",marginBottom:8}}>{g.nota}</div>}
              <div style={{display:"flex",gap:8}}>
                <button onClick={()=>startEdit(g)} style={{flex:1,...S.actionBtn,color:AZUL,borderColor:AZUL,background:AZUL_BG,fontSize:12}}>✏️ Editar</button>
                <button onClick={()=>setPagoForm({id:g.id,fecha:todayISO(),forma:"Efectivo",nota:""})}
                  style={{flex:2,...S.actionBtn,color:VERDE,borderColor:VERDE,background:VERDE_BG,fontSize:12}}>✅ Registrar pago</button>
              </div>
            </div>
          );
        })}

        {pagados.length>0&&(
          <>
            <ST>Pagados ({pagados.length})</ST>
            {pagados.slice(0,20).map(g=>(
              <div key={g.id} style={{...S.card,borderLeft:"4px solid #A5D6A7",opacity:0.85,marginBottom:8}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                  <div>
                    <div style={{fontWeight:700,fontSize:14}}>{g.concepto}</div>
                    <div style={{fontSize:11,color:GRIS_TEXT,marginTop:2}}>
                      Compra: {g.fecha} · Pagado: {g.fecha_pago||"—"} · {g.forma}
                    </div>
                  </div>
                  <div style={{textAlign:"right"}}>
                    <div style={{fontWeight:900,color:VERDE,fontSize:15}}>{fmtMXN(g.monto)}</div>
                    <div style={{fontSize:10,background:VERDE_BG,color:VERDE,borderRadius:6,padding:"2px 6px",marginTop:2}}>✓ pagado</div>
                  </div>
                </div>
              </div>
            ))}
          </>
        )}
      </Screen>
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  // VISTA: RESUMEN MES
  // ══════════════════════════════════════════════════════════════════════════
  if(view==="resumen"){if(!PUEDE_VER_NUMEROS.includes(usuarioActual))return null;
    const mk=resMK||currentMK;
    // Aplicar todos los filtros
    const listaCompleta=gMes(mk).filter(g=>{
      if(filtroQ!=="todos"&&g.quien!==filtroQ)return false;
      if(resCat!=="todos"&&g.cat!==resCat)return false;
      if(resBuscar&&!norm(g.concepto).includes(norm(resBuscar)))return false;
      if(resDesde&&g.fecha<resDesde)return false;
      if(resHasta&&g.fecha>resHasta)return false;
      return true;
    });
    const tg=listaCompleta.reduce((s,g)=>s+num(g.monto),0);
    // Desglose por método de pago (efectivo vs otros)
    const tgEfectivo=listaCompleta.filter(g=>g.forma==="Efectivo").reduce((s,g)=>s+num(g.monto),0);
    const tgOtros=tg-tgEfectivo;
    // Desglose detallado por forma de pago (para tarjeta/Mercado Pago/etc)
    const porForma={};listaCompleta.forEach(g=>{const k=g.forma||"Sin método";porForma[k]=(porForma[k]||0)+g.monto;});
    // Categorías de la lista filtrada
    const catTot={};listaCompleta.forEach(g=>{catTot[g.cat]=(catTot[g.cat]||0)+g.monto;});
    // Personas de la lista filtrada
    const quien={};listaCompleta.forEach(g=>{const k=g.quien||"Sin asignar";quien[k]=(quien[k]||0)+g.monto;});
    const lista=listaCompleta.sort((a,b)=>b.fecha.localeCompare(a.fecha));
    const ventasMes=ventas.filter(v=>monthKey(v.fecha)===mk);
    const totalVentasMes=ventasMes.reduce((s,v)=>s+num(v.efectivo),0);
    const credMes=gMes(mk).filter(g=>g.tipo_pago==="credito"&&!g.pagado);
    const totCred=credMes.reduce((s,g)=>s+num(g.monto),0);
    const diasConV=ventasMes.length;
    const diasDelMes=new Date(parseInt(mk.slice(0,4)),parseInt(mk.slice(5,7)),0).getDate();
    // RECOLECCIÓN DEL MES
    const recoleccionesMes=recolecciones.filter(r=>monthKey(r.fecha_recoleccion)===mk);
    const totalRecolectadoMes=recoleccionesMes.reduce((s,r)=>s+num(r.monto_fisico??r.monto_total),0);
    // Pendiente SOLO del mes seleccionado: días con venta del mes que no estén recolectados
    const diasMesConVenta=ventasMes.map(v=>v.fecha);
    const diasMesPendientes=diasMesConVenta.filter(d=>!diasRecolectados.includes(d));
    const pendienteMes=diasMesPendientes.reduce((s,d)=>{const v=ventas.find(v=>v.fecha===d);return s+num(v?.efectivo);},0);
    // Faltantes del mes (diferencia entre lo que debió recolectarse y lo físico)
    const faltantesMes=recoleccionesMes.reduce((s,r)=>s+num(r.faltante),0);
    // Recolectado por persona en el mes
    const recoPorPersona={};
    recoleccionesMes.forEach(r=>{
      const k=r.quien||"—";
      const m=num(r.monto_fisico!=null?r.monto_fisico:r.monto_total);
      recoPorPersona[k]=(recoPorPersona[k]||0)+m;
    });
    // Top proveedores de la lista filtrada
    const provMap={};listaCompleta.forEach(g=>{const k=g.concepto||"Sin nombre";provMap[k]=(provMap[k]||0)+g.monto;});
    const topProv=Object.entries(provMap).sort((a,b)=>b[1]-a[1]).slice(0,8);
    // ── COMPARACIÓN MES ANTERIOR (para mostrar tendencia ▲▼) ──
    const mkPrev=(()=>{const [y,m]=mk.split("-").map(Number);const d=new Date(y,m-2,1);return monthKey(d.toISOString());})();
    const tgPrev=totG(mkPrev);
    const tvPrev=ventas.filter(v=>monthKey(v.fecha)===mkPrev).reduce((s,v)=>s+num(v.efectivo),0);
    const diff=(curr,prev)=>{if(!prev)return null;const pct=Math.round(((curr-prev)/prev)*100);return{pct,up:pct>=0};};
    const diffVentas=diff(totalVentasMes,tvPrev);
    const diffGastos=diff(tg,tgPrev);
    return(
      <Screen title={`Resumen ${monthLabel(mk)}`} onBack={()=>setView("inicio")}
        action={<ExportBtn onClick={()=>exportExcel(gastos,ventas,recolecciones,mk,sucursales,sucursalActiva,cats)}/>}>

        {/* ═══ HERO: BALANCES + MINI-CARDS ═══ */}
        <div style={{marginBottom:14}}>
          {/* Selector de mes + título */}
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10,padding:"0 2px"}}>
            <div style={{fontSize:11,color:GRIS_TEXT,fontWeight:800,textTransform:"uppercase",letterSpacing:0.8}}>Balance del mes</div>
            <button onClick={()=>{setShowMonthPicker(true);}}
              style={{background:BLANCO,border:`1.5px solid ${ROSA}33`,borderRadius:10,padding:"6px 12px",color:ROSA,fontSize:12,fontWeight:800,cursor:"pointer",fontFamily:"inherit",boxShadow:"0 1px 4px rgba(0,0,0,0.04)"}}>
              📅 {monthLabel(mk)} ▼
            </button>
          </div>

          {/* Dos balances grandes lado a lado */}
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:10}}>
            {/* Balance total */}
            <div style={{background:`linear-gradient(135deg, ${ROSA} 0%, #C2185B 100%)`,borderRadius:16,padding:"14px 14px 12px",color:BLANCO,boxShadow:"0 4px 14px rgba(232,23,93,0.2)"}}>
              <div style={{fontSize:10,color:"rgba(255,255,255,0.85)",fontWeight:800,textTransform:"uppercase",letterSpacing:0.6,marginBottom:4}}>📊 Total</div>
              <div style={{fontSize:22,fontWeight:900,letterSpacing:-0.5,color:totalVentasMes-tg>=0?"#C8F7C8":"#FFD4D4",lineHeight:1.1}}>
                {totalVentasMes-tg>=0?"+":""}{fmtMXN(totalVentasMes-tg)}
              </div>
              <div style={{fontSize:10,color:"rgba(255,255,255,0.7)",marginTop:4}}>Ventas − todos los gastos</div>
            </div>
            {/* Balance efectivo (caja) */}
            <div style={{background:`linear-gradient(135deg, ${VERDE} 0%, #1B5E20 100%)`,borderRadius:16,padding:"14px 14px 12px",color:BLANCO,boxShadow:"0 4px 14px rgba(46,125,50,0.2)"}}>
              <div style={{fontSize:10,color:"rgba(255,255,255,0.85)",fontWeight:800,textTransform:"uppercase",letterSpacing:0.6,marginBottom:4}}>💵 En caja</div>
              <div style={{fontSize:22,fontWeight:900,letterSpacing:-0.5,color:totalVentasMes-tgEfectivo>=0?"#C8F7C8":"#FFD4D4",lineHeight:1.1}}>
                {totalVentasMes-tgEfectivo>=0?"+":""}{fmtMXN(totalVentasMes-tgEfectivo)}
              </div>
              <div style={{fontSize:10,color:"rgba(255,255,255,0.7)",marginTop:4}}>Ventas − gastos en efectivo</div>
            </div>
          </div>

          {/* Cuatro mini-cards: Ventas, Efectivo, Otros, Recolectado */}
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
            <div style={{background:BLANCO,borderRadius:12,padding:"10px 12px",boxShadow:"0 2px 8px rgba(0,0,0,0.05)",borderLeft:`3px solid ${VERDE}`}}>
              <div style={{fontSize:10,color:GRIS_TEXT,fontWeight:800,textTransform:"uppercase",letterSpacing:0.4}}>Ventas</div>
              <div style={{fontSize:16,fontWeight:900,color:VERDE,marginTop:2}}>{fmtMXN(totalVentasMes)}</div>
            </div>
            <div style={{background:BLANCO,borderRadius:12,padding:"10px 12px",boxShadow:"0 2px 8px rgba(0,0,0,0.05)",borderLeft:`3px solid ${AZUL}`}}>
              <div style={{fontSize:10,color:GRIS_TEXT,fontWeight:800,textTransform:"uppercase",letterSpacing:0.4}}>💰 Recolectado</div>
              <div style={{fontSize:16,fontWeight:900,color:AZUL,marginTop:2}}>{fmtMXN(totalRecolectadoMes)}</div>
            </div>
            <div style={{background:BLANCO,borderRadius:12,padding:"10px 12px",boxShadow:"0 2px 8px rgba(0,0,0,0.05)",borderLeft:`3px solid ${ROSA}`}}>
              <div style={{fontSize:10,color:GRIS_TEXT,fontWeight:800,textTransform:"uppercase",letterSpacing:0.4}}>💵 Gastos efectivo</div>
              <div style={{fontSize:16,fontWeight:900,color:ROSA,marginTop:2}}>{fmtMXN(tgEfectivo)}</div>
            </div>
            <div style={{background:BLANCO,borderRadius:12,padding:"10px 12px",boxShadow:"0 2px 8px rgba(0,0,0,0.05)",borderLeft:`3px solid #6A1B9A`}}>
              <div style={{fontSize:10,color:GRIS_TEXT,fontWeight:800,textTransform:"uppercase",letterSpacing:0.4}}>💳 Gastos otros</div>
              <div style={{fontSize:16,fontWeight:900,color:"#6A1B9A",marginTop:2}}>{fmtMXN(tgOtros)}</div>
            </div>
          </div>
        </div>

        {/* ═══ MODAL SELECTOR DE MES ═══ */}
        {showMonthPicker&&(
          <div onClick={()=>setShowMonthPicker(false)}
            style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.5)",zIndex:300,display:"flex",alignItems:"center",justifyContent:"center",padding:24}}>
            <div onClick={e=>e.stopPropagation()}
              style={{background:BLANCO,borderRadius:20,padding:"20px",width:"100%",maxWidth:340,maxHeight:"70vh",overflowY:"auto"}}>
              <div style={{fontSize:16,fontWeight:900,color:GRIS_DARK,marginBottom:14}}>📅 Selecciona el mes</div>
              {months.map(m=>{
                const tgM=totG(m);
                return(
                  <button key={m} onClick={()=>{setResMK(m===currentMK?null:m);setShowMonthPicker(false);}}
                    style={{display:"flex",justifyContent:"space-between",alignItems:"center",width:"100%",padding:"12px 14px",borderRadius:12,border:mk===m?`2px solid ${ROSA}`:"1.5px solid #EEE",background:mk===m?ROSA_BG:BLANCO,marginBottom:8,cursor:"pointer",fontFamily:"inherit"}}>
                    <span style={{fontWeight:800,fontSize:14,color:mk===m?ROSA:GRIS_DARK}}>{monthLabel(m)}</span>
                    <span style={{fontSize:12,color:GRIS_TEXT,fontWeight:700}}>{fmtMXN(tgM)}</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* ═══ BARRA DE TABS ═══ */}
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:6,marginBottom:14,background:GRIS_LIGHT,padding:4,borderRadius:12}}>
          {[
            {id:"resumen",icon:"📊",label:"Resumen"},
            {id:"gastos",icon:"💸",label:`Gastos ${lista.length>0?`(${lista.length})`:""}`},
            {id:"recolecciones",icon:"💰",label:"Cobranza"},
          ].map(t=>(
            <button key={t.id} onClick={()=>setResTab(t.id)}
              style={{
                padding:"10px 4px",borderRadius:9,border:"none",cursor:"pointer",fontFamily:"inherit",
                background:resTab===t.id?BLANCO:"transparent",
                boxShadow:resTab===t.id?"0 2px 6px rgba(0,0,0,0.08)":"none",
                color:resTab===t.id?ROSA:GRIS_MED,
                fontSize:11,fontWeight:800,transition:"all 0.15s",
                display:"flex",flexDirection:"column",alignItems:"center",gap:2
              }}>
              <span style={{fontSize:16}}>{t.icon}</span>
              <span>{t.label}</span>
            </button>
          ))}
        </div>

        {/* ═══════════════════════════════════════════════════ */}
        {/* TAB 1: RESUMEN — vista de un vistazo */}
        {/* ═══════════════════════════════════════════════════ */}
        {resTab==="resumen"&&(
          <>
            {/* Alertas rápidas */}
            {totCred>0&&<button onClick={()=>setView("creditos")} style={{...S.alertaBanner,marginBottom:8,width:"100%",border:`1px solid ${AMBAR}`,cursor:"pointer",fontFamily:"inherit",textAlign:"left"}}>
              ⏳ <strong>{fmtMXN(totCred)}</strong> en créditos pendientes →
            </button>}
            {pendienteMes>0&&<div style={{...S.alertaBanner,background:VERDE_BG,color:VERDE,border:`1px solid ${VERDE}`,marginBottom:8}}>
              💵 <strong>{fmtMXN(pendienteMes)}</strong> de efectivo sin recolectar ({diasMesPendientes.length} días)
            </div>}
            {faltantesMes>0&&<div style={{...S.alertaBanner,background:"#FFEBEE",color:"#E53935",border:"1px solid #EF9A9A",marginBottom:8}}>
              🔴 <strong>{fmtMXN(faltantesMes)}</strong> en faltantes este mes
            </div>}

            {/* Comparación con mes anterior */}
            {tvPrev>0&&(
              <>
                <ST>📈 Este mes vs anterior</ST>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:16}}>
                  <div style={{background:BLANCO,borderRadius:12,padding:"12px 14px",boxShadow:"0 2px 8px rgba(0,0,0,0.05)",borderTop:`3px solid ${VERDE}`}}>
                    <div style={{fontSize:10,color:VERDE,fontWeight:800,marginBottom:4}}>💵 VENTAS</div>
                    <div style={{fontSize:17,fontWeight:900,color:VERDE}}>{fmtMXN(totalVentasMes)}</div>
                    <div style={{fontSize:10,color:GRIS_TEXT,marginTop:2}}>{fmtMXN(tvPrev)} mes pasado</div>
                    {diffVentas&&<div style={{fontSize:11,fontWeight:800,color:diffVentas.up?VERDE:"#E53935",marginTop:2}}>{diffVentas.up?"▲":"▼"} {Math.abs(diffVentas.pct)}%</div>}
                  </div>
                  <div style={{background:BLANCO,borderRadius:12,padding:"12px 14px",boxShadow:"0 2px 8px rgba(0,0,0,0.05)",borderTop:`3px solid ${ROSA}`}}>
                    <div style={{fontSize:10,color:ROSA,fontWeight:800,marginBottom:4}}>🛒 GASTOS</div>
                    <div style={{fontSize:17,fontWeight:900,color:ROSA}}>{fmtMXN(tg)}</div>
                    <div style={{fontSize:10,color:GRIS_TEXT,marginTop:2}}>{fmtMXN(tgPrev)} mes pasado</div>
                    {diffGastos&&<div style={{fontSize:11,fontWeight:800,color:diffGastos.up?"#E53935":VERDE,marginTop:2}}>{diffGastos.up?"▲":"▼"} {Math.abs(diffGastos.pct)}%</div>}
                  </div>
                </div>
              </>
            )}

            {/* Top 3 categorías del mes */}
            {Object.keys(catTot).length>0&&(
              <>
                <ST>🏆 Top categorías de gasto</ST>
                <div style={{background:BLANCO,borderRadius:14,padding:"14px",marginBottom:16,boxShadow:"0 2px 8px rgba(0,0,0,0.05)"}}>
                  {cats.filter(c=>catTot[c.id]).sort((a,b)=>(catTot[b.id]||0)-(catTot[a.id]||0)).slice(0,3).map((c,i)=>{
                    const pct=tg?Math.round((catTot[c.id]/tg)*100):0;
                    return(
                      <div key={c.id} style={{display:"flex",alignItems:"center",gap:10,marginBottom:i<2?12:0}}>
                        <div style={{width:24,height:24,borderRadius:"50%",background:c.color,display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:900,color:BLANCO,flexShrink:0}}>{i+1}</div>
                        <div style={{flex:1,minWidth:0}}>
                          <div style={{display:"flex",justifyContent:"space-between",fontSize:13,marginBottom:4}}>
                            <span style={{color:GRIS_DARK,fontWeight:700}}>{c.emoji} {c.label}</span>
                            <span style={{color:c.color,fontWeight:900}}>{fmtMXN(catTot[c.id])}</span>
                          </div>
                          <div style={{height:5,background:"#F0F0F0",borderRadius:3,overflow:"hidden"}}>
                            <div style={{height:"100%",width:`${pct}%`,background:c.color,borderRadius:3}}/>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </>
            )}

            {/* ── COMPARACIÓN ENTRE SUCURSALES (solo viendo "Todas" y con ≥2 sucursales) ── */}
            {sucursalActiva==null&&sucursales.length>=2&&(()=>{
              // Calcular por cada sucursal: gastos, ventas, balance, recolectado, pendiente del mes
              const filas=sucursales.map(s=>{
                const gMesS=gastos.filter(g=>g.sucursal_id===s.id&&monthKey(g.fecha)===mk);
                const vMesS=ventas.filter(v=>v.sucursal_id===s.id&&monthKey(v.fecha)===mk);
                const rMesS=recolecciones.filter(r=>r.sucursal_id===s.id&&monthKey(r.fecha_recoleccion)===mk);
                const gt=gMesS.reduce((a,g)=>a+num(g.monto),0);
                const vt=vMesS.reduce((a,v)=>a+num(v.efectivo),0);
                const rt=rMesS.reduce((a,r)=>a+num(r.monto_fisico??r.monto_total),0);
                const ge=gMesS.filter(g=>g.forma==="Efectivo").reduce((a,g)=>a+num(g.monto),0);
                // Pendiente: días con venta en esta sucursal cuya (fecha,suc) no esté cubierta por una reco de la misma suc
                const recosSucCubre=recolecciones.filter(r=>r.sucursal_id===s.id).flatMap(r=>r.fechas_cubiertas||[]);
                const pend=vMesS.filter(v=>!recosSucCubre.includes(v.fecha)).reduce((a,v)=>a+num(v.efectivo),0);
                return{s,gt,vt,rt,ge,balance:vt-gt,balanceEf:vt-ge,pend};
              }).filter(f=>f.gt>0||f.vt>0||f.rt>0); // ocultar sucursales sin movimiento
              if(filas.length<2)return null;
              const maxGT=Math.max(...filas.map(f=>f.gt),1);
              const maxVT=Math.max(...filas.map(f=>f.vt),1);
              return(
                <>
                  <ST>🏪 Comparativa entre sucursales</ST>
                  <div style={{background:BLANCO,borderRadius:14,padding:"14px",marginBottom:16,boxShadow:"0 2px 8px rgba(0,0,0,0.05)"}}>
                    {filas.map((f,i)=>(
                      <div key={f.s.id} style={{paddingBottom:i<filas.length-1?12:0,marginBottom:i<filas.length-1?12:0,borderBottom:i<filas.length-1?"1px solid #F0F0F0":"none"}}>
                        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8}}>
                          <button onClick={()=>setSucursalActiva(f.s.id)}
                            style={{display:"flex",alignItems:"center",gap:6,background:"none",border:"none",cursor:"pointer",fontFamily:"inherit",padding:0}}>
                            <span style={{fontSize:18}}>{f.s.emoji}</span>
                            <span style={{fontSize:14,fontWeight:900,color:f.s.color||GRIS_DARK}}>{f.s.nombre}</span>
                            <span style={{fontSize:10,color:GRIS_TEXT,marginLeft:4}}>ver →</span>
                          </button>
                          <div style={{fontSize:14,fontWeight:900,color:f.balance>=0?VERDE:"#E53935"}}>{f.balance>=0?"+":""}{fmtMXN(f.balance)}</div>
                        </div>
                        {/* Barra ventas */}
                        <div style={{display:"flex",justifyContent:"space-between",fontSize:11,marginBottom:3}}>
                          <span style={{color:VERDE,fontWeight:700}}>💵 Ventas</span>
                          <span style={{color:VERDE,fontWeight:800}}>{fmtMXN(f.vt)}</span>
                        </div>
                        <div style={{height:5,background:"#F0F0F0",borderRadius:3,overflow:"hidden",marginBottom:6}}>
                          <div style={{height:"100%",width:`${Math.round((f.vt/maxVT)*100)}%`,background:VERDE,borderRadius:3}}/>
                        </div>
                        {/* Barra gastos */}
                        <div style={{display:"flex",justifyContent:"space-between",fontSize:11,marginBottom:3}}>
                          <span style={{color:ROSA,fontWeight:700}}>🛒 Gastos</span>
                          <span style={{color:ROSA,fontWeight:800}}>{fmtMXN(f.gt)}</span>
                        </div>
                        <div style={{height:5,background:"#F0F0F0",borderRadius:3,overflow:"hidden",marginBottom:6}}>
                          <div style={{height:"100%",width:`${Math.round((f.gt/maxGT)*100)}%`,background:ROSA,borderRadius:3}}/>
                        </div>
                        {/* Mini KPIs */}
                        <div style={{display:"flex",gap:8,marginTop:6,fontSize:10,color:GRIS_TEXT}}>
                          <span>Recolectado: <strong style={{color:AZUL}}>{fmtMXN(f.rt)}</strong></span>
                          {f.pend>0&&<span>Pendiente: <strong style={{color:AMBAR}}>{fmtMXN(f.pend)}</strong></span>}
                        </div>
                      </div>
                    ))}
                  </div>
                </>
              );
            })()}

            {/* Acceso rápido a tabs */}
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginTop:8}}>
              <button onClick={()=>setResTab("gastos")}
                style={{background:BLANCO,border:"none",borderRadius:14,padding:"14px",boxShadow:"0 2px 8px rgba(0,0,0,0.05)",cursor:"pointer",fontFamily:"inherit",textAlign:"left",borderLeft:`3px solid ${ROSA}`}}>
                <div style={{fontSize:11,color:GRIS_TEXT,fontWeight:800,textTransform:"uppercase",letterSpacing:0.4}}>💸 Ver gastos</div>
                <div style={{fontSize:15,fontWeight:900,color:ROSA,marginTop:4}}>{listaCompleta.length} este mes</div>
                <div style={{fontSize:10,color:GRIS_TEXT,marginTop:2}}>Toca para detalle →</div>
              </button>
              <button onClick={()=>setResTab("recolecciones")}
                style={{background:BLANCO,border:"none",borderRadius:14,padding:"14px",boxShadow:"0 2px 8px rgba(0,0,0,0.05)",cursor:"pointer",fontFamily:"inherit",textAlign:"left",borderLeft:`3px solid ${AZUL}`}}>
                <div style={{fontSize:11,color:GRIS_TEXT,fontWeight:800,textTransform:"uppercase",letterSpacing:0.4}}>💰 Cobranza</div>
                <div style={{fontSize:15,fontWeight:900,color:AZUL,marginTop:4}}>{recoleccionesMes.length} recolecciones</div>
                <div style={{fontSize:10,color:GRIS_TEXT,marginTop:2}}>Toca para detalle →</div>
              </button>
            </div>
          </>
        )}

        {/* ═══════════════════════════════════════════════════ */}
        {/* TAB 2: GASTOS — todo lo de gastos en un solo lugar */}
        {/* ═══════════════════════════════════════════════════ */}
        {resTab==="gastos"&&(
          <>
            {/* Desglose por método de pago */}
            {tg>0&&(
              <>
                <ST>💳 Por método de pago</ST>
                <div style={{background:BLANCO,borderRadius:14,padding:"14px",marginBottom:14,boxShadow:"0 2px 8px rgba(0,0,0,0.05)"}}>
                  {Object.entries(porForma).sort((a,b)=>b[1]-a[1]).map(([forma,monto])=>{
                    const pct=tg?Math.round((monto/tg)*100):0;
                    const esEfectivo=forma==="Efectivo";
                    const color=esEfectivo?VERDE:AZUL;
                    const emoji=esEfectivo?"💵":forma.toLowerCase().includes("tarjeta")?"💳":forma.toLowerCase().includes("transfer")?"🏦":forma.toLowerCase().includes("mercado")?"📱":"💰";
                    return(
                      <div key={forma} style={{marginBottom:10}}>
                        <div style={{display:"flex",justifyContent:"space-between",fontSize:13,marginBottom:4}}>
                          <span style={{color:GRIS_DARK,fontWeight:700}}>{emoji} {forma}</span>
                          <span style={{color,fontWeight:800}}>{fmtMXN(monto)} <span style={{color:GRIS_TEXT,fontWeight:600,fontSize:11}}>({pct}%)</span></span>
                        </div>
                        <div style={{height:5,background:"#F0F0F0",borderRadius:3,overflow:"hidden"}}>
                          <div style={{height:"100%",width:`${pct}%`,background:color,borderRadius:3}}/>
                        </div>
                      </div>
                    );
                  })}
                  <div style={{display:"flex",justifyContent:"space-between",fontSize:11,color:GRIS_TEXT,marginTop:8,paddingTop:10,borderTop:"1px solid #F0F0F0"}}>
                    <span>💵 Efectivo: <strong style={{color:VERDE}}>{fmtMXN(tgEfectivo)}</strong></span>
                    <span>💳 Otros: <strong style={{color:AZUL}}>{fmtMXN(tgOtros)}</strong></span>
                  </div>
                </div>
              </>
            )}

            {/* Filtros */}
            <ST>🔍 Filtrar</ST>
            <div style={{position:"relative",marginBottom:10}}>
              <input value={resBuscar} onChange={e=>setResBuscar(e.target.value)}
                placeholder="🔍 Buscar proveedor o concepto..."
                style={{...S.input,paddingRight:resBuscar?40:14}}/>
              {resBuscar&&(
                <button onClick={()=>setResBuscar("")}
                  style={{position:"absolute",right:8,top:"50%",transform:"translateY(-50%)",background:"none",border:"none",fontSize:18,color:GRIS_MED,cursor:"pointer"}}>×</button>
              )}
            </div>

            {/* Filtro categoría */}
            <div style={{fontSize:11,color:GRIS_TEXT,fontWeight:800,marginBottom:6,textTransform:"uppercase",letterSpacing:0.4}}>Categoría</div>
            <div style={{...S.chipRow,marginBottom:12,overflowX:"auto",flexWrap:"nowrap",paddingBottom:4}}>
              <Chip active={resCat==="todos"} color={GRIS_MED} onClick={()=>setResCat("todos")}>Todas</Chip>
              {cats.filter(c=>catTot[c.id]).sort((a,b)=>(catTot[b.id]||0)-(catTot[a.id]||0)).map(c=>(
                <Chip key={c.id} active={resCat===c.id} color={c.color} onClick={()=>setResCat(resCat===c.id?"todos":c.id)}>
                  {c.emoji} {c.label} · {fmtMXN(catTot[c.id])}
                </Chip>
              ))}
            </div>

            {/* Filtro persona */}
            <div style={{fontSize:11,color:GRIS_TEXT,fontWeight:800,marginBottom:6,textTransform:"uppercase",letterSpacing:0.4}}>Persona</div>
            <div style={{...S.chipRow,marginBottom:12}}>
              <Chip active={filtroQ==="todos"} color={GRIS_MED} onClick={()=>setFiltroQ("todos")}>Todos</Chip>
              {Object.entries(quien).sort((a,b)=>b[1]-a[1]).map(([nombre,monto])=>(
                <Chip key={nombre} active={filtroQ===nombre} color={ROSA} onClick={()=>setFiltroQ(filtroQ===nombre?"todos":nombre)}>
                  {nombre} · {fmtMXN(monto)}
                </Chip>
              ))}
            </div>

            {/* Filtro fechas colapsable */}
            <button onClick={()=>setResFiltrosOpen(!resFiltrosOpen)}
              style={{width:"100%",marginBottom:resFiltrosOpen?0:14,background:GRIS_LIGHT,border:"none",borderRadius:resFiltrosOpen?"10px 10px 0 0":10,padding:"8px 14px",fontSize:11,fontWeight:800,color:GRIS_MED,cursor:"pointer",fontFamily:"inherit",textTransform:"uppercase",letterSpacing:0.4,textAlign:"left"}}>
              📅 Rango de fechas {resFiltrosOpen?"▲":"▼"}
              {(resDesde||resHasta)&&<span style={{marginLeft:8,fontSize:10,color:ROSA}}>● activo</span>}
            </button>
            {resFiltrosOpen&&(
              <div style={{marginBottom:14,background:GRIS_LIGHT,borderRadius:"0 0 10px 10px",padding:"4px 14px 12px"}}>
                <div style={{display:"flex",gap:8,marginTop:8}}>
                  <div style={{flex:1}}>
                    <FL>Desde</FL>
                    <input type="date" value={resDesde} onChange={e=>setResDesde(e.target.value)} style={S.input}/>
                  </div>
                  <div style={{flex:1}}>
                    <FL>Hasta</FL>
                    <input type="date" value={resHasta} onChange={e=>setResHasta(e.target.value)} style={S.input}/>
                  </div>
                </div>
              </div>
            )}

            {/* Indicador filtros activos */}
            {(resCat!=="todos"||filtroQ!=="todos"||resBuscar||resDesde||resHasta)&&(
              <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",background:ROSA_BG,padding:"10px 14px",borderRadius:12,marginBottom:14,border:`1px solid ${ROSA}33`}}>
                <div style={{fontSize:12,color:ROSA,fontWeight:800}}>
                  📊 {lista.length}/{gMes(mk).length} · <strong>{fmtMXN(tg)}</strong>
                </div>
                <button onClick={()=>{setResCat("todos");setFiltroQ("todos");setResBuscar("");setResDesde("");setResHasta("");}}
                  style={{background:"none",border:"none",color:ROSA,fontSize:12,fontWeight:700,cursor:"pointer",fontFamily:"inherit"}}>
                  ✕ Limpiar
                </button>
              </div>
            )}

            {/* Lista de gastos */}
            <ST>📋 Gastos {lista.length>0?`(${lista.length})`:""}</ST>
            {lista.length===0?<Empty>Sin gastos con esos filtros</Empty>:lista.map(g=><GastoRow key={g.id} g={g} onDelete={deleteGasto} onEdit={startEdit} inusual={esInusual(g.cat,g.monto)} canEdit={usuarioActual==="Andres"||usuarioActual==="José Luis"||(usuarioActual!=="Apolo"&&g.quien===usuarioActual)} sucursalLabel={mkSucLabel(g.sucursal_id)} cats={cats}/>)}
          </>
        )}

        {/* ═══════════════════════════════════════════════════ */}
        {/* TAB 3: RECOLECCIONES — toda la cobranza */}
        {/* ═══════════════════════════════════════════════════ */}
        {resTab==="recolecciones"&&(
          <>
            {/* Resumen recolectado */}
            <div style={{background:BLANCO,borderRadius:14,padding:"14px",marginBottom:14,boxShadow:"0 2px 8px rgba(0,0,0,0.05)"}}>
              <div style={{display:"flex",justifyContent:"space-between",paddingBottom:10,marginBottom:10,borderBottom:"1px solid #F0F0F0"}}>
                <div>
                  <div style={{fontSize:11,color:GRIS_TEXT,fontWeight:700,marginBottom:2}}>EFECTIVO RECOLECTADO</div>
                  <div style={{fontSize:24,fontWeight:900,color:VERDE}}>{fmtMXN(totalRecolectadoMes)}</div>
                  <div style={{fontSize:11,color:GRIS_TEXT,marginTop:2}}>{recoleccionesMes.length} recolección{recoleccionesMes.length!==1?"es":""}</div>
                </div>
                {faltantesMes>0&&(
                  <div style={{textAlign:"right"}}>
                    <div style={{fontSize:11,color:"#E53935",fontWeight:700,marginBottom:2}}>FALTANTES</div>
                    <div style={{fontSize:18,fontWeight:900,color:"#E53935"}}>{fmtMXN(faltantesMes)}</div>
                  </div>
                )}
              </div>
              {Object.entries(recoPorPersona).sort((a,b)=>b[1]-a[1]).map(([nombre,monto])=>{
                const pct=totalRecolectadoMes?Math.round((monto/totalRecolectadoMes)*100):0;
                return(
                  <div key={nombre} style={{marginBottom:8}}>
                    <div style={{display:"flex",justifyContent:"space-between",fontSize:13,marginBottom:3}}>
                      <span style={{color:GRIS_DARK,fontWeight:700}}>{nombre==="Apolo"?"🧑 ":"👤 "}{nombre}</span>
                      <span style={{color:VERDE,fontWeight:800}}>{fmtMXN(monto)} <span style={{color:GRIS_TEXT,fontWeight:600,fontSize:11}}>({pct}%)</span></span>
                    </div>
                    <div style={{height:5,background:"#F0F0F0",borderRadius:3,overflow:"hidden"}}>
                      <div style={{height:"100%",width:`${pct}%`,background:VERDE,borderRadius:3}}/>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Pendiente de recolectar */}
            {diasMesPendientes.length>0&&(
              <div style={{background:VERDE_BG,border:`1px solid ${VERDE}`,borderRadius:12,padding:"12px 14px",marginBottom:14}}>
                <div style={{fontSize:11,color:VERDE,fontWeight:800,textTransform:"uppercase",letterSpacing:0.4}}>⏳ Pendiente de recolectar</div>
                <div style={{fontSize:20,fontWeight:900,color:VERDE,marginTop:4}}>{fmtMXN(pendienteMes)}</div>
                <div style={{fontSize:11,color:VERDE,marginTop:2}}>{diasMesPendientes.length} día{diasMesPendientes.length!==1?"s":""} sin recolectar</div>
              </div>
            )}

            {/* Notas de ventas */}
            {ventasMes.filter(v=>v.nota).length>0&&(
              <>
                <ST>📝 Notas de ventas</ST>
                {ventasMes.filter(v=>v.nota).map(v=>(
                  <div key={v.id} style={{background:BLANCO,borderRadius:12,padding:"10px 14px",marginBottom:8,boxShadow:"0 2px 6px rgba(0,0,0,0.04)",borderLeft:`3px solid ${VERDE}`}}>
                    <div style={{fontSize:11,color:GRIS_TEXT,marginBottom:3}}>{v.fecha} · {v.quien||"—"} · {fmtMXN(v.efectivo)}</div>
                    <div style={{fontSize:13,color:GRIS_DARK,fontStyle:"italic"}}>{v.nota}</div>
                  </div>
                ))}
              </>
            )}

            {/* Lista de recolecciones del mes */}
            {recoleccionesMes.length>0&&(
              <>
                <ST>💰 Recolecciones del mes</ST>
                {recoleccionesMes.sort((a,b)=>b.fecha_recoleccion.localeCompare(a.fecha_recoleccion)).map(r=>{
                  const sl=mkSucLabel(r.sucursal_id);
                  return(
                  <button key={r.id} onClick={()=>{setSelRec(r);setView("detalle-recoleccion");}}
                    style={{display:"block",width:"100%",textAlign:"left",background:BLANCO,borderRadius:12,padding:"12px 14px",marginBottom:8,boxShadow:"0 2px 6px rgba(0,0,0,0.04)",border:"none",cursor:"pointer",fontFamily:"inherit"}}>
                    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                      <div>
                        <div style={{display:"flex",alignItems:"center",gap:6,flexWrap:"wrap"}}>
                          <div style={{fontSize:13,fontWeight:800,color:GRIS_DARK}}>{r.fecha_recoleccion} · {r.quien}</div>
                          {sl&&<span style={{fontSize:10,background:sl.bg,color:sl.color,borderRadius:6,padding:"1px 6px",fontWeight:700}}>{sl.emoji} {sl.nombre}</span>}
                        </div>
                        <div style={{fontSize:11,color:GRIS_TEXT,marginTop:2}}>{(r.fechas_cubiertas||[]).length} día{(r.fechas_cubiertas||[]).length!==1?"s":""} cubierto{(r.fechas_cubiertas||[]).length!==1?"s":""}</div>
                      </div>
                      <div style={{textAlign:"right"}}>
                        <div style={{fontSize:15,fontWeight:900,color:VERDE}}>{fmtMXN(r.monto_fisico??r.monto_total)}</div>
                        {num(r.faltante)>0&&<div style={{fontSize:11,color:"#E53935",fontWeight:700}}>−{fmtMXN(r.faltante)}</div>}
                      </div>
                    </div>
                  </button>
                  );
                })}
              </>
            )}

            {recoleccionesMes.length===0&&<Empty>Sin recolecciones este mes</Empty>}
          </>
        )}
      </Screen>
    );
  }


  // ══════════════════════════════════════════════════════════════════════════
  // VISTA: HISTORIAL
  // ══════════════════════════════════════════════════════════════════════════
  if(view==="historial"){if(!PUEDE_VER_NUMEROS.includes(usuarioActual))return null; return(
    <Screen title="Historial" onBack={()=>setView("inicio")}
      action={<ExportBtn label="📥 Todo" onClick={()=>exportExcel(gastos,ventas,recolecciones,null,sucursales,sucursalActiva,cats)}/>}>
      {months.length===0?<Empty>Sin registros</Empty>:months.map(mk=>(
        <button key={mk} onClick={()=>{setSelMonth(mk);setView("detalle");}} style={S.monthCard}>
          <div>
            <div style={{fontWeight:800,fontSize:16,color:GRIS_DARK}}>{monthLabel(mk)}</div>
            <div style={{fontSize:12,color:GRIS_TEXT,marginTop:3}}>{gMes(mk).length} gastos</div>
          </div>
          <div style={{textAlign:"right"}}>
            <div style={{fontWeight:900,fontSize:20,color:ROSA}}>{fmtMXN(totG(mk))}</div>
            <div style={{fontSize:11,color:"#CCC",marginTop:2}}>ver →</div>
          </div>
        </button>
      ))}
    </Screen>
  );
  }

  // ══════════════════════════════════════════════════════════════════════════
  // VISTA: DETALLE MES
  // ══════════════════════════════════════════════════════════════════════════
  if(view==="detalle"&&selMonth){
    const mk=selMonth,tg=totG(mk),catTot=porCat(mk);
    const lista=gMes(mk).sort((a,b)=>b.fecha.localeCompare(a.fecha));
    return(
      <Screen title={monthLabel(mk)} onBack={()=>setView("historial")}
        action={<ExportBtn onClick={()=>exportExcel(gastos,ventas,recolecciones,mk,sucursales,sucursalActiva,cats)}/>}>
        <div style={S.heroCard}>
          <div style={{fontSize:12,color:"rgba(255,255,255,0.7)",marginBottom:4}}>Total del mes</div>
          <div style={{fontSize:40,fontWeight:900,letterSpacing:-1.5}}>{fmtMXN(tg)}</div>
          <div style={{fontSize:12,color:"rgba(255,255,255,0.65)",marginTop:4}}>{lista.length} registros</div>
        </div>
        <ST>Por categoría</ST>
        {cats.filter(c=>catTot[c.id]).sort((a,b)=>(catTot[b.id]||0)-(catTot[a.id]||0)).map(c=>{
          const pct=tg?Math.round((catTot[c.id]/tg)*100):0;
          return(
            <div key={c.id} style={S.catRow}>
              <div style={{...S.catEmoji,background:c.color+"22",color:c.color}}>{c.emoji}</div>
              <div style={{flex:1}}>
                <div style={{fontWeight:700,fontSize:13}}>{c.label}</div>
                <div style={{height:4,background:"#F0F0F0",borderRadius:2,marginTop:5,overflow:"hidden"}}>
                  <div style={{height:"100%",width:`${pct}%`,background:c.color,borderRadius:2}}/>
                </div>
                <div style={{fontSize:10,color:GRIS_TEXT,marginTop:2}}>{pct}%</div>
              </div>
              <div style={{fontWeight:800,color:c.color,fontSize:14,marginLeft:12}}>{fmtMXN(catTot[c.id])}</div>
            </div>
          );
        })}
        <ST>Todos los gastos</ST>
        {lista.map(g=><GastoRow key={g.id} g={g} onDelete={deleteGasto} onEdit={startEdit} inusual={esInusual(g.cat,g.monto)} canEdit={usuarioActual==="Andres"||usuarioActual==="José Luis"||(usuarioActual!=="Apolo"&&g.quien===usuarioActual)} sucursalLabel={mkSucLabel(g.sucursal_id)} cats={cats}/>)}
      </Screen>
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  // VISTA: ANALÍTICA / TENDENCIAS
  // ══════════════════════════════════════════════════════════════════════════
  if(view==="analitica"){if(!PUEDE_VER_NUMEROS.includes(usuarioActual))return null;
    // Últimos 6 meses
    const ultimos6=[];
    for(let i=5;i>=0;i--){const d=new Date();d.setMonth(d.getMonth()-i);ultimos6.push(monthKey(d.toISOString()));}
    const dataBarras=ultimos6.map(mk=>({
      mes:monthLabel(mk).slice(0,3),
      gastos:totG(mk),
      ventas:ventas.filter(v=>monthKey(v.fecha)===mk).reduce((s,v)=>s+num(v.efectivo),0),
      recolectado:recolecciones.filter(r=>monthKey(r.fecha_recoleccion)===mk).reduce((s,r)=>s+num(r.monto_total),0),
    }));
    const maxVal=Math.max(...dataBarras.flatMap(d=>[d.gastos,d.ventas]),1);
    const mk=currentMK;
    const tvM=ventas.filter(v=>monthKey(v.fecha)===mk).reduce((s,v)=>s+num(v.efectivo),0);
    const tgM=totG(mk);
    const balance=tvM-tgM;
    // Desglose gastos del mes por método (efectivo vs otros)
    const tgEfectivoM=gMes(mk).filter(g=>g.forma==="Efectivo").reduce((s,g)=>s+num(g.monto),0);
    const tgOtrosM=tgM-tgEfectivoM;
    const balanceEfectivo=tvM-tgEfectivoM;
    // Dias de venta ultimos 30 dias
    const ventasOrdenadas=[...ventas].sort((a,b)=>a.fecha.localeCompare(b.fecha)).slice(-30);
    const promedioVenta=ventasOrdenadas.length?ventasOrdenadas.reduce((s,v)=>s+num(v.efectivo),0)/ventasOrdenadas.length:0;
    // Top 3 proveedores por gasto total
    const gastosPorConcepto={};
    gastos.forEach(g=>{if(!gastosPorConcepto[g.concepto])gastosPorConcepto[g.concepto]=0;gastosPorConcepto[g.concepto]+=g.monto;});
    const topProveedores=Object.entries(gastosPorConcepto).sort((a,b)=>b[1]-a[1]).slice(0,5);
    const totalGastosTodo=gastos.reduce((s,g)=>s+num(g.monto),0);
    // Días de semana con más ventas
    const ventasPorDia={};
    const diasNombres=["Dom","Lun","Mar","Mié","Jue","Vie","Sáb"];
    ventas.forEach(v=>{const d=new Date(v.fecha+"T12:00:00").getDay();if(!ventasPorDia[d])ventasPorDia[d]={total:0,count:0};ventasPorDia[d].total+=(v.efectivo||0);ventasPorDia[d].count++;});
    const avgPorDia=diasNombres.map((_,i)=>ventasPorDia[i]?ventasPorDia[i].total/ventasPorDia[i].count:0);
    const maxAvgDia=Math.max(...avgPorDia,1);

    return(
      <Screen title="Tendencias 📉" onBack={()=>setView("inicio")} action={<ExportBtn onClick={()=>exportExcel(gastos,ventas,recolecciones,null,sucursales,sucursalActiva,cats)} label="📥 Excel"/>}>

        {/* KPIs del mes */}
        <ST>📅 Este mes — {monthLabel(mk)}</ST>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:16}}>
          {[
            {label:"💵 Ventas",val:tvM,color:VERDE},
            {label:"📊 Prom/día",val:promedioVenta,color:AZUL},
            {label:"💵 Gastos efectivo",val:tgEfectivoM,color:ROSA},
            {label:"💳 Gastos otros",val:tgOtrosM,color:AZUL},
            {label:`${balance>=0?"✅":"🔴"} Balance total`,val:balance,color:balance>=0?VERDE:"#E53935"},
            {label:`${balanceEfectivo>=0?"✅":"🔴"} Balance efectivo`,val:balanceEfectivo,color:balanceEfectivo>=0?VERDE:"#E53935"},
          ].map(k=>(
            <div key={k.label} style={{background:BLANCO,borderRadius:14,padding:"14px 12px",boxShadow:"0 2px 10px rgba(0,0,0,0.06)",borderTop:`3px solid ${k.color}`}}>
              <div style={{fontSize:10,color:k.color,fontWeight:800,marginBottom:6}}>{k.label}</div>
              <div style={{fontSize:19,fontWeight:900,color:k.color}}>{fmtMXN(k.val)}</div>
            </div>
          ))}
        </div>

        {/* Gráfica de barras: Ventas vs Gastos últimos 6 meses */}
        <ST>📊 Ventas vs Gastos — últimos 6 meses</ST>
        <div style={{background:BLANCO,borderRadius:16,padding:"16px 12px 12px",marginBottom:16,boxShadow:"0 2px 10px rgba(0,0,0,0.06)"}}>
          <div style={{display:"flex",gap:12,marginBottom:8}}>
            <div style={{display:"flex",alignItems:"center",gap:4,fontSize:11,color:VERDE,fontWeight:700}}><div style={{width:10,height:10,borderRadius:2,background:VERDE}}/> Ventas</div>
            <div style={{display:"flex",alignItems:"center",gap:4,fontSize:11,color:ROSA,fontWeight:700}}><div style={{width:10,height:10,borderRadius:2,background:ROSA}}/> Gastos</div>
          </div>
          <div style={{display:"flex",alignItems:"flex-end",gap:6,height:120}}>
            {dataBarras.map((d,i)=>(
              <div key={i} style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",gap:2}}>
                <div style={{width:"100%",display:"flex",gap:2,alignItems:"flex-end",height:100}}>
                  <div style={{flex:1,background:VERDE,borderRadius:"3px 3px 0 0",height:`${maxVal?Math.round((d.ventas/maxVal)*100):0}%`,minHeight:d.ventas>0?3:0,transition:"height 0.5s"}}/>
                  <div style={{flex:1,background:ROSA,borderRadius:"3px 3px 0 0",height:`${maxVal?Math.round((d.gastos/maxVal)*100):0}%`,minHeight:d.gastos>0?3:0,transition:"height 0.5s"}}/>
                </div>
                <div style={{fontSize:9,color:GRIS_TEXT,fontWeight:700,marginTop:2}}>{d.mes}</div>
              </div>
            ))}
          </div>
          <div style={{display:"flex",justifyContent:"space-between",marginTop:8,paddingTop:8,borderTop:"1px solid #F5F5F5"}}>
            {dataBarras.map((d,i)=>(
              <div key={i} style={{flex:1,textAlign:"center"}}>
                <div style={{fontSize:8,color:d.ventas>=d.gastos?VERDE:"#E53935",fontWeight:800}}>
                  {d.ventas||d.gastos?`${d.ventas>=d.gastos?"+":"-"}${fmtMXN(Math.abs(d.ventas-d.gastos)).replace("$","").replace(",","k").slice(0,4)}`:"—"}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Promedio de venta por día de semana */}
        <ST>📅 ¿Qué días se vende más?</ST>
        <div style={{background:BLANCO,borderRadius:16,padding:"16px 12px 12px",marginBottom:16,boxShadow:"0 2px 10px rgba(0,0,0,0.06)"}}>
          <div style={{display:"flex",alignItems:"flex-end",gap:4,height:80}}>
            {diasNombres.map((dia,i)=>{
              const pct=maxAvgDia?Math.round((avgPorDia[i]/maxAvgDia)*100):0;
              const esMejor=avgPorDia[i]===Math.max(...avgPorDia);
              return(
                <div key={i} style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",gap:3}}>
                  <div style={{width:"100%",background:esMejor?VERDE:GRIS_LIGHT,borderRadius:"4px 4px 0 0",height:`${pct}%`,minHeight:avgPorDia[i]>0?4:0,transition:"height 0.5s"}}/>
                  <div style={{fontSize:9,fontWeight:esMejor?900:600,color:esMejor?VERDE:GRIS_TEXT}}>{dia}</div>
                </div>
              );
            })}
          </div>
          <div style={{fontSize:11,color:GRIS_TEXT,marginTop:10,textAlign:"center"}}>
            Promedio de venta efectivo por día de la semana
          </div>
        </div>

        {/* Top proveedores */}
        <ST>🏆 Top proveedores / gastos acumulados</ST>
        <div style={{background:BLANCO,borderRadius:16,padding:"14px",marginBottom:16,boxShadow:"0 2px 10px rgba(0,0,0,0.06)"}}>
          {topProveedores.length===0?<Empty>Sin datos</Empty>:topProveedores.map(([nombre,monto],i)=>{
            const pct=totalGastosTodo?Math.round((monto/totalGastosTodo)*100):0;
            const colores=[ROSA,AMBAR,AZUL,VERDE,"#6A1B9A"];
            return(
              <div key={nombre} style={{marginBottom:12}}>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
                  <div style={{fontSize:13,fontWeight:700,color:GRIS_DARK}}>{i+1}. {nombre}</div>
                  <div style={{fontSize:13,fontWeight:900,color:colores[i]}}>{fmtMXN(monto)}</div>
                </div>
                <div style={{height:6,background:"#F0F0F0",borderRadius:3,overflow:"hidden"}}>
                  <div style={{height:"100%",width:`${pct}%`,background:colores[i],borderRadius:3,transition:"width 0.5s"}}/>
                </div>
                <div style={{fontSize:10,color:GRIS_TEXT,marginTop:2}}>{pct}% del total</div>
              </div>
            );
          })}
        </div>

        {/* Gráfica de categorías acumuladas (todo el tiempo) */}
        <ST>🍰 Distribución de gastos por categoría</ST>
        <div style={{background:BLANCO,borderRadius:16,padding:"14px",marginBottom:16,boxShadow:"0 2px 10px rgba(0,0,0,0.06)"}}>
          {cats.filter(c=>{const tot=gastos.filter(g=>g.cat===c.id).reduce((s,g)=>s+num(g.monto),0);return tot>0;}).sort((a,b)=>{
            const ta=gastos.filter(g=>g.cat===a.id).reduce((s,g)=>s+num(g.monto),0);
            const tb=gastos.filter(g=>g.cat===b.id).reduce((s,g)=>s+num(g.monto),0);
            return tb-ta;
          }).map(c=>{
            const tot=gastos.filter(g=>g.cat===c.id).reduce((s,g)=>s+num(g.monto),0);
            const pct=totalGastosTodo?Math.round((tot/totalGastosTodo)*100):0;
            return(
              <div key={c.id} style={{display:"flex",alignItems:"center",gap:10,marginBottom:10}}>
                <div style={{width:32,height:32,borderRadius:8,background:c.color+"22",color:c.color,display:"flex",alignItems:"center",justifyContent:"center",fontSize:16,flexShrink:0}}>{c.emoji}</div>
                <div style={{flex:1}}>
                  <div style={{display:"flex",justifyContent:"space-between",marginBottom:3}}>
                    <span style={{fontSize:12,fontWeight:700}}>{c.label}</span>
                    <span style={{fontSize:12,fontWeight:900,color:c.color}}>{fmtMXN(tot)}</span>
                  </div>
                  <div style={{height:5,background:"#F0F0F0",borderRadius:3,overflow:"hidden"}}>
                    <div style={{height:"100%",width:`${pct}%`,background:c.color,borderRadius:3}}/>
                  </div>
                </div>
                <div style={{fontSize:11,fontWeight:700,color:GRIS_TEXT,width:28,textAlign:"right"}}>{pct}%</div>
              </div>
            );
          })}
        </div>

        {/* Reporte para inversores */}
        <ST>📋 Resumen ejecutivo (inversores)</ST>
        <div style={{background:BLANCO,borderRadius:16,padding:"18px",marginBottom:16,boxShadow:"0 2px 10px rgba(0,0,0,0.06)",border:`1.5px solid ${ROSA}22`}}>
          <div style={{fontSize:14,fontWeight:900,color:GRIS_DARK,marginBottom:12}}>Lady Fresa · {monthLabel(mk)}</div>
          {[
            {label:"Ventas efectivo",val:fmtMXN(tvM),color:VERDE},
            {label:"Gastos en efectivo",val:fmtMXN(tgEfectivoM),color:ROSA},
            {label:"Gastos con tarjeta / otros",val:fmtMXN(tgOtrosM),color:AZUL},
            {label:"Total gastos operativos",val:fmtMXN(tgM),color:ROSA},
            {label:"Balance neto (total)",val:fmtMXN(balance),color:balance>=0?VERDE:"#E53935"},
            {label:"Balance efectivo (caja)",val:fmtMXN(balanceEfectivo),color:balanceEfectivo>=0?VERDE:"#E53935"},
            {label:"Margen bruto",val:tvM>0?`${Math.round(((tvM-tgM)/tvM)*100)}%`:"—",color:balance>=0?VERDE:"#E53935"},
            {label:"Efectivo pendiente recolección",val:fmtMXN(montoPendiente),color:AMBAR},
            {label:"Créditos por pagar",val:fmtMXN(creditosPendientes.reduce((s,g)=>s+num(g.monto),0)),color:creditosPendientes.length>0?AMBAR:VERDE},
            {label:"Días con venta registrada",val:`${ventas.filter(v=>monthKey(v.fecha)===mk).length} días`,color:AZUL},
            {label:"Ticket promedio diario",val:fmtMXN(promedioVenta),color:AZUL},
          ].map(r=>(
            <div key={r.label} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"8px 0",borderBottom:"1px solid #F5F5F5"}}>
              <span style={{fontSize:12,color:GRIS_MED}}>{r.label}</span>
              <span style={{fontSize:13,fontWeight:900,color:r.color}}>{r.val}</span>
            </div>
          ))}
          <div style={{marginTop:12,padding:"10px 12px",background:ROSA_BG,borderRadius:10,fontSize:11,color:GRIS_MED,lineHeight:1.5}}>
            💡 Exporta el Excel para el detalle completo de gastos, ventas y recolecciones con desglose por categoría.
          </div>
        </div>

      </Screen>
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  // VISTA: ADMIN DE SUCURSALES (solo Andres / José Luis)
  // ══════════════════════════════════════════════════════════════════════════
  if(view==="admin-sucursales"){
    if(!PUEDE_ADMIN_SUC.includes(usuarioActual))return null;
    return(
      <AdminSucursalesView
        sucursales={sucursales} setView={setView}
        sucursalActiva={sucursalActiva} setSucursalActiva={setSucursalActiva}
        onChange={fetchS}
        gastos={gastos} ventas={ventas} recolecciones={recolecciones}/>
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  // VISTA: ADMIN DE CATEGORÍAS (solo Andres / José Luis)
  // ══════════════════════════════════════════════════════════════════════════
  if(view==="admin-categorias"){
    if(!PUEDE_ADMIN_CAT.includes(usuarioActual))return null;
    return(
      <AdminCategoriasView
        cats={cats} sucursales={sucursales} setView={setView}
        onChange={fetchC} gastos={gastos}/>
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  // VISTA: ADMIN DE TARJETAS (solo Andres / José Luis)
  // ══════════════════════════════════════════════════════════════════════════
  if(view==="admin-tarjetas"){
    if(!PUEDE_VER_NUMEROS.includes(usuarioActual))return null;
    return<AdminTarjetasView tarjetas={tarjetas} onSave={saveTarjetas} setView={setView}/>;
  }

  // ══════════════════════════════════════════════════════════════════════════
  // VISTA: INICIO
  // ══════════════════════════════════════════════════════════════════════════
  return(
    <div style={S.root}>
      <div style={S.header}>
        <div style={{display:"flex",alignItems:"center",gap:10}}>
          <span style={{fontSize:30}}>🍓</span>
          <div>
            <div style={S.headerTitle}>Lady Fresa</div>
            <div style={S.headerSub}>Control de gastos</div>
          </div>
        </div>
        <div style={{display:"flex",alignItems:"center",gap:8}}>
          {PUEDE_VER_NUMEROS.includes(usuarioActual)&&(creditosPendientes.length>0)&&(
            <button onClick={()=>setView("creditos")}
              style={{background:vencidos.length>0?"#FFEBEE":AMBAR_BG,border:`1px solid ${vencidos.length>0?"#EF9A9A":"#FFE082"}`,borderRadius:10,padding:"5px 10px",fontSize:12,fontWeight:700,color:vencidos.length>0?"#E53935":AMBAR,cursor:"pointer"}}>
              ⏳ {creditosPendientes.length}
            </button>
          )}
          {usuarioActual==="José Luis"&&recoleccionesPendientesAprobacion.length>0&&(
            <button onClick={()=>setView("recoleccion")}
              style={{background:"#FFF8E1",border:"2px solid #FFD700",borderRadius:10,padding:"5px 10px",fontSize:12,fontWeight:700,color:"#E65100",cursor:"pointer",animation:"pulse 1.5s infinite"}}>
              🔔 {recoleccionesPendientesAprobacion.length} por aprobar
            </button>
          )}
          <button onClick={()=>{localStorage.removeItem("lf_usuario");setUsuarioActual(null);}}
            style={{background:ROSA_BG,border:`1.5px solid ${ROSA}`,borderRadius:10,padding:"5px 10px",
              fontSize:11,fontWeight:800,color:ROSA,cursor:"pointer"}}>
            👤 {usuarioActual}
          </button>
        </div>
      </div>

      {/* ── BARRA DE SUCURSALES ── */}
      <SucursalBar
        sucursales={sucursales} sucursalActiva={sucursalActiva}
        setSucursalActiva={setSucursalActiva}
        puedeAdmin={PUEDE_ADMIN_SUC.includes(usuarioActual)}
        onAdmin={()=>setView("admin-sucursales")}
        onAdminCat={PUEDE_ADMIN_CAT.includes(usuarioActual)?()=>setView("admin-categorias"):null}/>

      <div style={S.hero}>
        <div style={S.heroDate}>{new Date().toLocaleDateString("es-MX",{weekday:"long",day:"numeric",month:"long"})}</div>
        {sucActivaObj&&(
          <div style={{fontSize:13,color:"rgba(255,255,255,0.9)",fontWeight:700,marginBottom:6,display:"inline-flex",alignItems:"center",gap:6,background:"rgba(0,0,0,0.18)",borderRadius:10,padding:"4px 10px"}}>
            <span>{sucActivaObj.emoji}</span>
            <span>{sucActivaObj.nombre}</span>
          </div>
        )}
        {PUEDE_VER_NUMEROS.includes(usuarioActual)
          ?<>
            <div style={S.heroAmount}>{fmtMXN(todayTG)}</div>
            <div style={{fontSize:13,color:"rgba(255,255,255,0.65)",marginTop:4}}>
              {todayG.length} gasto{todayG.length!==1?"s":""} hoy{todayV?` · venta ${fmtMXN(todayV.efectivo)}`:""}
            </div>
            <div style={S.heroStats}>
              <div style={S.heroStat}><div style={S.heroStatNum}>{fmtMXN(totG(currentMK))}</div><div style={S.heroStatLabel}>gastos mes</div></div>
              <div style={{width:1,background:"rgba(255,255,255,0.2)"}}/>
              <div style={S.heroStat}><div style={{...S.heroStatNum,color:montoPendiente>0?"#FFE082":"#A5F3A5"}}>{fmtMXN(montoPendiente)}</div><div style={S.heroStatLabel}>por recolectar</div></div>
              <div style={{width:1,background:"rgba(255,255,255,0.2)"}}/>
              <div style={S.heroStat}><div style={{...S.heroStatNum,color:creditosPendientes.length>0?"#FFE082":"#A5F3A5"}}>{creditosPendientes.length}</div><div style={S.heroStatLabel}>créditos</div></div>
            </div>
          </>
          :<>
            <div style={{fontSize:28,fontWeight:900,color:"rgba(255,255,255,0.9)",marginTop:8}}>
              {todayG.length > 0 ? `${todayG.length} gasto${todayG.length!==1?"s":""} registrado${todayG.length!==1?"s":""}` : "Sin gastos hoy"}
            </div>
            <div style={{fontSize:13,color:"rgba(255,255,255,0.6)",marginTop:6}}>Hola, {usuarioActual} 👋</div>
          </>
        }
      </div>

      <div style={{padding:"0 16px 8px",display:"flex",flexDirection:"column",gap:10}}>
        <button onClick={()=>setView("nuevo")} style={S.fabBig}>
          <span style={{fontSize:24}}>+</span>
          <span style={{fontSize:16,fontWeight:800}}>Registrar Gasto</span>
        </button>
        <button onClick={()=>setView("fresa")}
          style={{...S.fabBig,padding:"15px 0",fontSize:15,background:BLANCO,color:ROSA,
            border:`2px solid ${ROSA}`,boxShadow:"0 4px 14px rgba(232,23,93,0.12)"}}>
          <span style={{fontSize:22}}>🍓</span>
          <span style={{fontSize:15,fontWeight:800}}>Compra de fresa</span>
        </button>
        <div style={{display:"flex",gap:10}}>
          <button onClick={()=>setView("ventas")} style={{...S.fabMini,background:`linear-gradient(135deg,${VERDE},#1B5E20)`,boxShadow:"0 6px 18px rgba(46,125,50,0.3)"}}>
            <span style={{fontSize:20}}>💵</span><span style={{fontSize:13,fontWeight:800}}>Venta del día</span>
          </button>
          <button onClick={()=>setView("recoleccion")} style={{...S.fabMini,background:`linear-gradient(135deg,${AZUL},#0D47A1)`,boxShadow:"0 6px 18px rgba(21,101,192,0.3)"}}>
            <span style={{fontSize:20}}>💰</span>
            <span style={{fontSize:13,fontWeight:800}}>Recolectar{montoPendiente>0?` (${diasPendientes.length})`:""}</span>
          </button>
        </div>
      </div>

      {todayG.length>0&&(
        <div style={{padding:"0 16px"}}>
          <ST>Hoy</ST>
          {todayG.slice(0,4).map(g=><GastoRow key={g.id} g={g} onDelete={deleteGasto} onEdit={startEdit} inusual={esInusual(g.cat,g.monto)} canEdit={usuarioActual==="Andres"||usuarioActual==="José Luis"||(usuarioActual!=="Apolo"&&g.quien===usuarioActual)} canSeeNumbers={PUEDE_VER_NUMEROS.includes(usuarioActual)} sucursalLabel={mkSucLabel(g.sucursal_id)} cats={cats}/>)}
        </div>
      )}

      <nav style={S.bottomNav}>
        {PUEDE_VER_NUMEROS.includes(usuarioActual)&&<NavBtn icon="📊" label="Resumen" onClick={()=>setView("resumen")}/>}
        {PUEDE_VER_NUMEROS.includes(usuarioActual)&&<NavBtn icon="📉" label="Tendencias" onClick={()=>setView("analitica")}/>}
        {PUEDE_VER_NUMEROS.includes(usuarioActual)&&<NavBtn icon="📅" label="Historial" onClick={()=>setView("historial")}/>}
        <NavBtn icon="💰" label="Recolectar" onClick={()=>setView("recoleccion")}/>
      </nav>
    </div>
  );
}

// ── COMPONENTES MULTI-SUCURSAL ────────────────────────────────────────────────

// Selector horizontal de sucursales para usar en formularios
function SucursalChips({sucursales,value,onChange}){
  if(!sucursales||sucursales.length===0){
    return(
      <div style={{background:"#FFEBEE",borderRadius:12,padding:"10px 14px",fontSize:12,color:"#C62828",fontWeight:600,marginBottom:4}}>
        ⚠️ No hay sucursales configuradas. Pídele a un admin que cree alguna desde el botón "Sucursales" de la pantalla de inicio.
      </div>
    );
  }
  return(
    <div style={{display:"flex",flexWrap:"wrap",gap:8,marginBottom:4}}>
      {sucursales.map(s=>{
        const sel=value===s.id;
        const color=s.color||"#E8175D";
        return(
          <button key={s.id} onClick={()=>onChange(s.id)}
            style={{padding:"10px 14px",borderRadius:14,cursor:"pointer",fontFamily:"inherit",
              border:`2px solid ${sel?color:"#E0E0E0"}`,
              background:sel?color:"#F5F5F5",
              color:sel?"#FFF":"#555",
              fontSize:13,fontWeight:800,
              display:"flex",alignItems:"center",gap:6,
              transform:sel?"scale(1.04)":"scale(1)",
              transition:"all 0.15s"}}>
            <span style={{fontSize:16}}>{s.emoji||"📍"}</span>
            <span>{s.nombre}</span>
          </button>
        );
      })}
    </div>
  );
}

// Barra horizontal de sucursales en el inicio (incluye "Todas" + botón admin)
function SucursalBar({sucursales,sucursalActiva,setSucursalActiva,puedeAdmin,onAdmin,onAdminCat}){
  const activas=sucursales.filter(s=>s.activa!==false);
  if(activas.length===0&&!puedeAdmin)return null;
  return(
    <div style={{background:"#FFF",padding:"10px 14px",borderBottom:"1px solid #F0F0F0",display:"flex",gap:8,overflowX:"auto",alignItems:"center"}}>
      <span style={{fontSize:11,fontWeight:800,color:"#888",textTransform:"uppercase",letterSpacing:0.6,flexShrink:0}}>Sucursal:</span>
      <button onClick={()=>setSucursalActiva(null)}
        style={{padding:"6px 12px",borderRadius:14,border:sucursalActiva==null?"2px solid #E8175D":"1.5px solid #E0E0E0",
          background:sucursalActiva==null?"#FFF5F8":"#F5F5F5",
          color:sucursalActiva==null?"#E8175D":"#555",
          fontSize:12,fontWeight:800,cursor:"pointer",fontFamily:"inherit",flexShrink:0,whiteSpace:"nowrap"}}>
        🌐 Todas
      </button>
      {activas.map(s=>{
        const sel=sucursalActiva===s.id;
        const color=s.color||"#E8175D";
        return(
          <button key={s.id} onClick={()=>setSucursalActiva(s.id)}
            style={{padding:"6px 12px",borderRadius:14,border:sel?`2px solid ${color}`:"1.5px solid #E0E0E0",
              background:sel?color+"18":"#F5F5F5",
              color:sel?color:"#555",
              fontSize:12,fontWeight:800,cursor:"pointer",fontFamily:"inherit",flexShrink:0,whiteSpace:"nowrap",
              display:"flex",alignItems:"center",gap:4}}>
            <span>{s.emoji||"📍"}</span><span>{s.nombre}</span>
          </button>
        );
      })}
      {puedeAdmin&&(
        <>
          <button onClick={onAdmin}
            style={{padding:"6px 10px",borderRadius:14,border:"1.5px dashed #BBB",background:"#FAFAFA",color:"#888",
              fontSize:12,fontWeight:700,cursor:"pointer",fontFamily:"inherit",flexShrink:0,whiteSpace:"nowrap"}}>
            ⚙️ Sucursales
          </button>
          {onAdminCat&&(
            <button onClick={onAdminCat}
              style={{padding:"6px 10px",borderRadius:14,border:"1.5px dashed #BBB",background:"#FAFAFA",color:"#888",
                fontSize:12,fontWeight:700,cursor:"pointer",fontFamily:"inherit",flexShrink:0,whiteSpace:"nowrap"}}>
              📂 Categorías
            </button>
          )}
        </>
      )}
    </div>
  );
}

// Pantalla completa de Recolección con manejo de sucursal
// Panel admin de sucursales (crear/editar/desactivar/eliminar)
function AdminSucursalesView({sucursales,setView,sucursalActiva,setSucursalActiva,onChange,gastos,ventas,recolecciones}){
  const[modo,setModo]=useState(null); // null | "nueva" | objeto sucursal en edición
  const[form,setForm]=useState({nombre:"",emoji:"🍓",color:SUC_COLORS[0],orden:0,activa:true});
  const[saving,setSaving]=useState(false);
  const[err,setErr]=useState(null);
  const[confirmDel,setConfirmDel]=useState(null);

  const empezarNueva=()=>{
    const usadosColor=new Set(sucursales.map(s=>s.color));
    const usadosEmoji=new Set(sucursales.map(s=>s.emoji));
    const colorLibre=SUC_COLORS.find(c=>!usadosColor.has(c))||SUC_COLORS[0];
    const emojiLibre=SUC_EMOJIS.find(e=>!usadosEmoji.has(e))||SUC_EMOJIS[0];
    setForm({nombre:"",emoji:emojiLibre,color:colorLibre,orden:(sucursales.length+1),activa:true});
    setModo("nueva");setErr(null);
  };
  const empezarEdit=(s)=>{
    setForm({nombre:s.nombre,emoji:s.emoji||"🍓",color:s.color||SUC_COLORS[0],orden:s.orden||0,activa:s.activa!==false});
    setModo(s);setErr(null);
  };
  const cancelar=()=>{setModo(null);setErr(null);};
  const guardar=async()=>{
    const nombre=(form.nombre||"").trim();
    if(!nombre){setErr("El nombre no puede estar vacío");return;}
    setSaving(true);
    let e;
    if(modo==="nueva"){
      ({error:e}=await sb.from("sucursales").insert([{nombre,emoji:form.emoji,color:form.color,orden:form.orden,activa:form.activa}]));
    } else {
      ({error:e}=await sb.from("sucursales").update({nombre,emoji:form.emoji,color:form.color,orden:form.orden,activa:form.activa}).eq("id",modo.id));
    }
    setSaving(false);
    if(e){setErr(e.message);return;}
    await onChange();
    setModo(null);
  };
  const toggleActiva=async(s)=>{
    await sb.from("sucursales").update({activa:!(s.activa!==false)}).eq("id",s.id);
    await onChange();
  };
  const eliminar=async(s)=>{
    // Comprobar si tiene movimientos
    const gN=gastos.filter(g=>g.sucursal_id===s.id).length;
    const vN=ventas.filter(v=>v.sucursal_id===s.id).length;
    const rN=recolecciones.filter(r=>r.sucursal_id===s.id).length;
    if(gN+vN+rN>0){
      setErr(`No se puede eliminar: tiene ${gN} gastos, ${vN} ventas y ${rN} recolecciones. Desactívala en su lugar.`);
      setConfirmDel(null);
      return;
    }
    const{error:e}=await sb.from("sucursales").delete().eq("id",s.id);
    if(e){setErr(e.message);return;}
    if(sucursalActiva===s.id)setSucursalActiva(null);
    setConfirmDel(null);
    await onChange();
  };

  return(
    <Screen title="Sucursales" onBack={()=>setView("inicio")}>
      <div style={{...S.infoBox,marginBottom:14}}>
        ⚙️ Aquí gestionas las sucursales del negocio. Los movimientos (gastos / ventas / recolecciones) están ligados a una sucursal: si desactivas una, sigue apareciendo en reportes pero no en formularios nuevos.
      </div>

      {!modo&&(
        <>
          <button onClick={empezarNueva}
            style={{...S.btnPri,marginTop:0,marginBottom:18,background:`linear-gradient(135deg,${ROSA},${ROSA_DARK})`}}>
            + Nueva sucursal
          </button>

          {sucursales.length===0?<Empty>No hay sucursales</Empty>:sucursales.map(s=>{
            const gN=gastos.filter(g=>g.sucursal_id===s.id).length;
            const vN=ventas.filter(v=>v.sucursal_id===s.id).length;
            const rN=recolecciones.filter(r=>r.sucursal_id===s.id).length;
            const totalMov=gN+vN+rN;
            const activa=s.activa!==false;
            return(
              <div key={s.id} style={{...S.card,marginBottom:10,opacity:activa?1:0.55,border:`1.5px solid ${(s.color||GRIS_LIGHT)}33`}}>
                <div style={{display:"flex",alignItems:"center",gap:10}}>
                  <div style={{width:42,height:42,borderRadius:12,background:(s.color||GRIS_LIGHT)+"22",color:s.color||GRIS_MED,display:"flex",alignItems:"center",justifyContent:"center",fontSize:22,flexShrink:0}}>
                    {s.emoji||"📍"}
                  </div>
                  <div style={{flex:1,minWidth:0}}>
                    <div style={{fontSize:15,fontWeight:900,color:s.color||GRIS_DARK,display:"flex",alignItems:"center",gap:6,flexWrap:"wrap"}}>
                      {s.nombre}
                      {!activa&&<span style={{fontSize:9,background:GRIS_LIGHT,color:GRIS_TEXT,borderRadius:6,padding:"1px 6px",fontWeight:700}}>INACTIVA</span>}
                    </div>
                    <div style={{fontSize:11,color:GRIS_TEXT,marginTop:2}}>
                      {gN} gastos · {vN} ventas · {rN} recolecciones
                    </div>
                  </div>
                </div>
                <div style={{display:"flex",gap:6,marginTop:10,flexWrap:"wrap"}}>
                  <button onClick={()=>empezarEdit(s)}
                    style={{flex:1,minWidth:90,padding:"8px 0",borderRadius:10,border:"1.5px solid #E0E0E0",background:BLANCO,color:GRIS_MED,fontSize:12,fontWeight:700,cursor:"pointer",fontFamily:"inherit"}}>
                    ✏️ Editar
                  </button>
                  <button onClick={()=>toggleActiva(s)}
                    style={{flex:1,minWidth:90,padding:"8px 0",borderRadius:10,border:`1.5px solid ${activa?AMBAR:VERDE}`,background:activa?AMBAR_BG:VERDE_BG,color:activa?AMBAR:VERDE,fontSize:12,fontWeight:700,cursor:"pointer",fontFamily:"inherit"}}>
                    {activa?"⏸ Desactivar":"▶ Activar"}
                  </button>
                  {totalMov===0&&(
                    confirmDel===s.id
                      ?<button onClick={()=>eliminar(s)}
                          style={{flex:1,minWidth:90,padding:"8px 0",borderRadius:10,border:"none",background:"#E53935",color:BLANCO,fontSize:12,fontWeight:800,cursor:"pointer",fontFamily:"inherit"}}>
                          🗑 ¿Borrar?
                        </button>
                      :<button onClick={()=>setConfirmDel(s.id)}
                          style={{flex:1,minWidth:90,padding:"8px 0",borderRadius:10,border:"1.5px solid #EF9A9A",background:"#FFEBEE",color:"#E53935",fontSize:12,fontWeight:700,cursor:"pointer",fontFamily:"inherit"}}>
                          🗑 Eliminar
                        </button>
                  )}
                </div>
              </div>
            );
          })}
          {err&&<div style={S.errorBanner}>{err}</div>}
        </>
      )}

      {/* Form de creación / edición */}
      {modo&&(
        <div style={{background:BLANCO,borderRadius:16,padding:"16px",boxShadow:"0 2px 12px rgba(0,0,0,0.06)"}}>
          <div style={{fontSize:14,fontWeight:900,color:GRIS_DARK,marginBottom:12}}>
            {modo==="nueva"?"➕ Nueva sucursal":`✏️ Editar ${modo.nombre}`}
          </div>

          <FL>Nombre *</FL>
          <input style={S.input} placeholder="Ej: Coyoacán, Polanco…"
            value={form.nombre} onChange={e=>setForm(f=>({...f,nombre:e.target.value}))}/>

          <FL>Emoji</FL>
          <div style={{display:"flex",flexWrap:"wrap",gap:6,marginBottom:4}}>
            {SUC_EMOJIS.map(em=>(
              <button key={em} onClick={()=>setForm(f=>({...f,emoji:em}))}
                style={{width:42,height:42,borderRadius:10,fontSize:22,cursor:"pointer",fontFamily:"inherit",
                  border:`2px solid ${form.emoji===em?form.color:"#E0E0E0"}`,
                  background:form.emoji===em?form.color+"18":"#F5F5F5"}}>
                {em}
              </button>
            ))}
          </div>

          <FL>Color</FL>
          <div style={{display:"flex",flexWrap:"wrap",gap:6,marginBottom:4}}>
            {SUC_COLORS.map(c=>(
              <button key={c} onClick={()=>setForm(f=>({...f,color:c}))}
                style={{width:42,height:42,borderRadius:"50%",cursor:"pointer",border:form.color===c?"3px solid #000":"3px solid transparent",
                  background:c,padding:0,fontFamily:"inherit"}}/>
            ))}
          </div>

          <FL>Orden de aparición</FL>
          <input type="number" inputMode="numeric" style={S.input}
            placeholder="0" value={form.orden}
            onChange={e=>setForm(f=>({...f,orden:parseInt(e.target.value)||0}))}/>

          <FL>Estado</FL>
          <div style={{display:"flex",gap:8,marginBottom:4}}>
            <button onClick={()=>setForm(f=>({...f,activa:true}))}
              style={{flex:1,padding:"10px 0",borderRadius:12,cursor:"pointer",fontFamily:"inherit",fontWeight:800,fontSize:13,
                border:`2px solid ${form.activa?VERDE:"#E0E0E0"}`,
                background:form.activa?VERDE_BG:GRIS_LIGHT,
                color:form.activa?VERDE:GRIS_TEXT}}>
              ✅ Activa
            </button>
            <button onClick={()=>setForm(f=>({...f,activa:false}))}
              style={{flex:1,padding:"10px 0",borderRadius:12,cursor:"pointer",fontFamily:"inherit",fontWeight:800,fontSize:13,
                border:`2px solid ${!form.activa?AMBAR:"#E0E0E0"}`,
                background:!form.activa?AMBAR_BG:GRIS_LIGHT,
                color:!form.activa?AMBAR:GRIS_TEXT}}>
              ⏸ Inactiva
            </button>
          </div>

          {/* Vista previa */}
          <div style={{background:GRIS_LIGHT,borderRadius:12,padding:"14px",marginTop:14,marginBottom:8,textAlign:"center"}}>
            <div style={{fontSize:10,fontWeight:800,color:GRIS_TEXT,letterSpacing:0.6,marginBottom:8}}>VISTA PREVIA</div>
            <div style={{display:"inline-flex",alignItems:"center",gap:6,background:form.color+"18",color:form.color,padding:"8px 14px",borderRadius:14,fontWeight:800,fontSize:14,border:`2px solid ${form.color}`}}>
              <span style={{fontSize:18}}>{form.emoji}</span>
              <span>{form.nombre||"(sin nombre)"}</span>
            </div>
          </div>

          {err&&<div style={S.errorBanner}>{err}</div>}

          <div style={{display:"flex",gap:8,marginTop:16}}>
            <button onClick={cancelar} disabled={saving}
              style={{flex:1,padding:"14px 0",borderRadius:13,border:"1.5px solid #E0E0E0",background:GRIS_LIGHT,color:GRIS_MED,fontSize:14,fontWeight:800,cursor:"pointer",fontFamily:"inherit"}}>
              Cancelar
            </button>
            <button onClick={guardar} disabled={saving||!form.nombre.trim()}
              style={{flex:1,padding:"14px 0",borderRadius:13,border:"none",background:saving?GRIS_MED:form.color,color:BLANCO,fontSize:14,fontWeight:800,cursor:"pointer",fontFamily:"inherit",opacity:!form.nombre.trim()?0.4:1}}>
              {saving?"⏳ Guardando…":"💾 Guardar"}
            </button>
          </div>
        </div>
      )}
    </Screen>
  );
}

// Panel admin de categorías (crear/editar/desactivar/eliminar)
// Funciona igual que el de sucursales pero con extras:
// - cada categoría puede ser global (sucursal_id=null) o específica de una sucursal
// - cat_key es el identificador que va en gastos.cat (NO se puede cambiar después de crear)
function AdminCategoriasView({cats,sucursales,setView,onChange,gastos}){
  const sucActivas=sucursales.filter(s=>s.activa!==false);
  // Estado para crear/editar
  const[modo,setModo]=useState(null); // null | "nueva" | {_dbId, ...} en edición
  const[form,setForm]=useState({cat_key:"",nombre:"",emoji:"📦",color:"#546E7A",orden:0,activa:true,sucursal_id:null});
  const[saving,setSaving]=useState(false);
  const[err,setErr]=useState(null);
  const[confirmDel,setConfirmDel]=useState(null);
  // Filtro de visualización: ver todas / sólo globales / por sucursal específica
  const[verSuc,setVerSuc]=useState("todas"); // "todas" | "globales" | id de sucursal

  // Catálogo extendido de emojis y colores para categorías
  const EMOJIS_CAT=["🍓","🥛","🍫","🍯","🧃","🍬","☕","🥤","📢","🧹","📦","🍦","🍌","🍇","🍒","🍑","🥥","🥭","🌽","🥖","🥯","🥞","🧀","🍳","🥩","🍗","🐟","🦐","🥗","🌶️","🧂","🥄","🍴","🍽️","🪣","🧴","🧻","💡","🔌","💧","🚿","💧","💵","💳","📱","📞","🚗","⛽","🔧","🛠️","📋","💼","🧾","💰","📊","🎁","🎉","🎊","✨"];
  const COLORS_CAT=["#E8175D","#1565C0","#4E342E","#E65100","#00796B","#F57F17","#5D4037","#6A1B9A","#C62828","#2E7D32","#546E7A","#AD1457","#0277BD","#558B2F","#EF6C00","#00838F","#6D4C41","#8E24AA","#D32F2F","#388E3C","#455A64","#FF7043","#26A69A","#7E57C2"];

  // Recuento de uso por categoría (cuántos gastos están en cada cat_key)
  const usoPorCat={};
  gastos.forEach(g=>{usoPorCat[g.cat]=(usoPorCat[g.cat]||0)+1;});

  const empezarNueva=()=>{
    setForm({cat_key:"",nombre:"",emoji:"📦",color:COLORS_CAT[Math.floor(Math.random()*COLORS_CAT.length)],orden:(cats.length+1)*10,activa:true,sucursal_id:null});
    setModo("nueva");setErr(null);
  };
  const empezarEdit=(c)=>{
    setForm({cat_key:c.id,nombre:c.label,emoji:c.emoji,color:c.color,orden:c.orden||0,activa:c.activa!==false,sucursal_id:c.sucursal_id});
    setModo(c);setErr(null);
  };
  const cancelar=()=>{setModo(null);setErr(null);};

  // Normalizar cat_key: minúsculas, sin acentos, sin espacios
  const normCatKey=(s)=>(s||"").normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase().replace(/[^a-z0-9_]/g,"_").replace(/_+/g,"_").replace(/^_|_$/g,"");

  const guardar=async()=>{
    const nombre=(form.nombre||"").trim();
    let cat_key=(form.cat_key||"").trim();
    if(!cat_key)cat_key=normCatKey(nombre);
    if(!nombre){setErr("El nombre no puede estar vacío");return;}
    if(!cat_key){setErr("La clave técnica no puede estar vacía");return;}
    if(!/^[a-z0-9_]+$/.test(cat_key)){setErr("La clave sólo puede tener letras minúsculas, números y _");return;}
    setSaving(true);
    const payload={cat_key,nombre,emoji:form.emoji,color:form.color,orden:form.orden,activa:form.activa,sucursal_id:form.sucursal_id};
    let e;
    if(modo==="nueva"){
      ({error:e}=await sb.from("categorias").insert([payload]));
    } else {
      // Al editar NO permitimos cambiar cat_key (rompería los gastos vinculados)
      const{cat_key:_omit,...sinKey}=payload;
      ({error:e}=await sb.from("categorias").update(sinKey).eq("id",modo._dbId));
    }
    setSaving(false);
    if(e){setErr(e.message);return;}
    await onChange();
    setModo(null);
  };
  const toggleActiva=async(c)=>{
    await sb.from("categorias").update({activa:!(c.activa!==false)}).eq("id",c._dbId);
    await onChange();
  };
  const eliminar=async(c)=>{
    const n=usoPorCat[c.id]||0;
    if(n>0){
      setErr(`No se puede eliminar "${c.label}": hay ${n} gasto${n!==1?"s":""} en esta categoría. Desactívala en su lugar.`);
      setConfirmDel(null);
      return;
    }
    const{error:e}=await sb.from("categorias").delete().eq("id",c._dbId);
    if(e){setErr(e.message);return;}
    setConfirmDel(null);
    await onChange();
  };

  // Filtrado de la lista a mostrar
  const catsVisibles=cats.filter(c=>{
    if(verSuc==="todas")return true;
    if(verSuc==="globales")return c.sucursal_id==null;
    return c.sucursal_id===verSuc;
  });

  return(
    <Screen title="Categorías" onBack={()=>setView("inicio")}>
      <div style={{...S.infoBox,marginBottom:14}}>
        📂 Las categorías <strong>globales</strong> (🌐) aparecen en todas las sucursales. Una categoría <strong>específica</strong> sólo se ve en la sucursal asignada. Útil si Narvarte vende algo que Balbuena no.
      </div>

      {!modo&&(
        <>
          <button onClick={empezarNueva}
            style={{...S.btnPri,marginTop:0,marginBottom:14,background:`linear-gradient(135deg,${ROSA},${ROSA_DARK})`}}>
            + Nueva categoría
          </button>

          {/* Filtro */}
          <div style={{display:"flex",gap:6,marginBottom:14,overflowX:"auto",paddingBottom:4}}>
            <button onClick={()=>setVerSuc("todas")}
              style={{padding:"6px 12px",borderRadius:14,border:verSuc==="todas"?"2px solid #E8175D":"1.5px solid #E0E0E0",
                background:verSuc==="todas"?"#FFF5F8":"#F5F5F5",color:verSuc==="todas"?"#E8175D":"#555",
                fontSize:12,fontWeight:800,cursor:"pointer",fontFamily:"inherit",flexShrink:0,whiteSpace:"nowrap"}}>
              Todas ({cats.length})
            </button>
            <button onClick={()=>setVerSuc("globales")}
              style={{padding:"6px 12px",borderRadius:14,border:verSuc==="globales"?"2px solid #E8175D":"1.5px solid #E0E0E0",
                background:verSuc==="globales"?"#FFF5F8":"#F5F5F5",color:verSuc==="globales"?"#E8175D":"#555",
                fontSize:12,fontWeight:800,cursor:"pointer",fontFamily:"inherit",flexShrink:0,whiteSpace:"nowrap"}}>
              🌐 Globales ({cats.filter(c=>c.sucursal_id==null).length})
            </button>
            {sucActivas.map(s=>{
              const n=cats.filter(c=>c.sucursal_id===s.id).length;
              return(
                <button key={s.id} onClick={()=>setVerSuc(s.id)}
                  style={{padding:"6px 12px",borderRadius:14,border:verSuc===s.id?`2px solid ${s.color}`:"1.5px solid #E0E0E0",
                    background:verSuc===s.id?s.color+"18":"#F5F5F5",color:verSuc===s.id?s.color:"#555",
                    fontSize:12,fontWeight:800,cursor:"pointer",fontFamily:"inherit",flexShrink:0,whiteSpace:"nowrap",
                    display:"flex",alignItems:"center",gap:4}}>
                  <span>{s.emoji||"📍"}</span><span>{s.nombre} ({n})</span>
                </button>
              );
            })}
          </div>

          {catsVisibles.length===0?<Empty>No hay categorías que mostrar</Empty>:catsVisibles.sort((a,b)=>(a.orden||0)-(b.orden||0)).map(c=>{
            const usos=usoPorCat[c.id]||0;
            const activa=c.activa!==false;
            const sucObj=c.sucursal_id?sucursales.find(s=>s.id===c.sucursal_id):null;
            return(
              <div key={c._dbId} style={{...S.card,marginBottom:10,opacity:activa?1:0.55,border:`1.5px solid ${c.color}33`}}>
                <div style={{display:"flex",alignItems:"center",gap:10}}>
                  <div style={{width:42,height:42,borderRadius:12,background:c.color+"22",color:c.color,display:"flex",alignItems:"center",justifyContent:"center",fontSize:22,flexShrink:0}}>
                    {c.emoji}
                  </div>
                  <div style={{flex:1,minWidth:0}}>
                    <div style={{fontSize:15,fontWeight:900,color:c.color,display:"flex",alignItems:"center",gap:6,flexWrap:"wrap"}}>
                      {c.label}
                      {!activa&&<span style={{fontSize:9,background:GRIS_LIGHT,color:GRIS_TEXT,borderRadius:6,padding:"1px 6px",fontWeight:700}}>INACTIVA</span>}
                      {sucObj
                        ?<span style={{fontSize:9,background:sucObj.color+"22",color:sucObj.color,borderRadius:6,padding:"1px 6px",fontWeight:700}}>{sucObj.emoji} {sucObj.nombre}</span>
                        :<span style={{fontSize:9,background:"#E3F2FD",color:AZUL,borderRadius:6,padding:"1px 6px",fontWeight:700}}>🌐 Global</span>}
                    </div>
                    <div style={{fontSize:11,color:GRIS_TEXT,marginTop:2}}>
                      Clave: <code style={{background:GRIS_LIGHT,padding:"1px 5px",borderRadius:4,fontSize:10}}>{c.id}</code> · {usos} gasto{usos!==1?"s":""}
                    </div>
                  </div>
                </div>
                <div style={{display:"flex",gap:6,marginTop:10,flexWrap:"wrap"}}>
                  <button onClick={()=>empezarEdit(c)}
                    style={{flex:1,minWidth:90,padding:"8px 0",borderRadius:10,border:"1.5px solid #E0E0E0",background:BLANCO,color:GRIS_MED,fontSize:12,fontWeight:700,cursor:"pointer",fontFamily:"inherit"}}>
                    ✏️ Editar
                  </button>
                  <button onClick={()=>toggleActiva(c)}
                    style={{flex:1,minWidth:90,padding:"8px 0",borderRadius:10,border:`1.5px solid ${activa?AMBAR:VERDE}`,background:activa?AMBAR_BG:VERDE_BG,color:activa?AMBAR:VERDE,fontSize:12,fontWeight:700,cursor:"pointer",fontFamily:"inherit"}}>
                    {activa?"⏸ Desactivar":"▶ Activar"}
                  </button>
                  {usos===0&&(
                    confirmDel===c._dbId
                      ?<button onClick={()=>eliminar(c)}
                          style={{flex:1,minWidth:90,padding:"8px 0",borderRadius:10,border:"none",background:"#E53935",color:BLANCO,fontSize:12,fontWeight:800,cursor:"pointer",fontFamily:"inherit"}}>
                          🗑 ¿Borrar?
                        </button>
                      :<button onClick={()=>setConfirmDel(c._dbId)}
                          style={{flex:1,minWidth:90,padding:"8px 0",borderRadius:10,border:"1.5px solid #EF9A9A",background:"#FFEBEE",color:"#E53935",fontSize:12,fontWeight:700,cursor:"pointer",fontFamily:"inherit"}}>
                          🗑 Eliminar
                        </button>
                  )}
                </div>
              </div>
            );
          })}
          {err&&<div style={S.errorBanner}>{err}</div>}
        </>
      )}

      {/* Form crear/editar */}
      {modo&&(
        <div style={{background:BLANCO,borderRadius:16,padding:"16px",boxShadow:"0 2px 12px rgba(0,0,0,0.06)"}}>
          <div style={{fontSize:14,fontWeight:900,color:GRIS_DARK,marginBottom:12}}>
            {modo==="nueva"?"➕ Nueva categoría":`✏️ Editar ${modo.label}`}
          </div>

          <FL>Nombre *</FL>
          <input style={S.input} placeholder="Ej: Renta, Sueldos, Servicios…"
            value={form.nombre}
            onChange={e=>{
              const nombre=e.target.value;
              setForm(f=>({...f,nombre,cat_key:modo==="nueva"&&!f.cat_key.trim()?normCatKey(nombre):f.cat_key}));
            }}/>

          <FL>Clave técnica {modo==="nueva"?<span style={{color:GRIS_TEXT,fontWeight:400}}> (autogenerada — puedes editarla)</span>:<span style={{color:GRIS_TEXT,fontWeight:400}}> (no editable después de crear)</span>}</FL>
          <input style={{...S.input,opacity:modo==="nueva"?1:0.5,fontFamily:"monospace"}}
            disabled={modo!=="nueva"}
            placeholder="ej: renta"
            value={form.cat_key}
            onChange={e=>setForm(f=>({...f,cat_key:e.target.value}))}/>

          <FL>¿En qué sucursales?</FL>
          <div style={{display:"flex",flexWrap:"wrap",gap:6,marginBottom:4}}>
            <button onClick={()=>setForm(f=>({...f,sucursal_id:null}))}
              style={{padding:"8px 14px",borderRadius:14,cursor:"pointer",fontFamily:"inherit",fontSize:13,fontWeight:800,
                border:form.sucursal_id==null?"2px solid #E8175D":"1.5px solid #E0E0E0",
                background:form.sucursal_id==null?"#FFF5F8":"#F5F5F5",
                color:form.sucursal_id==null?"#E8175D":"#555"}}>
              🌐 Todas (global)
            </button>
            {sucActivas.map(s=>(
              <button key={s.id} onClick={()=>setForm(f=>({...f,sucursal_id:s.id}))}
                style={{padding:"8px 14px",borderRadius:14,cursor:"pointer",fontFamily:"inherit",fontSize:13,fontWeight:800,
                  border:form.sucursal_id===s.id?`2px solid ${s.color}`:"1.5px solid #E0E0E0",
                  background:form.sucursal_id===s.id?s.color+"18":"#F5F5F5",
                  color:form.sucursal_id===s.id?s.color:"#555",
                  display:"flex",alignItems:"center",gap:4}}>
                <span>{s.emoji}</span><span>Solo {s.nombre}</span>
              </button>
            ))}
          </div>

          <FL>Emoji</FL>
          <div style={{display:"flex",flexWrap:"wrap",gap:5,marginBottom:4,maxHeight:140,overflowY:"auto",padding:6,background:GRIS_LIGHT,borderRadius:10}}>
            {EMOJIS_CAT.map((em,i)=>(
              <button key={i} onClick={()=>setForm(f=>({...f,emoji:em}))}
                style={{width:36,height:36,borderRadius:8,fontSize:18,cursor:"pointer",fontFamily:"inherit",
                  border:`2px solid ${form.emoji===em?form.color:"transparent"}`,
                  background:form.emoji===em?form.color+"18":"#FFF"}}>
                {em}
              </button>
            ))}
          </div>

          <FL>Color</FL>
          <div style={{display:"flex",flexWrap:"wrap",gap:6,marginBottom:4}}>
            {COLORS_CAT.map(c=>(
              <button key={c} onClick={()=>setForm(f=>({...f,color:c}))}
                style={{width:36,height:36,borderRadius:"50%",cursor:"pointer",border:form.color===c?"3px solid #000":"3px solid transparent",
                  background:c,padding:0,fontFamily:"inherit"}}/>
            ))}
          </div>

          <FL>Orden</FL>
          <input type="number" inputMode="numeric" style={S.input}
            placeholder="0" value={form.orden}
            onChange={e=>setForm(f=>({...f,orden:parseInt(e.target.value)||0}))}/>

          <FL>Estado</FL>
          <div style={{display:"flex",gap:8,marginBottom:4}}>
            <button onClick={()=>setForm(f=>({...f,activa:true}))}
              style={{flex:1,padding:"10px 0",borderRadius:12,cursor:"pointer",fontFamily:"inherit",fontWeight:800,fontSize:13,
                border:`2px solid ${form.activa?VERDE:"#E0E0E0"}`,
                background:form.activa?VERDE_BG:GRIS_LIGHT,
                color:form.activa?VERDE:GRIS_TEXT}}>
              ✅ Activa
            </button>
            <button onClick={()=>setForm(f=>({...f,activa:false}))}
              style={{flex:1,padding:"10px 0",borderRadius:12,cursor:"pointer",fontFamily:"inherit",fontWeight:800,fontSize:13,
                border:`2px solid ${!form.activa?AMBAR:"#E0E0E0"}`,
                background:!form.activa?AMBAR_BG:GRIS_LIGHT,
                color:!form.activa?AMBAR:GRIS_TEXT}}>
              ⏸ Inactiva
            </button>
          </div>

          {/* Vista previa */}
          <div style={{background:GRIS_LIGHT,borderRadius:12,padding:"14px",marginTop:14,marginBottom:8,textAlign:"center"}}>
            <div style={{fontSize:10,fontWeight:800,color:GRIS_TEXT,letterSpacing:0.6,marginBottom:8}}>VISTA PREVIA</div>
            <div style={{display:"inline-flex",flexDirection:"column",alignItems:"center",padding:"10px 14px",borderRadius:13,background:form.color,color:BLANCO,minWidth:72}}>
              <span style={{fontSize:24}}>{form.emoji}</span>
              <span style={{fontSize:9,marginTop:3,textAlign:"center",lineHeight:1.2,fontWeight:600}}>{form.nombre||"(sin nombre)"}</span>
            </div>
          </div>

          {err&&<div style={S.errorBanner}>{err}</div>}

          <div style={{display:"flex",gap:8,marginTop:16}}>
            <button onClick={cancelar} disabled={saving}
              style={{flex:1,padding:"14px 0",borderRadius:13,border:"1.5px solid #E0E0E0",background:GRIS_LIGHT,color:GRIS_MED,fontSize:14,fontWeight:800,cursor:"pointer",fontFamily:"inherit"}}>
              Cancelar
            </button>
            <button onClick={guardar} disabled={saving||!form.nombre.trim()}
              style={{flex:1,padding:"14px 0",borderRadius:13,border:"none",background:saving?GRIS_MED:form.color,color:BLANCO,fontSize:14,fontWeight:800,cursor:"pointer",fontFamily:"inherit",opacity:!form.nombre.trim()?0.4:1}}>
              {saving?"⏳ Guardando…":"💾 Guardar"}
            </button>
          </div>
        </div>
      )}
    </Screen>
  );
}

function RecoleccionView({rForm,setRForm,ventas,recolecciones,recoleccionesF,sucursales,sucActivas,sucursalActiva,setView,setSelRec,setSelVentaDia,fetchV,usuarioActual,saveRecoleccion,rSaved,error,sucName,sucEmoji,sucColor}){
  // Sucursal del formulario manda. Si no hay, requerimos al usuario que elija.
  const sucForm=rForm.sucursal_id;
  // Ventas y recolecciones de la sucursal del form:
  const ventasSuc=sucForm?ventas.filter(v=>v.sucursal_id===sucForm):[];
  const recosSuc=sucForm?recolecciones.filter(r=>r.sucursal_id===sucForm):[];
  const diasCubiertos=recosSuc.flatMap(r=>r.fechas_cubiertas||[]);
  const diasPendientesSuc=ventasSuc.filter(v=>!diasCubiertos.includes(v.fecha)).map(v=>v.fecha).sort();
  const montoPendienteSuc=ventasSuc.filter(v=>!diasCubiertos.includes(v.fecha)).reduce((s,v)=>s+num(v.efectivo),0);

  return(
    <Screen title="Recolección de Efectivo" onBack={()=>setView("inicio")}>
      <FL>📍 Sucursal a recolectar *</FL>
      <SucursalChips sucursales={sucActivas} value={rForm.sucursal_id}
        onChange={(id)=>setRForm(f=>({...f,sucursal_id:id,selDias:[]}))}/>

      {!sucForm?(
        <div style={{...S.infoBox,marginTop:14}}>👆 Elige la sucursal cuyo efectivo vas a recolectar. Cada sucursal lleva su efectivo por separado.</div>
      ):(
        <>
          <div style={{background:`linear-gradient(135deg,${VERDE},#1B5E20)`,borderRadius:18,padding:"20px",color:BLANCO,marginTop:16,marginBottom:20,boxShadow:"0 6px 20px rgba(46,125,50,0.25)"}}>
            <div style={{fontSize:12,color:"rgba(255,255,255,0.7)"}}>Efectivo pendiente en {sucEmoji(sucForm)} {sucName(sucForm)}</div>
            <div style={{fontSize:38,fontWeight:900,letterSpacing:-1.5}}>{fmtMXN(montoPendienteSuc)}</div>
            <div style={{fontSize:12,color:"rgba(255,255,255,0.65)",marginTop:4}}>{diasPendientesSuc.length} días sin recolectar</div>
          </div>

          {diasPendientesSuc.length===0?<Empty>✅ Todo recolectado en {sucName(sucForm)}</Empty>:(
            <>
              <ST>Selecciona días a recolectar</ST>
              <EditableVentasDias diasPendientes={diasPendientesSuc} ventas={ventasSuc} rForm={rForm} setRForm={setRForm} setSelVentaDia={setSelVentaDia} setView={setView} onVentaUpdated={fetchV} sucursalId={sucForm}/>

              {rForm.selDias.length>0&&(
                <div style={{background:VERDE_BG,borderRadius:12,padding:"14px 16px",marginTop:4,border:"1px solid #A5D6A7",marginBottom:4}}>
                  <div style={{fontSize:12,color:VERDE,fontWeight:700}}>Total a recolectar</div>
                  <div style={{fontSize:28,fontWeight:900,color:VERDE}}>{fmtMXN(rForm.selDias.reduce((s,d)=>{const v=ventasSuc.find(v=>v.fecha===d);return s+num(v?.efectivo);},0))}</div>
                </div>
              )}

              <FL>Fecha de recolección</FL>
              <input type="date" style={S.input} value={rForm.fecha_recoleccion} onChange={e=>setRForm(f=>({...f,fecha_recoleccion:e.target.value}))}/>
              <FL>¿Quién recolecta? *</FL>
              {usuarioActual==="Apolo"
                ?<div style={{background:"#FFF8E1",borderRadius:12,padding:"12px 14px",border:"2px solid #FFD700",marginBottom:4}}>
                   <div style={{fontSize:13,fontWeight:800,color:"#E65100"}}>🧑 Apolo</div>
                   <div style={{fontSize:11,color:"#795548",marginTop:2}}>Recolección pendiente de aprobación por José Luis</div>
                 </div>
                :<div style={S.chipRow}>{["José Luis","Jefeson","Apolo"].map(o=><Chip key={o} active={rForm.quien===o} color={VERDE} onClick={()=>setRForm(f=>({...f,quien:o}))}>{o}</Chip>)}</div>
              }

              {/* ── MONTO FÍSICO ── */}
              {(()=>{
                const montoDeclarado=rForm.selDias.reduce((s,d)=>{const v=ventasSuc.find(v=>v.fecha===d);return s+num(v?.efectivo);},0);
                const montoFisico=rForm.monto_fisico?parseFloat(rForm.monto_fisico):null;
                const faltante=montoFisico!=null?Math.max(0,montoDeclarado-montoFisico):0;
                const sobra=montoFisico!=null?Math.max(0,montoFisico-montoDeclarado):0;
                return(
                  <div style={{background:BLANCO,borderRadius:14,padding:"14px",marginTop:12,border:"1.5px solid #E0E0E0"}}>
                    <div style={{fontSize:12,fontWeight:800,color:GRIS_MED,marginBottom:10,textTransform:"uppercase",letterSpacing:0.6}}>
                      💵 Cuadre de efectivo
                    </div>
                    <div style={{display:"flex",justifyContent:"space-between",marginBottom:10}}>
                      <div style={{textAlign:"center",flex:1}}>
                        <div style={{fontSize:10,color:GRIS_TEXT,fontWeight:700,marginBottom:3}}>DECLARADO</div>
                        <div style={{fontSize:20,fontWeight:900,color:VERDE}}>{fmtMXN(montoDeclarado)}</div>
                      </div>
                      <div style={{display:"flex",alignItems:"center",fontSize:18,color:"#CCC"}}>≠</div>
                      <div style={{textAlign:"center",flex:1}}>
                        <div style={{fontSize:10,color:GRIS_TEXT,fontWeight:700,marginBottom:3}}>FÍSICO</div>
                        <div style={{fontSize:20,fontWeight:900,color:montoFisico!=null?(faltante>0?"#E53935":sobra>0?AMBAR:VERDE):GRIS_TEXT}}>
                          {montoFisico!=null?fmtMXN(montoFisico):"—"}
                        </div>
                      </div>
                    </div>
                    <div style={{position:"relative",marginBottom:8}}>
                      <span style={{position:"absolute",left:12,top:"50%",transform:"translateY(-50%)",fontSize:16,fontWeight:900,color:VERDE}}>$</span>
                      <input type="number" inputMode="decimal"
                        style={{...S.input,paddingLeft:28,fontSize:20,fontWeight:900,color:VERDE}}
                        placeholder="Monto físico entregado (opcional)"
                        value={rForm.monto_fisico}
                        onChange={e=>setRForm(f=>({...f,monto_fisico:e.target.value}))}/>
                    </div>
                    {faltante>0&&(
                      <div style={{background:"#FFEBEE",borderRadius:10,padding:"12px 14px",border:"1.5px solid #EF9A9A"}}>
                        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8}}>
                          <span style={{fontSize:13,fontWeight:800,color:"#E53935"}}>🔴 Faltante</span>
                          <span style={{fontSize:20,fontWeight:900,color:"#E53935"}}>{fmtMXN(faltante)}</span>
                        </div>
                        <div style={{fontSize:11,color:"#C62828",marginBottom:8}}>¿Quién tiene el faltante?</div>
                        <div style={{display:"flex",flexWrap:"wrap",gap:6}}>
                          {EQUIPO.map(p=>(
                            <button key={p} onClick={()=>setRForm(f=>({...f,quien_faltante:p}))}
                              style={{padding:"6px 12px",borderRadius:16,border:"none",
                                background:rForm.quien_faltante===p?"#E53935":"#FFCDD2",
                                color:rForm.quien_faltante===p?BLANCO:"#C62828",
                                fontSize:12,fontWeight:700,cursor:"pointer",fontFamily:"inherit"}}>
                              {p}
                            </button>
                          ))}
                        </div>
                        {rForm.quien_faltante&&(
                          <div style={{marginTop:8,fontSize:12,color:"#C62828",fontWeight:600}}>
                            📋 Se registrará deuda de {fmtMXN(faltante)} a cargo de {rForm.quien_faltante}
                          </div>
                        )}
                      </div>
                    )}
                    {sobra>0&&(
                      <div style={{background:AMBAR_BG,borderRadius:10,padding:"10px 14px",border:`1.5px solid ${AMBAR}`}}>
                        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                          <span style={{fontSize:13,fontWeight:800,color:AMBAR}}>⚠️ Sobrante</span>
                          <span style={{fontSize:18,fontWeight:900,color:AMBAR}}>{fmtMXN(sobra)}</span>
                        </div>
                        <div style={{fontSize:11,color:AMBAR,marginTop:4}}>Hay más efectivo del declarado — anota en la nota.</div>
                      </div>
                    )}
                    {montoFisico!=null&&faltante===0&&sobra===0&&(
                      <div style={{background:VERDE_BG,borderRadius:10,padding:"10px 14px",border:"1.5px solid #A5D6A7",textAlign:"center"}}>
                        <span style={{fontSize:13,fontWeight:800,color:VERDE}}>✅ Cuadre perfecto</span>
                      </div>
                    )}
                  </div>
                );
              })()}

              <FL>Nota</FL>
              <textarea style={{...S.input,height:56,resize:"none"}} value={rForm.nota} onChange={e=>setRForm(f=>({...f,nota:e.target.value}))}/>
              {error&&<div style={S.errorBanner}>{error}</div>}
              {(()=>{
                const noDias=!rForm.selDias.length;
                const noQuien=!rForm.quien&&usuarioActual!=="Apolo";
                const blocked=noDias||noQuien;
                return(
                  <button onClick={saveRecoleccion} disabled={blocked}
                    style={{...S.btnPri,opacity:blocked?0.5:1,background:rSaved?VERDE:ROSA,cursor:blocked?"not-allowed":"pointer"}}>
                    {rSaved?"✅ ¡Recolectado!":noDias?"Selecciona al menos un día":noQuien?"Selecciona quién recolecta":"💰 Confirmar Recolección"}
                  </button>
                );
              })()}
            </>
          )}
        </>
      )}

      {/* Historial respeta filtro de sucursal activa */}
      {recoleccionesF.length>0&&(
        <>
          <ST>Historial de recolecciones{sucursalActiva!=null?` · ${sucName(sucursalActiva)}`:""}</ST>
          {(()=>{
            const totalFaltantes=recoleccionesF.reduce((s,r)=>s+num(r.faltante),0);
            return(
              <div style={{display:"flex",gap:8,marginBottom:12,flexWrap:"wrap"}}>
                <div style={{flex:1,minWidth:120,background:VERDE_BG,borderRadius:14,padding:"12px",border:"1.5px solid #A5D6A7",textAlign:"center"}}>
                  <div style={{fontSize:10,color:VERDE,fontWeight:700}}>Total recolectado</div>
                  <div style={{fontSize:18,fontWeight:900,color:VERDE}}>{fmtMXN(recoleccionesF.reduce((s,r)=>s+num(r.monto_fisico??r.monto_total),0))}</div>
                </div>
                <div style={{flex:1,minWidth:120,background:AZUL_BG,borderRadius:14,padding:"12px",border:"1.5px solid #90CAF9",textAlign:"center"}}>
                  <div style={{fontSize:10,color:AZUL,fontWeight:700}}>Recolecciones</div>
                  <div style={{fontSize:18,fontWeight:900,color:AZUL}}>{recoleccionesF.length}</div>
                </div>
                {totalFaltantes>0&&(
                  <div style={{flex:1,minWidth:120,background:"#FFEBEE",borderRadius:14,padding:"12px",border:"1.5px solid #EF9A9A",textAlign:"center"}}>
                    <div style={{fontSize:10,color:"#E53935",fontWeight:700}}>Faltantes</div>
                    <div style={{fontSize:18,fontWeight:900,color:"#E53935"}}>{fmtMXN(totalFaltantes)}</div>
                  </div>
                )}
              </div>
            );
          })()}
          {recoleccionesF.map(r=>{
            const pendAprobacion=r.quien==="Apolo"&&!r.aprobada;
            const mostrarSuc=sucursalActiva==null;
            return(
            <button key={r.id} onClick={()=>{setSelRec(r);setView("detalle-recoleccion");}}
              style={{...S.card,display:"flex",alignItems:"center",gap:12,width:"100%",
                border:pendAprobacion?"2px solid #FFD700":r.faltante>0?"1.5px solid #EF9A9A":"1.5px solid transparent",
                background:pendAprobacion?"#FFFDE7":BLANCO,
                cursor:"pointer",fontFamily:"inherit",textAlign:"left",marginBottom:8}}>
              <div style={{...S.catEmoji,background:pendAprobacion?"#FFF8E1":r.faltante>0?"#FFEBEE":VERDE_BG,color:pendAprobacion?"#E65100":r.faltante>0?"#E53935":VERDE}}>
                {pendAprobacion?"⏳":r.faltante>0?"⚠️":"💰"}
              </div>
              <div style={{flex:1}}>
                <div style={{display:"flex",alignItems:"center",gap:6,flexWrap:"wrap"}}>
                  <div style={{fontWeight:700,fontSize:14}}>{r.fecha_recoleccion}</div>
                  {mostrarSuc&&r.sucursal_id&&<span style={{fontSize:10,background:sucColor(r.sucursal_id)+"18",color:sucColor(r.sucursal_id),borderRadius:6,padding:"1px 6px",fontWeight:700}}>{sucEmoji(r.sucursal_id)} {sucName(r.sucursal_id)}</span>}
                </div>
                <div style={{fontSize:11,color:GRIS_TEXT,marginTop:2}}>{r.quien||"—"} · {(r.fechas_cubiertas||[]).length} días</div>
                {pendAprobacion&&<div style={{fontSize:11,color:"#E65100",fontWeight:700,marginTop:2}}>⏳ Pendiente aprobación de José Luis</div>}
                {r.faltante>0&&<div style={{fontSize:11,color:"#E53935",fontWeight:700,marginTop:2}}>🔴 Faltante: {fmtMXN(r.faltante)}{r.quien_faltante?` · ${r.quien_faltante}`:""}</div>}
                {r.nota&&<div style={{fontSize:11,color:"#C0C0C0",fontStyle:"italic",marginTop:2}}>{r.nota}</div>}
              </div>
              <div style={{display:"flex",alignItems:"center",gap:6}}>
                <div style={{fontWeight:900,color:pendAprobacion?"#E65100":r.faltante>0?"#E53935":VERDE,fontSize:15}}>{fmtMXN(num(r.monto_fisico??r.monto_total))}</div>
                <span style={{color:"#CCC",fontSize:18}}>›</span>
              </div>
            </button>
          );})}
        </>
      )}
    </Screen>
  );
}

// ── SUBCOMPONENTES ────────────────────────────────────────────────────────────
// ── TARJETAS ─────────────────────────────────────────────────────────────────
// Cajita que explica el crédito real de la compra según la fecha de corte
function TarjetaCreditoBox({t,fecha,onConfig}){
  const corte=proximoCorte(fecha,t.dia_corte);
  const vence=vencimientoTarjeta(fecha,t);
  const dias=creditoRealDias(fecha,t);
  return(
    <div style={{background:AZUL_BG,border:`1.5px solid ${AZUL}55`,borderRadius:14,padding:"12px 14px",marginTop:14}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8}}>
        <div style={{fontSize:13,fontWeight:900,color:AZUL}}>💳 {t.label} — crédito automático</div>
        {onConfig&&<button onClick={onConfig} style={{background:"none",border:"none",cursor:"pointer",fontSize:11,fontWeight:800,color:AZUL,fontFamily:"inherit"}}>⚙️ Ajustar</button>}
      </div>
      <div style={{display:"flex",gap:8}}>
        {[
          {l:"Corte",v:fmtFechaCorta(corte)},
          {l:"Pagar antes del",v:fmtFechaCorta(vence)},
          {l:"Días de crédito",v:`${dias}`},
        ].map(x=>(
          <div key={x.l} style={{flex:1,background:BLANCO,borderRadius:10,padding:"8px 6px",textAlign:"center"}}>
            <div style={{fontSize:9,color:GRIS_TEXT,fontWeight:700,textTransform:"uppercase"}}>{x.l}</div>
            <div style={{fontSize:14,fontWeight:900,color:AZUL,marginTop:2}}>{x.v}</div>
          </div>
        ))}
      </div>
      <div style={{fontSize:11,color:GRIS_MED,marginTop:8,lineHeight:1.45}}>
        Se cuenta desde el corte (día {t.dia_corte}) + {t.dias_pago} días naturales. Si compras justo después del corte ganas casi el ciclo completo; justo antes, solo {t.dias_pago} días.
      </div>
    </div>
  );
}

function AdminTarjetasView({tarjetas,onSave,setView}){
  const[items,setItems]=useState(tarjetas);
  const[ok,setOk]=useState(false);
  const set=(i,patch)=>setItems(a=>a.map((t,ix)=>ix===i?{...t,...patch}:t));
  const guardar=async()=>{
    await onSave(items.map(t=>({...t,dia_corte:Math.min(31,Math.max(1,parseInt(t.dia_corte)||1)),dias_pago:Math.max(0,parseInt(t.dias_pago)||0)})));
    setOk(true);setTimeout(()=>setOk(false),1500);
  };
  const hoy=todayISO();
  return(
    <Screen title="💳 Tarjetas" onBack={()=>setView("inicio")}>
      <div style={{...S.infoBox,marginBottom:6,lineHeight:1.5}}>
        En México el crédito de una tarjeta se cuenta desde la <strong>fecha de corte</strong>, no desde la compra.
        Pon el día de corte y cuántos días naturales te dan para pagar; la app calcula sola el vencimiento de cada gasto.
      </div>
      {items.map((t,i)=>{
        const vence=vencimientoTarjeta(hoy,t);
        return(
          <div key={t.key} style={{background:BLANCO,borderRadius:16,padding:14,marginTop:14,
            boxShadow:"0 2px 10px rgba(0,0,0,0.06)",borderLeft:`5px solid ${t.color||AZUL}`}}>
            <input style={{...S.input,fontWeight:800}} value={t.label} onChange={e=>set(i,{label:e.target.value})}/>

            <FL>Perfil de la tarjeta</FL>
            <div style={S.chipRow}>
              {PERFILES_TARJETA.map(p=>(
                <Chip key={p.id} active={t.perfil===p.id} color={AZUL}
                  onClick={()=>set(i,{perfil:p.id,dias_pago:p.dias})}>{p.label}</Chip>
              ))}
            </div>
            <div style={{fontSize:11,color:GRIS_TEXT,marginTop:6,lineHeight:1.4}}>
              {PERFILES_TARJETA.find(p=>p.id===t.perfil)?.desc||"Configura los días manualmente abajo."}
            </div>

            <div style={{display:"flex",gap:10}}>
              <div style={{flex:1}}>
                <FL>Día de corte</FL>
                <input type="number" inputMode="numeric" min="1" max="31" style={S.input}
                  value={t.dia_corte} onChange={e=>set(i,{dia_corte:e.target.value})}/>
              </div>
              <div style={{flex:1}}>
                <FL>Días para pagar</FL>
                <input type="number" inputMode="numeric" min="0" max="31" style={S.input}
                  value={t.dias_pago} onChange={e=>set(i,{dias_pago:e.target.value,perfil:"custom"})}/>
              </div>
            </div>
            <div style={{...S.infoBox,marginTop:10}}>
              Una compra de hoy se paga a más tardar el <strong>{fmtFechaCorta(vence)}</strong> · {creditoRealDias(hoy,t)} días de crédito
            </div>
          </div>
        );
      })}
      <button onClick={guardar} style={{...S.btnPri,background:ok?VERDE:ROSA}}>
        {ok?"✅ Guardado":"Guardar tarjetas"}
      </button>
      <div style={{fontSize:11,color:GRIS_TEXT,marginTop:14,lineHeight:1.6}}>
        <strong>Referencia Amex México:</strong><br/>
        • Tarjetas de Negocios (Business, Business Gold, Business Platinum): corte + 20 días naturales, hasta 50 días de financiamiento.<br/>
        • Tarjetas Corporativas (Corporate, Gold, Platinum Corporate): corte + 9 días naturales, hasta 39 días de financiamiento.<br/>
        Confirma tu día de corte en el estado de cuenta o en la app de Amex — es el dato que hace exacto el cálculo.
      </div>
    </Screen>
  );
}

function Screen({title,onBack,action,children}){
  return(
    <div style={{...S.root,paddingBottom:40}}>
      <div style={S.screenHeader}>
        <button onClick={onBack} style={S.backBtn}>‹</button>
        <div style={S.screenTitle}>{title}</div>
        <div>{action||<div style={{width:36}}/>}</div>
      </div>
      <div style={{padding:"12px 16px 40px"}}>{children}</div>
    </div>
  );
}

function GastoRow({g,onDelete,onEdit,inusual,canEdit,canSeeNumbers=true,sucursalLabel=null,cats=CATS_DEFAULT}){
  const cat=cats.find(c=>c.id===g.cat)||cats.find(c=>c.id==="otros")||CATS_DEFAULT[10];
  const[confirm,setConfirm]=useState(false);
  const[showFoto,setShowFoto]=useState(false);
  const isPendiente=g.tipo_pago==="credito"&&!g.pagado;
  const isVencido=isPendiente&&g.fecha_vencimiento&&g.fecha_vencimiento<new Date().toISOString().slice(0,10);
  return(
    <div style={{...S.card,border:isVencido?"1.5px solid #EF9A9A":inusual?`1.5px solid ${AMBAR}`:"1.5px solid transparent",marginBottom:8}}>
      <div style={{display:"flex",alignItems:"flex-start",gap:12}}>
        <div style={{...S.catEmoji,background:cat.color+"22",color:cat.color,flexShrink:0}}>{cat.emoji}</div>
        <div style={{flex:1,minWidth:0}}>
          <div style={{display:"flex",alignItems:"center",gap:6,flexWrap:"wrap"}}>
            <span style={{fontWeight:700,fontSize:14}}>{g.concepto}</span>
            {sucursalLabel&&<span style={{fontSize:10,background:sucursalLabel.bg,color:sucursalLabel.color,borderRadius:6,padding:"1px 6px",fontWeight:700}}>{sucursalLabel.emoji} {sucursalLabel.nombre}</span>}
            {inusual&&<span style={{fontSize:10,background:AMBAR_BG,color:AMBAR,borderRadius:6,padding:"1px 6px",fontWeight:700}}>⚠️ alto</span>}
            {isPendiente&&<span style={{fontSize:10,background:isVencido?"#FFEBEE":AMBAR_BG,color:isVencido?"#E53935":AMBAR,borderRadius:6,padding:"1px 6px",fontWeight:700}}>{isVencido?"🔴 vencido":"⏳ crédito"}</span>}
            {g.pagado&&g.tipo_pago==="credito"&&<span style={{fontSize:10,background:VERDE_BG,color:VERDE,borderRadius:6,padding:"1px 6px",fontWeight:700}}>✓ pagado</span>}
          </div>
          <div style={{fontSize:11,color:GRIS_TEXT,marginTop:2}}>{g.fecha} · {g.forma}{g.quien?` · ${g.quien}`:""}</div>
          {g.fecha_vencimiento&&isPendiente&&<div style={{fontSize:11,color:isVencido?"#E53935":AMBAR,fontWeight:600,marginTop:2}}>Vence: {g.fecha_vencimiento}</div>}
          {g.nota&&<div style={{fontSize:11,color:"#C0C0C0",fontStyle:"italic"}}>{g.nota}</div>}
          {g.foto&&<button onClick={()=>setShowFoto(!showFoto)} style={{fontSize:11,color:ROSA,background:"none",border:"none",cursor:"pointer",padding:0,marginTop:2}}>{showFoto?"▲ ocultar":"📎 ver ticket"}</button>}
          {g.foto&&showFoto&&(
            g.foto.match(/\.pdf(\?|$)/i)
              ?<a href={g.foto} target="_blank" rel="noreferrer"
                  style={{display:"flex",alignItems:"center",gap:6,marginTop:6,padding:"10px 12px",
                    background:"#FFF8E1",borderRadius:8,border:"1px solid #FFE082",
                    fontSize:12,fontWeight:700,color:AMBAR,textDecoration:"none"}}>
                  📄 Abrir PDF del ticket
                </a>
              :<img src={g.foto} alt="ticket" style={{width:"100%",borderRadius:8,marginTop:6,objectFit:"cover",maxHeight:140}}/>
          )}
        </div>
        <div style={{display:"flex",flexDirection:"column",alignItems:"flex-end",gap:4,marginLeft:4}}>
          {canSeeNumbers&&<div style={{fontWeight:900,color:cat.color,fontSize:15}}>{fmtMXN(g.monto)}</div>}
          {canEdit?(
            <div style={{display:"flex",gap:4}}>
              <button onClick={()=>onEdit&&onEdit(g)} style={{fontSize:12,color:AZUL,background:"none",border:"none",cursor:"pointer"}}>✏️</button>
              {confirm
                ?<button onClick={()=>{onDelete(g.id);setConfirm(false);}} style={{fontSize:10,color:"#FFF",background:"#E53935",border:"none",borderRadius:6,padding:"3px 8px",cursor:"pointer",fontWeight:700}}>¿Borrar?</button>
                :<button onClick={()=>setConfirm(true)} style={{fontSize:12,color:"#CCC",background:"none",border:"none",cursor:"pointer"}}>🗑</button>
              }
            </div>
          ):(
            <div style={{fontSize:9,color:"#CCC",fontWeight:600,marginTop:2}}>🔒</div>
          )}
        </div>
      </div>
    </div>
  );
}

function ExportBtn({onClick,label="📥 Excel"}){
  return<button onClick={onClick} style={{display:"flex",alignItems:"center",gap:4,background:VERDE_BG,color:VERDE,border:"1.5px solid #A5D6A7",borderRadius:10,padding:"6px 12px",fontSize:12,fontWeight:700,cursor:"pointer"}}>{label}</button>;
}
function Chip({children,active,color,onClick}){
  return<button onClick={onClick} style={{padding:"8px 14px",borderRadius:20,border:"none",background:active?color:"#F0F0F0",color:active?"#FFF":"#555",fontSize:13,fontWeight:600,cursor:"pointer",fontFamily:"inherit"}}>{children}</button>;
}
function FL({children}){return<div style={{fontSize:11,fontWeight:800,color:GRIS_TEXT,marginTop:18,marginBottom:6,textTransform:"uppercase",letterSpacing:0.6}}>{children}</div>;}
function ST({children}){return<div style={{fontSize:12,fontWeight:800,color:GRIS_MED,margin:"20px 0 10px",textTransform:"uppercase",letterSpacing:0.8}}>{children}</div>;}
function Empty({children}){return<div style={{textAlign:"center",color:"#CCC",fontSize:15,padding:"40px 0"}}>{children}</div>;}
function NavBtn({icon,label,onClick}){
  return<button onClick={onClick} style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",padding:"10px 0 16px",background:"none",border:"none",cursor:"pointer",color:GRIS_MED}}>
    <span style={{fontSize:24}}>{icon}</span><span style={{fontSize:10,marginTop:2,fontWeight:600}}>{label}</span>
  </button>;
}

const S={
  root:{maxWidth:430,margin:"0 auto",minHeight:"100vh",background:ROSA_BG,fontFamily:"'Helvetica Neue',Helvetica,sans-serif",paddingBottom:90},
  header:{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"18px 18px 10px",background:BLANCO},
  headerTitle:{fontSize:20,fontWeight:900,color:GRIS_DARK,letterSpacing:-0.5},
  headerSub:{fontSize:11,color:GRIS_TEXT},
  hero:{margin:"0 0 16px",background:`linear-gradient(140deg,${ROSA} 0%,${ROSA_DARK} 100%)`,padding:"24px 20px 20px",color:BLANCO},
  heroDate:{fontSize:13,color:"rgba(255,255,255,0.7)",marginBottom:8,textTransform:"capitalize"},
  heroAmount:{fontSize:44,fontWeight:900,letterSpacing:-2,lineHeight:1},
  heroStats:{display:"flex",alignItems:"center",marginTop:20,background:"rgba(0,0,0,0.12)",borderRadius:14,padding:"12px 16px",gap:8},
  heroStat:{flex:1,textAlign:"center"},
  heroStatNum:{fontSize:15,fontWeight:900},
  heroStatLabel:{fontSize:9,color:"rgba(255,255,255,0.6)",marginTop:2},
  heroCard:{background:`linear-gradient(135deg,${ROSA},${ROSA_DARK})`,borderRadius:18,padding:"22px 20px",color:BLANCO,marginBottom:20,boxShadow:"0 8px 28px rgba(232,23,93,0.22)"},
  fabBig:{display:"flex",alignItems:"center",justifyContent:"center",gap:10,width:"100%",padding:"18px 0",color:BLANCO,border:"none",borderRadius:18,cursor:"pointer",background:`linear-gradient(135deg,${ROSA},${ROSA_DARK})`,boxShadow:"0 8px 24px rgba(232,23,93,0.35)",fontSize:16,fontWeight:700,fontFamily:"inherit"},
  fabMini:{flex:1,display:"flex",alignItems:"center",justifyContent:"center",gap:8,padding:"14px 0",color:BLANCO,border:"none",borderRadius:16,cursor:"pointer",fontSize:13,fontWeight:700,fontFamily:"inherit"},
  bottomNav:{position:"fixed",bottom:0,left:"50%",transform:"translateX(-50%)",width:"100%",maxWidth:430,background:BLANCO,borderTop:"1px solid #F0F0F0",display:"flex",boxShadow:"0 -4px 20px rgba(0,0,0,0.07)",zIndex:100},
  screenHeader:{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"14px 16px 12px",background:BLANCO,borderBottom:"1px solid #F0F0F0",position:"sticky",top:0,zIndex:10},
  screenTitle:{fontWeight:800,fontSize:16,color:GRIS_DARK},
  backBtn:{width:36,height:36,borderRadius:10,background:GRIS_LIGHT,border:"none",cursor:"pointer",fontSize:24,color:GRIS_MED,display:"flex",alignItems:"center",justifyContent:"center"},
  catGrid:{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:8,marginBottom:4},
  catBtn:{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:"10px 4px",borderRadius:13,cursor:"pointer",minHeight:72,transition:"all 0.15s ease",fontFamily:"inherit"},
  chipRow:{display:"flex",flexWrap:"wrap",gap:8},
  input:{width:"100%",padding:"13px 14px",border:"1.5px solid #E8E8E8",borderRadius:13,fontSize:15,color:GRIS_DARK,background:BLANCO,outline:"none",boxSizing:"border-box",fontFamily:"inherit"},
  btnPri:{width:"100%",padding:"17px 0",color:BLANCO,border:"none",borderRadius:16,cursor:"pointer",fontSize:16,fontWeight:800,marginTop:24,fontFamily:"inherit",boxShadow:"0 6px 20px rgba(232,23,93,0.28)",transition:"background 0.3s"},
  btnSec:{width:"100%",padding:"13px 0",color:GRIS_MED,border:"1.5px solid #E0E0E0",borderRadius:13,cursor:"pointer",fontSize:14,fontWeight:700,background:GRIS_LIGHT,fontFamily:"inherit"},
  card:{background:BLANCO,borderRadius:14,padding:"12px 14px",boxShadow:"0 2px 8px rgba(0,0,0,0.05)"},
  catRow:{display:"flex",alignItems:"center",gap:12,background:BLANCO,borderRadius:14,padding:"12px 14px",marginBottom:8,boxShadow:"0 2px 8px rgba(0,0,0,0.04)"},
  catEmoji:{width:42,height:42,borderRadius:12,display:"flex",alignItems:"center",justifyContent:"center",fontSize:20},
  personaRow:{display:"flex",alignItems:"center",gap:12,background:BLANCO,borderRadius:14,padding:"12px 14px",marginBottom:8,boxShadow:"0 2px 8px rgba(0,0,0,0.04)"},
  personaAvatar:{width:38,height:38,borderRadius:"50%",background:`${ROSA}22`,color:ROSA,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:900,fontSize:16,flexShrink:0},
  monthCard:{display:"flex",justifyContent:"space-between",alignItems:"center",width:"100%",background:BLANCO,border:"none",borderRadius:16,padding:"18px 18px",marginBottom:10,cursor:"pointer",boxShadow:"0 2px 10px rgba(0,0,0,0.06)",textAlign:"left",fontFamily:"inherit"},
  dashCard:{background:BLANCO,borderRadius:14,padding:"14px 12px",boxShadow:"0 2px 8px rgba(0,0,0,0.05)"},
  actionBtn:{padding:"11px 0",borderRadius:12,border:"1.5px solid",cursor:"pointer",fontSize:13,fontWeight:700,fontFamily:"inherit",textAlign:"center"},
  alertaBanner:{background:AMBAR_BG,color:AMBAR,borderRadius:10,padding:"10px 14px",fontSize:13,fontWeight:700,border:`1px solid ${AMBAR}`},
  errorBanner:{background:"#FFEBEE",color:"#C62828",borderRadius:10,padding:"10px 14px",fontSize:13,fontWeight:700,marginTop:8,border:"1px solid #EF9A9A"},
  infoBox:{background:AZUL_BG,color:AZUL,borderRadius:10,padding:"10px 14px",fontSize:13,fontWeight:600},
};

// ── EDITABLE VENTAS EN CUADRE ─────────────────────────────────────────────────
function EditableVentasDias({diasPendientes,ventas,rForm,setRForm,setSelVentaDia,setView,onVentaUpdated,sucursalId=null}){
  const[editando,setEditando]=useState(null); // fecha
  const[nuevoMonto,setNuevoMonto]=useState("");
  const[nuevoQuien,setNuevoQuien]=useState("");
  const[saving,setSaving]=useState(false);
  const[savedFecha,setSavedFecha]=useState(null);

  const guardarEdicion=async(fecha)=>{
    if(!nuevoMonto)return;
    setSaving(true);
    // Buscar venta existente para esta fecha+sucursal
    let q=sb.from("ventas").select("id").eq("fecha",fecha);
    if(sucursalId)q=q.eq("sucursal_id",sucursalId);
    const{data:existing}=await q.limit(1);
    if(existing&&existing.length>0){
      await sb.from("ventas").update({efectivo:parseFloat(nuevoMonto),quien:nuevoQuien||undefined}).eq("id",existing[0].id);
    } else {
      const payload={fecha,efectivo:parseFloat(nuevoMonto),quien:nuevoQuien};
      if(sucursalId)payload.sucursal_id=sucursalId;
      await sb.from("ventas").insert([payload]);
    }
    await onVentaUpdated();
    setSaving(false);
    setSavedFecha(fecha);
    setEditando(null);
    setNuevoMonto("");
    setNuevoQuien("");
    setTimeout(()=>setSavedFecha(null),2000);
  };

  return(
    <>
      {diasPendientes.map(fecha=>{
        const v=ventas.find(v=>v.fecha===fecha);
        const sel=rForm.selDias.includes(fecha);
        const isEditing=editando===fecha;
        const wasSaved=savedFecha===fecha;
        return(
          <div key={fecha} style={{borderRadius:14,border:`2px solid ${wasSaved?"#A5D6A7":isEditing?AZUL:sel?VERDE:"#E0E0E0"}`,
            background:wasSaved?VERDE_BG:isEditing?AZUL_BG:sel?VERDE_BG:BLANCO,
            padding:"12px 14px",marginBottom:8,transition:"all 0.2s"}}>
            <div style={{display:"flex",alignItems:"center",gap:8}}>
              <button onClick={()=>!isEditing&&setRForm(f=>({...f,selDias:sel?f.selDias.filter(d=>d!==fecha):[...f.selDias,fecha]}))}
                style={{flex:1,background:"none",border:"none",cursor:"pointer",textAlign:"left",fontFamily:"inherit",padding:0}}>
                <div style={{fontWeight:700,fontSize:14,color:wasSaved?VERDE:isEditing?AZUL:sel?VERDE:GRIS_DARK}}>
                  {wasSaved?"✅ ":""}{fecha}
                </div>
                <div style={{fontSize:11,color:GRIS_TEXT,marginTop:2}}>
                  {v?`Registró: ${v.quien||"—"} · `:"Sin registro · "}
                  <strong style={{color:v?VERDE:"#E53935"}}>{v?fmtMXN(v.efectivo):"$0"}</strong>
                </div>
              </button>
              <button onClick={()=>{
                if(isEditing){setEditando(null);setNuevoMonto("");setNuevoQuien("");}
                else{setEditando(fecha);setNuevoMonto(v?.efectivo?String(v.efectivo):"");setNuevoQuien(v?.quien||"");}
              }} style={{background:isEditing?"#FFEBEE":GRIS_LIGHT,border:"none",borderRadius:8,
                padding:"6px 10px",cursor:"pointer",fontSize:12,
                color:isEditing?"#E53935":AZUL,fontWeight:700}}>
                {isEditing?"✕ Cancelar":"✏️ Editar"}
              </button>
            </div>

            {isEditing&&(
              <div style={{marginTop:12,paddingTop:12,borderTop:"1px solid #E8E8E8"}}>
                <div style={{fontSize:10,fontWeight:800,color:AZUL,marginBottom:6,textTransform:"uppercase",letterSpacing:0.5}}>
                  Corregir monto del {fecha}
                </div>
                <div style={{position:"relative",marginBottom:8}}>
                  <span style={{position:"absolute",left:12,top:"50%",transform:"translateY(-50%)",fontSize:18,fontWeight:900,color:VERDE}}>$</span>
                  <input type="number" inputMode="decimal" autoFocus
                    style={{width:"100%",paddingLeft:28,padding:"11px 14px 11px 28px",border:`2px solid ${AZUL}`,
                      borderRadius:10,fontSize:22,fontWeight:900,color:VERDE,background:BLANCO,
                      outline:"none",boxSizing:"border-box",fontFamily:"inherit"}}
                    placeholder="0" value={nuevoMonto}
                    onChange={e=>setNuevoMonto(e.target.value)}/>
                </div>
                <div style={{display:"flex",flexWrap:"wrap",gap:6,marginBottom:10}}>
                  {EQUIPO.map(p=>(
                    <button key={p} onClick={()=>setNuevoQuien(p)}
                      style={{padding:"6px 12px",borderRadius:16,border:"none",
                        background:nuevoQuien===p?AZUL:"#F0F0F0",
                        color:nuevoQuien===p?BLANCO:"#555",
                        fontSize:12,fontWeight:600,cursor:"pointer",fontFamily:"inherit"}}>
                      {p}
                    </button>
                  ))}
                </div>
                <button onClick={()=>guardarEdicion(fecha)} disabled={saving||!nuevoMonto}
                  style={{width:"100%",padding:"12px 0",color:BLANCO,border:"none",borderRadius:12,
                    cursor:"pointer",fontSize:14,fontWeight:800,fontFamily:"inherit",
                    background:saving?GRIS_MED:AZUL,opacity:!nuevoMonto?0.4:1}}>
                  {saving?"⏳ Guardando…":"💾 Guardar corrección"}
                </button>
              </div>
            )}
          </div>
        );
      })}
    </>
  );
}

